# NullFlux (Linux · Sealed) — by LZF

> CFD AI Agent. 封装版，源码已混淆封装，外部不可读取。

## 一、安装依赖（首次）

```bash
# 仅需 Node.js >= 18 (sealed 版不需要 npm install，所有依赖已内联)
cd nullflux-linux-sealed
```

## 二、启动 / 指定端口

```bash
./start.sh                        # 默认 0.0.0.0:5174
./start.sh --port 5180            # 自定义端口
./start.sh -p 5180                # 缩写
./start.sh 5180                   # 直接给数字
./start.sh --port 5180 --host 127.0.0.1
```

## 三、可选系统依赖

- Python 3.9+      （doc_reader.py / Notebook 内核需要；可在 ⚙ 中选解释器）
- ParaView 5.x     （pvpython 离屏渲染；可选）
- OpenFOAM v2206+  （Beta CFD 模式；可选）

## 四、首次配置

打开浏览器访问 `http://<服务器>:<端口>`，点击 ⚙ 设置：
- LLM Provider + API Key
- ParaView / OpenFOAM 路径

## 五、文件构成

```
nullflux-linux-sealed/
├── server.bundle.mjs  ← 主程序（已混淆封装，源码不可见）
├── doc_reader.py      ← Python 辅助脚本（必须明文）
├── nb_kernel_host.py  ← 同上
├── public/            ← 前端
├── start.sh           ← 启动脚本（支持端口参数）
└── README.md
```
