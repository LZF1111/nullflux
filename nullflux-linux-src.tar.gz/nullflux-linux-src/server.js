import 'dotenv/config';
import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'http';
import path from 'path';
import fs from 'fs/promises';
import fssync from 'fs';
import { fileURLToPath } from 'url';
import { spawn, spawnSync } from 'child_process';
import crypto from 'crypto';
import os from 'os';

// 可选：HTTPS_PROXY / HTTP_PROXY 支持（GitHub 偶发 fetch failed 时可设置代理）
try {
  const proxy = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy;
  if (proxy) {
    const undici = await import('undici');
    if (undici.setGlobalDispatcher && undici.ProxyAgent) {
      undici.setGlobalDispatcher(new undici.ProxyAgent(proxy));
      console.log('[net] 已启用代理:', proxy);
    }
  }
} catch {}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SETTINGS_FILE = path.join(__dirname, 'settings.json');
const IS_WIN = process.platform === 'win32';

const DEFAULT_SETTINGS = {
  apiKey: process.env.DEEPSEEK_API_KEY || '',
  baseUrl: process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com',
  model: process.env.DEEPSEEK_MODEL || 'deepseek-chat',
  provider: 'sf',                  // 'sf' (SiliconFlow / 兼容 OpenAI) | 'copilot' (GitHub Copilot)
  copilotModel: 'gpt-4.1',         // 当 provider=copilot 时使用
  paraviewExe: '',
  paraviewPython: '',
  openfoamBash: '',
  pythonPath: '',
  foamRoot: process.env.FOAM_ROOT || '',  // OpenFOAM 安装根（含 tutorials/ src/ applications/）
  foamMode: false,                          // Beta：OpenFOAM 仿真智能体模式
  mfixRoot: process.env.MFIX_ROOT || '',    // MFIX 安装根（含 tutorials/ model/）
  mfixBash: process.env.MFIX_BASH || '',    // MFIX activate/bashrc（source 后能跑 mfixsolver）
  mfixMode: false,                          // Beta：MFIX 仿真智能体模式
  lbmTutorialRoot: process.env.LBM_TUTORIAL_ROOT || '',  // 用户提供的 LBM 算例根目录（无固定框架）
  lbmRunCmd: '',                            // LBM 默认运行命令模板（如 "python run.py" / "./lb_main"）
  lbmMode: false,                           // Beta：LBM 仿真智能体模式
  customMode: false,                        // Beta：用户自定义工作流 prompt 模式
  customName: '',                           // 自定义工作流名称（如 "DEM 颗粒料仓"）
  customRoot: '',                           // 自定义工作流可选根目录（传给 agent 作为上下文）
  customPrompt: '',                         // 用户手写的流水式提示词（会拼到 system prompt）
  // V4.1: 专用视觉模型路由 —— 主模型不是 VLM 也能读图
  // 默认 SiliconFlow 的 Kimi VL；visionAnalyze 会优先走这个端点 + 这个模型，读完在把文字回传主模型。
  visionProvider: 'sf',
  visionBaseUrl: 'https://api.siliconflow.cn',
  visionModel: 'Pro/moonshotai/Kimi-K2.6',  // 可在 ui 里改，如 Qwen/Qwen2.5-VL-72B-Instruct
  visionApiKey: '',                          // 为空时复用主 apiKey
  workspace: process.env.WORKSPACE_DIR || process.cwd()
};
let SETTINGS = { ...DEFAULT_SETTINGS };
let WORKSPACE = path.resolve(DEFAULT_SETTINGS.workspace);

async function loadSettings() {
  try { SETTINGS = { ...DEFAULT_SETTINGS, ...JSON.parse(await fs.readFile(SETTINGS_FILE, 'utf8')) }; } catch {}
  WORKSPACE = path.resolve(SETTINGS.workspace || process.cwd());
}
async function saveSettings() { await fs.writeFile(SETTINGS_FILE, JSON.stringify(SETTINGS, null, 2), 'utf8'); }

// ====================== 启动期自动探测（Linux/Mac/WSL 无配置即可用）======================
function whichSync(name) {
  try {
    const r = spawnSync(IS_WIN ? 'where' : 'which', [name], { encoding: 'utf8' });
    if (r.status === 0 && r.stdout) return r.stdout.split(/\r?\n/)[0].trim();
  } catch {}
  return '';
}
async function pathExistsSync(p) { try { await fs.access(p); return true; } catch { return false; } }
async function autoProbeEnvironment() {
  let changed = false;
  // ParaView
  if (!SETTINGS.paraviewExe) {
    const cand = [whichSync('paraview'), '/usr/bin/paraview', '/usr/local/bin/paraview', '/Applications/ParaView.app/Contents/MacOS/paraview'].filter(Boolean);
    for (const c of cand) { if (await pathExistsSync(c)) { SETTINGS.paraviewExe = c; changed = true; break; } }
  }
  if (!SETTINGS.paraviewPython) {
    const cand = [whichSync('pvpython'), '/usr/bin/pvpython', '/usr/local/bin/pvpython', '/Applications/ParaView.app/Contents/bin/pvpython'].filter(Boolean);
    for (const c of cand) { if (await pathExistsSync(c)) { SETTINGS.paraviewPython = c; changed = true; break; } }
  }
  // OpenFOAM root + bashrc：扫常见安装路径
  if (!SETTINGS.foamRoot && !IS_WIN) {
    const candDirs = ['/usr/lib/openfoam', '/opt/openfoam', '/opt/OpenFOAM', '/opt'];
    const FOAM_RE = /^(?:openfoam|OpenFOAM[-_]?)[\w.-]*$/i;
    for (const base of candDirs) {
      try {
        const ents = await fs.readdir(base, { withFileTypes: true });
        for (const e of ents) {
          if (!e.isDirectory()) continue;
          if (!FOAM_RE.test(e.name)) continue;
          const root = path.join(base, e.name);
          // OpenFOAM 真正源码根：含 etc/bashrc + tutorials
          if (await pathExistsSync(path.join(root, 'etc', 'bashrc')) && await pathExistsSync(path.join(root, 'tutorials'))) {
            SETTINGS.foamRoot = root; SETTINGS.openfoamBash = path.join(root, 'etc', 'bashrc'); changed = true; break;
          }
          // ESI 风格：openfoam2312/{etc,tutorials} 嵌一层
          for (const sub of [e.name, 'OpenFOAM-' + e.name.replace(/^openfoam/i, ''), '']) {
            const inner = sub ? path.join(root, sub) : root;
            if (await pathExistsSync(path.join(inner, 'etc', 'bashrc')) && await pathExistsSync(path.join(inner, 'tutorials'))) {
              SETTINGS.foamRoot = inner; SETTINGS.openfoamBash = path.join(inner, 'etc', 'bashrc'); changed = true; break;
            }
          }
          if (SETTINGS.foamRoot) break;
        }
      } catch {}
      if (SETTINGS.foamRoot) break;
    }
  }
  // 环境变量后备
  if (!SETTINGS.foamRoot && process.env.FOAM_INST_DIR) {
    if (await pathExistsSync(process.env.FOAM_INST_DIR)) { SETTINGS.foamRoot = process.env.FOAM_INST_DIR; changed = true; }
  }
  if (!SETTINGS.openfoamBash && process.env.FOAM_BASH) {
    if (await pathExistsSync(process.env.FOAM_BASH)) { SETTINGS.openfoamBash = process.env.FOAM_BASH; changed = true; }
  }
  if (changed) { try { await saveSettings(); } catch {} }
}

// 端口优先级：命令行参数 > 环境变量 > 默认 5174
// 支持：node server.js --port 5180 / -p 5180 / --port=5180 / 5180（首个数字位置参数）
function parseCliPort() {
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--port' || a === '-p') { const v = parseInt(argv[i+1], 10); if (v > 0 && v < 65536) return v; }
    const m = a.match(/^--port=(\d+)$/); if (m) { const v = parseInt(m[1], 10); if (v > 0 && v < 65536) return v; }
    if (/^\d+$/.test(a)) { const v = parseInt(a, 10); if (v > 0 && v < 65536) return v; }
  }
  return null;
}
function parseCliHost() {
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--host' || a === '-h') { const v = argv[i+1]; if (v) return v; }
    const m = a.match(/^--host=(.+)$/); if (m) return m[1];
  }
  return null;
}
const PORT = parseCliPort() || parseInt(process.env.PORT || '5174', 10);
const IGNORE = new Set(['node_modules', '.git', '.next', 'dist', 'build', '__pycache__', '.venv', 'venv']);
const MAX_AUTO_STEPS = 80;

// ====================== 内存防护（防 OOM） ======================
// 单条工具返回最大字符数（超过则截断保存到上下文，但仍把原文回送给前端做显示）
const MAX_TOOL_RESULT_CHARS = parseInt(process.env.MAX_TOOL_RESULT_CHARS || '20000', 10);
// 整段对话上下文软上限（字符）。超过则自动压缩（保留 system + 最近 6 条）
const MAX_HISTORY_CHARS    = parseInt(process.env.MAX_HISTORY_CHARS    || '700000', 10);
function clipForHistory(s) {
  s = s == null ? '' : String(s);
  if (s.length <= MAX_TOOL_RESULT_CHARS) return s;
  const head = s.slice(0, Math.floor(MAX_TOOL_RESULT_CHARS * 0.7));
  const tail = s.slice(-Math.floor(MAX_TOOL_RESULT_CHARS * 0.2));
  return head + `\n...[已截断：原文 ${s.length} 字符，仅保留头尾，避免上下文越限]...\n` + tail;
}
function historyCharCount(messages) {
  let n = 0;
  for (const m of messages) {
    const c = m.content;
    if (typeof c === 'string') n += c.length;
    else if (Array.isArray(c)) for (const p of c) n += (p && p.text) ? p.text.length : 0;
    if (m.tool_calls) for (const t of m.tool_calls) n += (t.function?.arguments || '').length + (t.function?.name || '').length;
  }
  return n;
}
function autoCompactIfNeeded(session, ws) {
  const total = historyCharCount(session.messages);
  if (total <= MAX_HISTORY_CHARS) return false;
  const before = session.messages.length;
  if (before > 10) {
    const sys = session.messages[0];
    // 安全切点：从 -6 起，若切点落在 role:'tool' 上，向左回退到拥有它的 assistant（含 tool_calls）。
    // 否则 tail 里的 tool 消息会指向已被压缩进 summary 的 tool_call_id → OpenAI 返回 400。
    let cutIdx = Math.max(1, before - 6);
    while (cutIdx > 1 && session.messages[cutIdx].role === 'tool') cutIdx--;
    // 若切点上方是 assistant + tool_calls，且其全部 tool 响应都在 tail 中，则保持 cut 不变；
    // 否则把这个 assistant 也并入 tail，避免它在 middle 里却没有对应工具响应。
    const tailMsgs = session.messages.slice(cutIdx);
    const middle = session.messages.slice(1, cutIdx);
    // 再保险：丢弃 tail 顶端找不到对应 assistant.tool_calls 的孤儿 tool 消息
    const tailIds = new Set();
    for (const m of tailMsgs) if (m.role === 'assistant' && m.tool_calls) for (const tc of m.tool_calls) tailIds.add(tc.id);
    const cleanTail = tailMsgs.filter(m => m.role !== 'tool' || tailIds.has(m.tool_call_id));
    const summary = middle.map(x => {
      if (x.role === 'user')      return `[用户] ${(typeof x.content === 'string' ? x.content : JSON.stringify(x.content)).slice(0, 200)}`;
      if (x.role === 'assistant') return `[助手] ${(x.content || '').toString().slice(0, 300)}` + (x.tool_calls ? ` (调用 ${x.tool_calls.map(t => t.function?.name).join(',')})` : '');
      if (x.role === 'tool')      return `[工具返回] ${String(x.content || '').slice(0, 160)}`;
      return '';
    }).filter(Boolean).join('\n');
    session.messages = [sys, { role: 'user', content: '以下是之前会话的压缩总结，请继续任务：\n' + summary }, ...cleanTail];
  }
  if (ws) try { ws.send(JSON.stringify({ type: 'term', line: `[自动压缩上下文：${(total/1024).toFixed(0)} KB 超限，消息 ${before} → ${session.messages.length}] `})); } catch {}
  return true;
}

// glob → RegExp（支持 **、*、?）
function globToRegExp(glob) {
  let re = '^'; let i = 0;
  while (i < glob.length) {
    const c = glob[i];
    if (c === '*') {
      if (glob[i+1] === '*') { re += '.*'; i += 2; if (glob[i] === '/') i++; }
      else { re += '[^/]*'; i++; }
    } else if (c === '?') { re += '[^/]'; i++; }
    else if ('.+^$|()[]{}\\'.includes(c)) { re += '\\' + c; i++; }
    else { re += c; i++; }
  }
  re += '$';
  return new RegExp(re);
}

const TOOLS = [
  { type: 'function', function: { name: 'list_dir', description: '列出目录内容', parameters: { type: 'object', properties: { path: { type: 'string' } } } } },
  { type: 'function', function: { name: 'read_file', description: '读取文本文件。可传 start_line/end_line (1-indexed, 闭区间) 只读一部分。', parameters: { type: 'object', properties: { path: { type: 'string' }, start_line: { type: 'number' }, end_line: { type: 'number' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'write_file', description: '写入/创建文件', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'edit_file', description: '在文件中精确替换字符串。old_str 必须唯一匹配。', parameters: { type: 'object', properties: { path: { type: 'string' }, old_str: { type: 'string' }, new_str: { type: 'string' } }, required: ['path', 'old_str', 'new_str'] } } },
  { type: 'function', function: { name: 'multi_edit', description: '对同一个文件依次应用多个 edit_file 替换（原子：任一失败全部不写入）。快于多次调 edit_file。', parameters: { type: 'object', properties: { path: { type: 'string' }, edits: { type: 'array', items: { type: 'object', properties: { old_str: { type: 'string' }, new_str: { type: 'string' } }, required: ['old_str','new_str'] } } }, required: ['path','edits'] } } },
  { type: 'function', function: { name: 'glob', description: '按通配符查找文件（支持 ** 、 *）。例：**/*.py 、 src/**/*.ts。', parameters: { type: 'object', properties: { pattern: { type: 'string' }, path: { type: 'string' } }, required: ['pattern'] } } },
  { type: 'function', function: { name: 'grep_search', description: '正则搜索代码（返回文件:行号: 内容）', parameters: { type: 'object', properties: { pattern: { type: 'string' }, path: { type: 'string' } }, required: ['pattern'] } } },
  { type: 'function', function: { name: 'run_command', description: '执行 shell 命令（用户审批）。命令中的 python/python3/pip/jupyter 会被自动替换为用户在顶部选中的解释器。', parameters: { type: 'object', properties: { command: { type: 'string' }, timeout_ms: { type: 'number' } }, required: ['command'] } } },
  { type: 'function', function: { name: 'update_todos', description: '维护待办清单', parameters: { type: 'object', properties: { items: { type: 'array', items: { type: 'object', properties: { text: { type: 'string' }, done: { type: 'boolean' } }, required: ['text'] } } }, required: ['items'] } } },
  { type: 'function', function: { name: 'task_complete', description: '声明任务完成', parameters: { type: 'object', properties: { summary: { type: 'string' } }, required: ['summary'] } } },
  { type: 'function', function: { name: 'web_search', description: '联网搜索。自动按优先级选用 Tavily(若 TAVILY_API_KEY) → Serper(SERPER_API_KEY) → Brave(BRAVE_API_KEY) → SearXNG(SEARXNG_URL) → DuckDuckGo HTML → Bing → Baidu。Tavily 会附带 LLM 摘要 answer。可指定 topic=news/general、time_range=day|week|month|year。', parameters: { type: 'object', properties: { query: { type: 'string' }, top_k: { type: 'number' }, topic: { type: 'string', enum: ['general','news'] }, time_range: { type: 'string', enum: ['day','week','month','year'] }, include_answer: { type: 'boolean', description: '默认 true（仅 Tavily 生效）' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'paper_search', description: '【学术】文献检索（合并 Semantic Scholar + arXiv，去重按 DOI/标题；无需 API Key）。返回 title / authors / year / venue / citationCount / abstract / DOI / openAccessPdf 链接，按引用数与年份综合排序。比 web_search 更适合找算法原文。', parameters: { type: 'object', properties: { query: { type: 'string' }, top_k: { type: 'number' }, year: { type: 'string', description: '如 2020-2025 / 2023- / -2018' }, open_access_only: { type: 'boolean' }, fields_of_study: { type: 'string', description: 'Semantic Scholar 字段过滤，如 Physics,Engineering,Computer Science（逗号分隔）' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'paper_fetch', description: '【学术】按 ID 取论文详情（abstract + tldr + references 列表 + OA PDF 链接）。id 可为 DOI:10.x/x、ARXIV:2106.15928、Semantic Scholar paperId（40 位 hex），或裸 arXiv id。可选 download=true 把 OA PDF 下载到 downloads/papers/ 便于后续 read_paper。', parameters: { type: 'object', properties: { id: { type: 'string' }, download: { type: 'boolean' }, max_refs: { type: 'number' } }, required: ['id'] } } },
  { type: 'function', function: { name: 'read_paper', description: '【学术】比 read_document 更强：先 read_document 拿全文，再做章节切分与关键信息抽取——Abstract / Introduction / Methods / Equations / Results / Conclusion / References。返回结构化 Markdown。可选 focus 定位特定章节段落。', parameters: { type: 'object', properties: { path: { type: 'string' }, focus: { type: 'string' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'vision_analyze', description: '【视觉】对一张或多张本地/网络图片做"高清细看"——以 detail=high 把图片发给多模态模型并按 question 抽取结构化信息。适用于：读图表数值、读公式、读表格、读流程图。images 是路径数组（相对工作区或绝对，或 http(s) URL）。', parameters: { type: 'object', properties: { images: { type: 'array', items: { type: 'string' } }, question: { type: 'string' }, max_tokens: { type: 'number' } }, required: ['images','question'] } } },
  { type: 'function', function: { name: 'image_search', description: '【图片搜索】专门搜图片（Bing Images），返回缩略图+原图 URL+来源页。结果会自动出现在右侧"图片库"面板中可双击大图、可下载。适合"找论文里 XX 现象的图"。', parameters: { type: 'object', properties: { query: { type: 'string' }, top_k: { type: 'number', description: '默认 12，最多 30' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'fetch_url', description: '拉取网页可读文本；自动追加图片链接列表（最多前 20 张）和正文图片描述。', parameters: { type: 'object', properties: { url: { type: 'string' }, max_chars: { type: 'number' }, with_images: { type: 'boolean' } }, required: ['url'] } } },
  { type: 'function', function: { name: 'read_document', description: '读取本地 PDF/DOCX/PPTX/XLSX/图片(OCR)/纯文本 文件，返回提取出的纯文本内容。需用户已配置 Python 解释器。', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'request_user_digitize', description: '【V3 手动标注】当你从论文图表/截图里需要精准的 (x,y) 数据点作为参考或对比基准，但大模型抽不准时调用。会在用户界面弹出手动标注仪（类 WebPlotDigitizer），用户点何点为数据点后保存为 CSV，返回该 CSV 的路径供后续读取。阻塞等待，默认超时 600s。', parameters: { type: 'object', properties: { image_path: { type: 'string', description: '可选，工作区内的图片路径；传了会预加载到标注仪。不传则让用户自己选图。' }, hint: { type: 'string', description: '给用户的提示，如 “请标 Fig.5 里 baseline 曲线上 8–10 个点”' }, name: { type: 'string', description: '保存 CSV 的名字（默认 plot）' }, timeout_sec: { type: 'number', description: '等待用户完成的超时（秒），默认 600' } }, required: [] } } },
  { type: 'function', function: { name: 'download_file', description: '从 URL 下载到本地（默认到 downloads/ 目录）。可用于保存网页里的图片或 PDF/zip 等。', parameters: { type: 'object', properties: { url: { type: 'string' }, save_as: { type: 'string' } }, required: ['url'] } } },
  { type: 'function', function: { name: 'sim_render', description: '【仿真】用 pvpython 离屏渲染一帧为 PNG 并显示到右侧。可选 field 上色、time_step 选时间步。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, field: { type: 'string', description: '上色场名（如 U / p / T）。不传则单色显示。' }, time_step: { type: 'number', description: '时间步索引（从 0 开始），或传 -1 表示最后一个。' }, azimuth: { type: 'number' }, elevation: { type: 'number' }, zoom: { type: 'number' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'sim_open_paraview', description: '【仿真】启动本机 ParaView GUI 作为独立窗口（不嵌入）。', parameters: { type: 'object', properties: { case_path: { type: 'string' } } } } },
  { type: 'function', function: { name: 'sim_run_openfoam', description: '【仿真】在算例目录执行 OpenFOAM 命令。需审批。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, command: { type: 'string' } }, required: ['case_path', 'command'] } } },
  { type: 'function', function: { name: 'foam_find_tutorial', description: '【FOAM-Beta】在 OpenFOAM 安装的 tutorials/ 中按关键字搜索算例（含 system/controlDict 的目录）。返回候选路径列表。', parameters: { type: 'object', properties: { query: { type: 'string' }, top_k: { type: 'number' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'foam_find_source', description: '【FOAM-Beta】在 OpenFOAM 源码中按关键字搜索（src/ + applications/）。kind：solver/model/bc/all。常用于查找曳力模型(WenYu/Ergun/SchillerNaumann)、湍流模型、求解器、边界条件等参考实现。', parameters: { type: 'object', properties: { query: { type: 'string' }, kind: { type: 'string', enum: ['solver','model','bc','all'] }, top_k: { type: 'number' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'foam_clone_tutorial', description: '【FOAM-Beta】把 OpenFOAM tutorials/ 下的某个算例完整复制到工作区指定目录。tutorial_path 既可以是绝对路径，也可以是相对 tutorials/ 的路径（如 multiphase/twoPhaseEulerFoam/RAS/bubbleColumn）。', parameters: { type: 'object', properties: { tutorial_path: { type: 'string' }, dest: { type: 'string', description: '相对工作区的目标目录' } }, required: ['tutorial_path', 'dest'] } } },
  { type: 'function', function: { name: 'foam_inspect_case', description: '【FOAM-Beta】检查算例：列出 0/ constant/ system/ 内容，提取每个 patch 在每个场上的边界类型 / 求解器 / 时间步 / 关键物理参数；用于确定下一步要让用户改什么。最后附上递归文件清单。', parameters: { type: 'object', properties: { case_path: { type: 'string' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'foam_run_solver_async', description: '【FOAM-Beta】启动求解器（或任何 OpenFOAM 命令）为后台作业。返回 runId 供轮询。避免主会话被长任务阻塞。需审批。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, command: { type: 'string' } }, required: ['case_path','command'] } } },
  { type: 'function', function: { name: 'foam_solver_status', description: '【FOAM-Beta】查看某个后台求解器作业的最新状态：当前Time、最近残差、log tail、是否还在跑。', parameters: { type: 'object', properties: { run_id: { type: 'string' } }, required: ['run_id'] } } },
  { type: 'function', function: { name: 'foam_solver_stop', description: '【FOAM-Beta】中止某个后台求解器作业。', parameters: { type: 'object', properties: { run_id: { type: 'string' } }, required: ['run_id'] } } },
  { type: 'function', function: { name: 'foam_stl_inspect', description: '【FOAM-Beta】读取 STL（ASCII/二进制）几何信息：三角形数、包围盒(min/max/size)、质心、体积估计、是否封闭、推荐特征长度。用于决定 blockMesh 背景域和 snappyHexMesh 加密层级。', parameters: { type: 'object', properties: { stl_path: { type: 'string' } }, required: ['stl_path'] } } },
  { type: 'function', function: { name: 'foam_mesh_plan', description: '【FOAM-Beta】基于 STL 自动生成 blockMeshDict + snappyHexMeshDict + surfaceFeaturesDict 草案：背景域按 STL bbox 外扩，cell 数依据 target_cell_size，snappy 在 STL 表面做 refinement。同时把 STL 复制到 case 的 constant/triSurface/。返回生成的文件清单与建议命令序列。需审批（会写文件）。开启 strategy=coarsen/minimal/box_stl 可在 blockMesh/snappy 重复失败后倒换档位。', parameters: { type: 'object', properties: { case_path: { type: 'string', description: '目标 case 目录（相对工作区或绝对）' }, stl_path: { type: 'string', description: 'STL 文件路径' }, target_cell_size: { type: 'number', description: '背景网格目标边长（米），默认 STL 最大尺寸/30' }, refinement_level_min: { type: 'number', description: 'snappy 表面最小加密级（默认 1）' }, refinement_level_max: { type: 'number', description: 'snappy 表面最大加密级（默认 3）' }, n_layers: { type: 'number', description: '边界层层数（默认 0=不加层）' }, location_in_mesh: { type: 'array', description: '内部点 [x,y,z]（默认取 bbox 中心向上偏移）', items: { type: 'number' } }, flow_direction: { type: 'string', enum: ['x','y','z'], description: '主流方向（决定 inlet/outlet 命名）' }, strategy: { type: 'string', enum: ['default','coarsen','minimal','box_stl'], description: '重试策略：default=默认；coarsen=第2次失败后粗化；minimal=第3次只留 castellated（无snap/layers）；box_stl=额外生成外域box STL用于纯STL组合策略' } }, required: ['case_path','stl_path'] } } },
  { type: 'function', function: { name: 'foam_mesh_box_stl', description: '【FOAM-Beta】在 case/constant/triSurface/ 下写一个 axis-aligned box STL（外域包围盒）。用于 blockMesh 反复失败后转“双 STL + snappyHexMesh”倒换策略：用 box STL 当外埌，物体 STL 当内部加密。需审批。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, bbox_min: { type: 'array', items: { type: 'number' }, description: '[xmin,ymin,zmin]（米）' }, bbox_max: { type: 'array', items: { type: 'number' }, description: '[xmax,ymax,zmax]（米）' }, name: { type: 'string', description: 'STL 名（不含 .stl，默认 domain_box）' } }, required: ['case_path','bbox_min','bbox_max'] } } },
  { type: 'function', function: { name: 'foam_residual_series', description: '【FOAM-Beta】解析后台求解器 log，返回结构化的时间步与残差时序（JSON）。LLM 用来判断收敛趋势、是否震荡、何时建议改 nNonOrthoCorrectors / 松弛因子等。', parameters: { type: 'object', properties: { run_id: { type: 'string' }, max_points: { type: 'number', description: '最多返回多少个时间步（默认 60，倒数取最新）' }, fields: { type: 'array', items: { type: 'string' }, description: '只关心的场名，例如 ["U","p","k","epsilon"]' } }, required: ['run_id'] } } },
  { type: 'function', function: { name: 'foam_compare_render', description: '【FOAM-Beta】并排渲染两个 case 的同一场同一时间步，结果以 sim_compare 消息推送到前端聊天，方便定性对比（如新模型 vs baseline / 网格无关性 / 论文复现）。', parameters: { type: 'object', properties: { case_a: { type: 'string' }, case_b: { type: 'string' }, label_a: { type: 'string' }, label_b: { type: 'string' }, field: { type: 'string' }, time_step: { type: 'string' }, azimuth: { type: 'number' }, elevation: { type: 'number' } }, required: ['case_a','case_b'] } } },
  { type: 'function', function: { name: 'foam_mesh_verify', description: '【FOAM-Beta v4.6 网格自动核对】blockMesh / snappyHexMesh 之后必走的视觉验证闭环：① 在 case 内运行 checkMesh -allTopology -allGeometry 抓 negVol/maxSkew/maxNonOrtho/aspectRatio/openCells/failed checks；② 多角度离屏渲染网格；③ 把渲染图丢给 vision_analyze 让 VLM 按硬性 checklist 判通过；返回 JSON: {pass, stage, metrics, renders, vision, suggestions}。pass=false 时 LLM 应立刻 edit_file 修 Dict 或 foam_mesh_plan(strategy=coarsen/minimal/box_stl) 倒档重试（最多 3 次）。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, stage: { type: 'string', enum: ['blockMesh','snappy','layers','final'], description: '当前在哪一关：blockMesh=刚跑完 blockMesh；snappy=刚跑完 snappyHexMesh；layers=带边界层后；final=求解前最终确认' }, ask_vision: { type: 'boolean', description: '默认 true。false 时只跑 checkMesh+渲染不调 VLM（节流）' }, n_views: { type: 'number', description: '渲染视角数 1-4，默认 2（等角 + 切片）' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'foam_stl_render', description: '【FOAM-Beta v4.6 STL 预检】在 snappyHexMesh 之前先把 STL 几何渲染 3-4 视角，让 LLM/VLM 肉眼确认：法向朝外、是否封闭、有无破洞、bbox 比例正确。返回渲染路径与 bbox/三角形数等元数据。比 foam_stl_inspect 多了视觉一层。', parameters: { type: 'object', properties: { stl_path: { type: 'string' }, n_views: { type: 'number', description: '默认 3：front/top/iso' } }, required: ['stl_path'] } } },
  { type: 'function', function: { name: 'foam_patch_diff', description: '【FOAM-Beta v4.6 patch 对照】解析 constant/polyMesh/boundary 给出当前所有 patch 名 / type / nFaces；可选传 snapshot_before（上一次的 patch 列表 JSON 字符串）做 diff，输出新增/丢失/类型变化。常用于 snappy 之后核对是否把 STL 切成了正确的命名 patch（inlet/outlet/walls），以及 createPatch 改名是否成功。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, snapshot_before: { type: 'string', description: '可选：上一次 foam_patch_diff 返回里的 patches JSON，传入做 diff' } }, required: ['case_path'] } } },

  // ---------- MFIX Beta ----------
  { type: 'function', function: { name: 'mfix_find_tutorial', description: '【MFIX-Beta】在 MFIX 安装目录的 tutorials/（含 mfix.dat 或 *.mfx 的子目录）中按关键字搜索算例。返回候选路径列表。', parameters: { type: 'object', properties: { query: { type: 'string' }, top_k: { type: 'number' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'mfix_clone_tutorial', description: '【MFIX-Beta】把 MFIX tutorials/ 下的某个算例完整复制到工作区。tutorial_path 既可绝对，也可相对 tutorials/。', parameters: { type: 'object', properties: { tutorial_path: { type: 'string' }, dest: { type: 'string', description: '相对工作区的目标目录' } }, required: ['tutorial_path','dest'] } } },
  { type: 'function', function: { name: 'mfix_inspect_case', description: '【MFIX-Beta】检查 MFIX 算例：解析 mfix.dat 或 *.mfx，提取关键 keyword（RUN_TYPE / TIME / DT / GEOMETRY / IMAX-JMAX-KMAX / MMAX / 边界条件 BC_* / 初始条件 IC_*），并附递归文件清单。', parameters: { type: 'object', properties: { case_path: { type: 'string' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'mfix_run_solver_async', description: '【MFIX-Beta】启动 mfixsolver（或任何 MFIX 命令）为后台作业。返回 runId 供轮询。需审批。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, command: { type: 'string', description: '默认为 mfixsolver；可传 mpirun -np N mfixsolver / mfixsolver -f xxx.mfx 等' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'mfix_solver_status', description: '【MFIX-Beta】查看 MFIX 后台作业最新状态：当前 Time、最近残差行、log tail、是否还在跑。', parameters: { type: 'object', properties: { run_id: { type: 'string' } }, required: ['run_id'] } } },
  { type: 'function', function: { name: 'mfix_solver_stop', description: '【MFIX-Beta】中止某个 MFIX 后台作业。', parameters: { type: 'object', properties: { run_id: { type: 'string' } }, required: ['run_id'] } } },

  // ---------- LBM Beta ----------
  { type: 'function', function: { name: 'lbm_find_tutorial', description: '【LBM-Beta】在用户提供的 LBM 算例根目录（lbmTutorialRoot）中按关键字搜索算例（任何含 README / *.py / *.cpp / input.* / params.* 的子目录都算候选）。返回候选路径列表。', parameters: { type: 'object', properties: { query: { type: 'string' }, top_k: { type: 'number' } }, required: ['query'] } } },
  { type: 'function', function: { name: 'lbm_clone_tutorial', description: '【LBM-Beta】把 LBM 教程根下的某个算例完整复制到工作区。', parameters: { type: 'object', properties: { tutorial_path: { type: 'string' }, dest: { type: 'string' } }, required: ['tutorial_path','dest'] } } },
  { type: 'function', function: { name: 'lbm_inspect_case', description: '【LBM-Beta】检查 LBM 算例：列出文件清单 + 自动识别算法骨架（D2Q9/D3Q19/D3Q27、BGK/MRT/TRT/Cumulant/Regularized、是否多相/多相场、是否含 collision 函数 / propagate / equilibrium），并提取 README / params 中关键参数。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, algorithm: { type: 'string', description: '用户已知的算法名提示（可选，如 "D3Q19 MRT" / "Palabos BGK"）' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'lbm_run_async', description: '【LBM-Beta】在算例目录后台执行任意命令（如 python3 main.py / ./lb / mpirun -np 4 ./lb）。返回 runId。需审批。', parameters: { type: 'object', properties: { case_path: { type: 'string' }, command: { type: 'string', description: '不传则使用 SETTINGS.lbmRunCmd 默认模板' } }, required: ['case_path'] } } },
  { type: 'function', function: { name: 'lbm_solver_status', description: '【LBM-Beta】查看 LBM 后台作业状态：log tail、提取的时间步与误差/macroscopic 指标（适配通用 print 风格）。', parameters: { type: 'object', properties: { run_id: { type: 'string' } }, required: ['run_id'] } } },
  { type: 'function', function: { name: 'lbm_solver_stop', description: '【LBM-Beta】中止某个 LBM 后台作业。', parameters: { type: 'object', properties: { run_id: { type: 'string' } }, required: ['run_id'] } } }
];

// 工具分组（用于 UI 开关；编辑类始终开启）
const TOOL_GROUPS = {
  edit: ['list_dir','read_file','write_file','edit_file','multi_edit','glob','grep_search','update_todos','task_complete'],  // 常亮
  shell: ['run_command'],
  web: ['web_search','fetch_url','download_file','image_search','paper_search','paper_fetch'],
  doc: ['read_document','read_paper','vision_analyze','request_user_digitize'],
  sim: ['sim_render','sim_open_paraview','sim_run_openfoam'],
  foam: ['foam_find_tutorial','foam_find_source','foam_clone_tutorial','foam_inspect_case','foam_run_solver_async','foam_solver_status','foam_solver_stop','foam_stl_inspect','foam_mesh_plan','foam_mesh_box_stl','foam_residual_series','foam_compare_render','foam_mesh_verify','foam_stl_render','foam_patch_diff','read_document'],
  mfix: ['mfix_find_tutorial','mfix_clone_tutorial','mfix_inspect_case','mfix_run_solver_async','mfix_solver_status','mfix_solver_stop','sim_render','sim_open_paraview','read_document'],
  lbm:  ['lbm_find_tutorial','lbm_clone_tutorial','lbm_inspect_case','lbm_run_async','lbm_solver_status','lbm_solver_stop','sim_render','read_document']
};
const DEFAULT_ENABLED = new Set([...TOOL_GROUPS.edit, ...TOOL_GROUPS.shell, ...TOOL_GROUPS.web, ...TOOL_GROUPS.doc]);
function filterTools(enabled) { return TOOLS.filter(t => enabled.has(t.function.name)); }

const NEEDS_APPROVAL = new Set(['run_command', 'sim_run_openfoam', 'foam_run_solver_async', 'foam_mesh_plan', 'foam_mesh_box_stl', 'mfix_run_solver_async', 'lbm_run_async']);
const MODIFYING = new Set(['write_file', 'edit_file']);

function safePath(p) {
  const target = path.resolve(WORKSPACE, p || '.');
  const rel = path.relative(WORKSPACE, target);
  if (rel.startsWith('..') || path.isAbsolute(rel)) throw new Error(`路径越界：${p}`);
  return target;
}

function broadcastTodos(ws) { const s = sessions.get(ws); if (!s) return; ws.send(JSON.stringify({ type: 'todos', list: s.todos })); }
function broadcastEdits(ws) { const s = sessions.get(ws); if (!s) return; ws.send(JSON.stringify({ type: 'pending_edits', list: s.pendingEdits })); }

function addPendingEdit(session, edit) {
  session.pendingEdits.push(edit);
  if (session.currentCheckpoint && !(edit.path in session.currentCheckpoint.files))
    session.currentCheckpoint.files[edit.path] = edit.oldContent;
}

// ====================== ParaView 窗口投影（核心新功能） ======================
//
// 思路：spawn 真正的 paraview GUI，记录其 PID，每隔 N ms 截取该窗口区域到 PNG
// 通过 WebSocket 推送给前端显示。Linux/Windows 各走一套实现。
//
const PV_STATE = { proc: null, pid: null, captureTimer: null, lastFrame: null, subscribers: new Set(), fps: 4, lastError: null, errorCount: 0, ready: false };

function pvBroadcast(obj) { const msg = JSON.stringify(obj); for (const ws of PV_STATE.subscribers) if (ws.readyState === 1) ws.send(msg); }

async function captureWindowsWindow(pid) {
  const tmp = path.join(os.tmpdir(), `pv_${process.pid}.png`);
  const outEsc = tmp.replaceAll("'", "''");
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
if (-not ([System.Management.Automation.PSTypeName]'CMaxW').Type) {
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class CMaxW {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc p, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint flags);
  [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint cmd);
  [DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L,T,R,B; }
}
"@
}
function Find-PvWindow($targetPid) {
  $found = $null; $best = 0
  $cb = [CMaxW+EnumProc]{ param($h,$l)
    $opid = 0
    [void][CMaxW]::GetWindowThreadProcessId($h, [ref]$opid)
    if ($opid -ne $targetPid) { return $true }
    if (-not [CMaxW]::IsWindowVisible($h)) { return $true }
    if ([CMaxW]::GetParent($h) -ne [IntPtr]::Zero) { return $true }
    $tl = [CMaxW]::GetWindowTextLength($h)
    $r = New-Object CMaxW+RECT
    [void][CMaxW]::GetWindowRect($h, [ref]$r)
    $area = ($r.R - $r.L) * ($r.B - $r.T)
    # 取面积最大的可见顶层窗口（避开 splash / 子对话）
    $score = $area + ($tl * 100)
    if ($script:best -lt $score) { $script:best = $score; $script:found = $h }
    return $true
  }
  $script:best = 0; $script:found = [IntPtr]::Zero
  [void][CMaxW]::EnumWindows($cb, [IntPtr]::Zero)
  return $script:found
}
try {
  $h = Find-PvWindow ${pid}
  if ($h -eq $null -or $h -eq [IntPtr]::Zero) {
    # 兜底：尝试子进程
    Get-Process | Where-Object { $_.Parent.Id -eq ${pid} -or $_.Id -eq ${pid} } | ForEach-Object {
      if ($h -eq $null -or $h -eq [IntPtr]::Zero) {
        $sub = Find-PvWindow $_.Id
        if ($sub -ne $null -and $sub -ne [IntPtr]::Zero) { $h = $sub }
      }
    }
  }
  if ($h -eq $null -or $h -eq [IntPtr]::Zero) { Write-Error 'NO_WINDOW'; exit 2 }
  if ([CMaxW]::IsIconic($h)) { [void][CMaxW]::ShowWindowAsync($h, 9); Start-Sleep -Milliseconds 200 }
  $r = New-Object CMaxW+RECT
  [void][CMaxW]::GetWindowRect($h, [ref]$r)
  $w = $r.R - $r.L; $hh = $r.B - $r.T
  if ($w -le 0 -or $hh -le 0) { Write-Error 'ZERO_SIZE'; exit 3 }
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $hdc = $g.GetHdc()
  # PW_RENDERFULLCONTENT = 0x00000002（Win8.1+，能抓 OpenGL/DWM 合成内容）
  $ok = [CMaxW]::PrintWindow($h, $hdc, 0x2)
  $g.ReleaseHdc($hdc)
  if (-not $ok) {
    # 兜底：屏幕拷贝
    $g.CopyFromScreen($r.L, $r.T, 0, 0, (New-Object System.Drawing.Size $w, $hh))
  }
  $g.Dispose()
  $bmp.Save('${outEsc}', [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
} catch { Write-Error $_; exit 9 }
`;
  return await new Promise((resolve, reject) => {
    const ps = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', '-'], { windowsHide: true });
    let err = '';
    ps.stderr.on('data', d => err += d);
    const to = setTimeout(() => { try { ps.kill(); } catch {} }, 4000);
    ps.on('close', async (code) => {
      clearTimeout(to);
      if (code !== 0) {
        const tag = code === 2 ? '未找到顶层窗口' : code === 3 ? '窗口尺寸为 0' : 'PowerShell 异常';
        return reject(new Error(`${tag} (code=${code}) ${err.replace(/\s+/g,' ').slice(0,200)}`));
      }
      try { resolve(await fs.readFile(tmp)); } catch (e) { reject(e); }
    });
    ps.on('error', reject);
    ps.stdin.end(script);
  });
}

async function captureLinuxWindow(pid) {
  const tmp = path.join(os.tmpdir(), `pv_${process.pid}.png`);
  // 用 xdotool 找窗口 → import 抓
  const wid = await new Promise((res) => {
    const p = spawn('xdotool', ['search', '--pid', String(pid)]);
    let o = ''; p.stdout.on('data', d => o += d);
    p.on('close', () => { const ids = o.trim().split('\n').filter(Boolean); res(ids[ids.length - 1] || null); });
    p.on('error', () => res(null));
  });
  if (!wid) throw new Error('xdotool 找不到 ParaView 窗口（请安装 xdotool 与 imagemagick）');
  await new Promise((res, rej) => {
    const p = spawn('import', ['-window', wid, tmp]);
    p.on('close', c => c === 0 ? res() : rej(new Error('import 失败')));
    p.on('error', rej);
  });
  return await fs.readFile(tmp);
}

async function captureParaViewFrame() {
  if (!PV_STATE.pid) return null;
  try {
    const buf = IS_WIN ? await captureWindowsWindow(PV_STATE.pid) : await captureLinuxWindow(PV_STATE.pid);
    if (PV_STATE.lastError) { PV_STATE.lastError = null; PV_STATE.errorCount = 0; pvBroadcast({ type: 'term', line: '[ParaView 投影已恢复]' }); }
    return 'data:image/png;base64,' + buf.toString('base64');
  } catch (e) {
    const msg = String(e.message || e).slice(0, 240);
    if (msg !== PV_STATE.lastError) {
      PV_STATE.lastError = msg;
      PV_STATE.errorCount = 0;
      pvBroadcast({ type: 'term', line: '[ParaView 抓帧失败] ' + msg });
      pvBroadcast({ type: 'sim_error', message: msg });
    } else {
      PV_STATE.errorCount++;
      if (PV_STATE.errorCount === 5) pvBroadcast({ type: 'term', line: '[ParaView 抓帧持续失败 ×5，已静音同类报错]' });
    }
    return null;
  }
}

function startParaViewCapture() {
  if (PV_STATE.captureTimer) return;
  const interval = Math.max(150, Math.round(1000 / PV_STATE.fps));
  PV_STATE.captureTimer = setInterval(async () => {
    if (PV_STATE.subscribers.size === 0) return;
    const frame = await captureParaViewFrame();
    if (!frame) return;
    PV_STATE.lastFrame = frame;
    const msg = JSON.stringify({ type: 'sim_frame', dataUrl: frame });
    for (const ws of PV_STATE.subscribers) if (ws.readyState === 1) ws.send(msg);
  }, interval);
}
function stopParaViewCapture() {
  if (PV_STATE.captureTimer) { clearInterval(PV_STATE.captureTimer); PV_STATE.captureTimer = null; }
}

async function launchParaView(casePath) {
  if (!SETTINGS.paraviewExe) throw new Error('未配置 ParaView 主程序路径，请到 ⚙ 设置中填入（如 paraview.exe 或 /usr/bin/paraview）');
  // 已在运行 → 重用
  if (PV_STATE.proc && !PV_STATE.proc.killed) {
    return { reused: true, pid: PV_STATE.pid };
  }
  const args = [];
  if (casePath) {
    let target = path.isAbsolute(casePath) ? casePath : path.resolve(WORKSPACE, casePath);
    try {
      const stat = await fs.stat(target);
      if (stat.isDirectory()) {
        const foam = path.join(target, 'case.foam');
        try { await fs.access(foam); } catch { await fs.writeFile(foam, '', 'utf8'); }
        target = foam;
      }
    } catch {}
    args.push(`--data=${target}`);
  }
  const proc = spawn(SETTINGS.paraviewExe, args, { detached: false, stdio: 'ignore', windowsHide: false });
  PV_STATE.proc = proc; PV_STATE.pid = proc.pid; PV_STATE.ready = false; PV_STATE.lastError = null; PV_STATE.errorCount = 0;
  proc.on('exit', () => { PV_STATE.proc = null; PV_STATE.pid = null; PV_STATE.lastFrame = null; PV_STATE.ready = false;
    for (const ws of PV_STATE.subscribers) if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'sim_closed' })); });
  // 等窗口就位（最多 12s）
  pvBroadcast({ type: 'term', line: `[ParaView 启动中 PID=${proc.pid}，等待窗口…]` });
  (async () => {
    for (let i = 0; i < 24; i++) {
      await new Promise(r => setTimeout(r, 500));
      if (!PV_STATE.proc) return;
      try {
        const buf = IS_WIN ? await captureWindowsWindow(PV_STATE.pid) : await captureLinuxWindow(PV_STATE.pid);
        if (buf) { PV_STATE.ready = true; pvBroadcast({ type: 'term', line: '[ParaView 窗口已就位，开始投影]' }); return; }
      } catch {}
    }
    pvBroadcast({ type: 'term', line: '[警告] 12s 内未抓到 ParaView 窗口；将持续重试。可手动把 ParaView 窗口拖到前台一次。' });
  })();
  startParaViewCapture();
  return { reused: false, pid: proc.pid };
}

function killParaView() {
  if (PV_STATE.proc) { try { PV_STATE.proc.kill(); } catch {} }
  stopParaViewCapture();
}

// ====================== 跨平台交互终端（每会话一个 shell） ======================
function spawnShell(cwd) {
  if (IS_WIN) return spawn(process.env.COMSPEC || 'cmd.exe', ['/Q'], { cwd, env: process.env });
  return spawn(process.env.SHELL || '/bin/bash', ['-i'], { cwd, env: process.env });
}

// ====================== OpenFOAM 命令（agent 调用） ======================
async function runOpenFoam({ casePath, command }, ws) {
  const cd = path.isAbsolute(casePath) ? casePath : path.resolve(WORKSPACE, casePath);
  let shell, shellArgs;
  if (IS_WIN && SETTINGS.openfoamBash) {
    shell = 'cmd.exe';
    shellArgs = ['/c', `call "${SETTINGS.openfoamBash}" && cd /d "${cd}" && ${command}`];
  } else if (IS_WIN) {
    shell = 'cmd.exe'; shellArgs = ['/c', `cd /d "${cd}" && ${command}`];
  } else {
    // Linux/Mac：优先用用户设置的 openfoamBash，其次 $FOAM_BASH，再试从 foamRoot/etc/bashrc 推断
    let bashrc = SETTINGS.openfoamBash || '';
    if (!bashrc && SETTINGS.foamRoot) {
      const cand = path.join(SETTINGS.foamRoot, 'etc', 'bashrc');
      try { if ((await fs.stat(cand)).isFile()) bashrc = cand; } catch {}
    }
    const sourceLine = bashrc ? `source "${bashrc}"` : `source "$FOAM_BASH" 2>/dev/null || true`;
    shell = 'bash'; shellArgs = ['-c', `cd "${cd}" && (${sourceLine}); ${command}`];
  }
  return await new Promise((resolve) => {
    ws.send(JSON.stringify({ type: 'term', line: `$ [OF] ${command}  (${cd})` }));
    const child = spawn(shell, shellArgs, { cwd: cd });
    let out = '';
    const onData = d => { const s = d.toString(); out += s; s.split(/\r?\n/).forEach(l => l && ws.send(JSON.stringify({ type: 'term', line: l }))); };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    const t = setTimeout(() => { try { child.kill(); } catch {} }, 600000);
    child.on('close', code => { clearTimeout(t); ws.send(JSON.stringify({ type: 'term', line: `[退出码 ${code}]` })); resolve(`[退出码 ${code}]\n${out.slice(0, 50000)}`); });
    child.on('error', err => { clearTimeout(t); resolve(`[启动失败] ${err.message}`); });
  });
}

// ====================== OpenFOAM Beta：教程/源码/克隆/检查 ======================
function foamRoot() {
  const r = SETTINGS.foamRoot && String(SETTINGS.foamRoot).trim();
  if (!r) throw new Error('未设置 OpenFOAM 根目录。请在右侧 "OpenFOAM (Beta)" 面板填写，或 POST /api/foam/config {root}');
  return r;
}
async function pathExists(p) { try { await fs.access(p); return true; } catch { return false; } }

// 递归走目录，回调 (relPath, absPath, dirent) for file/dir
async function walkDir(root, onEntry, opts = {}) {
  const maxDepth = opts.maxDepth ?? 8;
  const skip = new Set(['.git', '.svn', 'node_modules', 'doc', 'doxygen', '.lib-openmpi', 'lnInclude', 'linux64GccDPInt32Opt', 'linux64GccDPInt64Opt', 'linux64Gcc', '.idea']);
  const stack = [{ dir: root, depth: 0 }];
  while (stack.length) {
    const { dir, depth } = stack.pop();
    let ents = [];
    try { ents = await fs.readdir(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of ents) {
      if (skip.has(e.name)) continue;
      const abs = path.join(dir, e.name);
      const rel = path.relative(root, abs);
      try {
        const stop = await onEntry(rel, abs, e);
        if (stop === 'stop') return;
      } catch {}
      if (e.isDirectory() && depth < maxDepth) stack.push({ dir: abs, depth: depth + 1 });
    }
  }
}

async function foamFindTutorial(query, topK = 12) {
  const root = foamRoot();
  const tutDir = path.join(root, 'tutorials');
  if (!await pathExists(tutDir)) throw new Error(`未找到 tutorials/ 目录：${tutDir}`);
  const q = String(query || '').toLowerCase().split(/[\s,/]+/).filter(Boolean);
  const hits = [];
  await walkDir(tutDir, async (rel, abs, e) => {
    if (!e.isDirectory()) return;
    // case 目录的判定：含 system/controlDict
    if (await pathExists(path.join(abs, 'system', 'controlDict'))) {
      const lower = rel.toLowerCase().replace(/\\/g, '/');
      let score = 0;
      for (const t of q) if (lower.includes(t)) score += 10;
      // 每段命中加权
      const segs = lower.split('/');
      for (const t of q) for (const s of segs) if (s === t) score += 5;
      if (q.length === 0 || score > 0) hits.push({ rel: rel.replace(/\\/g, '/'), abs, score });
      return; // 不再深入 case 内部找子 case
    }
  }, { maxDepth: 8 });
  hits.sort((a, b) => b.score - a.score);
  const top = hits.slice(0, topK);
  if (!top.length) return `未找到匹配教程：${query}\n建议在 ${tutDir} 下手动浏览。`;
  return `[foam_find_tutorial] "${query}" → ${top.length} 条候选（按相关度）：\n` +
    top.map((h, i) => `${i+1}. ${h.rel}\n   绝对路径：${h.abs}`).join('\n');
}

async function foamFindSource(query, kind = 'all', topK = 12) {
  const root = foamRoot();
  const q = String(query || '').toLowerCase();
  if (!q) throw new Error('query 必填');
  // 选搜索根
  const roots = [];
  if (kind === 'solver' || kind === 'all') roots.push(path.join(root, 'applications', 'solvers'));
  if (kind === 'model' || kind === 'all')  roots.push(path.join(root, 'src'));
  if (kind === 'bc' || kind === 'all')     roots.push(path.join(root, 'src', 'finiteVolume', 'fields', 'fvPatchFields'));
  if (kind === 'all') roots.push(path.join(root, 'applications', 'utilities'));
  const hits = [];
  for (const base of roots) {
    if (!await pathExists(base)) continue;
    await walkDir(base, async (rel, abs, e) => {
      if (!e.isFile()) return;
      const name = e.name;
      const ext = path.extname(name).toLowerCase();
      if (!['.h', '.hpp', '.c', '.cpp', '.cxx', '.h.in', ''].includes(ext) && !['files','options'].includes(name)) return;
      const lower = name.toLowerCase();
      let score = 0;
      if (lower.includes(q)) score += 10;
      // 文件名片段精确匹配（大小写不敏感）
      const baseName = path.basename(name, ext).toLowerCase();
      if (baseName === q) score += 30;
      if (score > 0) hits.push({ rel: path.relative(root, abs).replace(/\\/g, '/'), abs, score, base: path.basename(base) });
    }, { maxDepth: 10 });
  }
  hits.sort((a, b) => b.score - a.score);
  const top = hits.slice(0, topK);
  if (!top.length) return `未找到匹配源码：${query} (kind=${kind})`;
  return `[foam_find_source] "${query}" kind=${kind} → ${top.length} 条候选：\n` +
    top.map((h, i) => `${i+1}. [${h.base}] ${h.rel}\n   绝对路径：${h.abs}`).join('\n');
}

async function foamCloneTutorial(tutorialPath, dest) {
  const root = foamRoot();
  if (!tutorialPath || !dest) throw new Error('tutorial_path 和 dest 必填');
  let src = tutorialPath;
  if (!path.isAbsolute(src)) src = path.join(root, 'tutorials', tutorialPath);
  if (!await pathExists(src)) throw new Error(`tutorial 不存在：${src}`);
  if (!await pathExists(path.join(src, 'system', 'controlDict'))) {
    return `警告：${src} 看起来不是一个 case 目录（缺 system/controlDict），未复制。请先用 foam_find_tutorial 定位到具体 case。`;
  }
  const target = safePath(dest);
  await fs.mkdir(target, { recursive: true });
  // 用 fs.cp（Node 16.7+）递归复制
  await fs.cp(src, target, { recursive: true, force: false, errorOnExist: false });
  return `已复制 tutorial：\n  源：${src}\n  目标：${path.relative(WORKSPACE, target)}\n建议下一步：foam_inspect_case("${path.relative(WORKSPACE, target)}")`;
}

// 解析 boundaryField { patch { type X; ... } }
function parseBoundaryField(text) {
  const out = {};
  const m = text.match(/boundaryField\s*\{([\s\S]*)\}/);
  if (!m) return out;
  const body = m[1];
  // 简化：找形如 patchName\s*{...} 的块（一层大括号匹配）
  let i = 0;
  while (i < body.length) {
    // 跳空白与注释
    while (i < body.length && /[\s\n\r]/.test(body[i])) i++;
    if (body[i] === '/' && body[i+1] === '/') { while (i < body.length && body[i] !== '\n') i++; continue; }
    if (body[i] === '/' && body[i+1] === '*') { i += 2; while (i < body.length && !(body[i] === '*' && body[i+1] === '/')) i++; i += 2; continue; }
    if (i >= body.length) break;
    // 读 patch 名
    const nameMatch = body.slice(i).match(/^([A-Za-z_][\w\.]*)/);
    if (!nameMatch) { i++; continue; }
    const pname = nameMatch[1];
    i += nameMatch[0].length;
    while (i < body.length && /[\s\n\r]/.test(body[i])) i++;
    if (body[i] !== '{') continue;
    // 一层大括号匹配
    let depth = 1; i++; const start = i;
    while (i < body.length && depth) { if (body[i] === '{') depth++; else if (body[i] === '}') depth--; if (depth) i++; }
    const block = body.slice(start, i);
    i++; // skip '}'
    const typeM = block.match(/\btype\s+([A-Za-z][\w]*)\s*;/);
    out[pname] = { type: typeM ? typeM[1] : '?', raw: block.trim().slice(0, 200) };
  }
  return out;
}

async function foamInspectCase(casePath) {
  if (!casePath) throw new Error('case_path 必填');
  const cd = path.isAbsolute(casePath) ? casePath : safePath(casePath);
  if (!await pathExists(cd)) throw new Error(`case 不存在：${cd}`);
  const lines = [`# 算例检查：${path.relative(WORKSPACE, cd) || cd}`];
  // 1) 列三大目录
  for (const d of ['0', 'constant', 'system']) {
    const dd = path.join(cd, d);
    if (!await pathExists(dd)) { lines.push(`\n## ${d}/  (不存在)`); continue; }
    const items = (await fs.readdir(dd, { withFileTypes: true })).map(e => e.name + (e.isDirectory()?'/':''));
    lines.push(`\n## ${d}/  (${items.length} 项)\n  ${items.join('  ')}`);
  }
  // 2) controlDict 摘要
  try {
    const cd_text = await fs.readFile(path.join(cd, 'system', 'controlDict'), 'utf8');
    const grab = (k) => (cd_text.match(new RegExp(`\\b${k}\\s+([^;\\n]+);`)) || [])[1] || '';
    lines.push(`\n## system/controlDict 关键项`);
    ['application','startTime','endTime','deltaT','writeInterval','writeControl','adjustTimeStep','maxCo'].forEach(k => {
      const v = grab(k); if (v) lines.push(`  ${k} = ${v.trim()}`);
    });
  } catch {}
  // 3) constant 关键 dict
  try {
    const ents = await fs.readdir(path.join(cd, 'constant'), { withFileTypes: true });
    const keyDicts = ents.filter(e => /Properties$|^transportProperties$|^turbulenceProperties$|^thermophysicalProperties$|^phaseProperties$|^MRFProperties$/.test(e.name)).map(e => e.name);
    if (keyDicts.length) {
      lines.push(`\n## constant/ 关键 dict`);
      for (const k of keyDicts.slice(0, 6)) {
        const t = await fs.readFile(path.join(cd, 'constant', k), 'utf8').catch(()=>'');
        lines.push(`  • ${k}：` + (t.slice(0, 240).replace(/\s+/g,' ')) + (t.length > 240 ? '…' : ''));
      }
    }
  } catch {}
  // 4) 0/ boundary 摘要
  try {
    const fields = (await fs.readdir(path.join(cd, '0'))).filter(n => !n.startsWith('.'));
    if (fields.length) {
      lines.push(`\n## 0/ 边界条件矩阵`);
      const matrix = {};
      const allPatches = new Set();
      for (const f of fields) {
        try {
          const txt = await fs.readFile(path.join(cd, '0', f), 'utf8');
          matrix[f] = parseBoundaryField(txt);
          Object.keys(matrix[f]).forEach(p => allPatches.add(p));
        } catch {}
      }
      const patches = [...allPatches];
      lines.push(`  patch \\ field   ${fields.map(f => f.padEnd(8)).join(' ')}`);
      for (const p of patches) {
        lines.push(`  ${p.padEnd(15)} ${fields.map(f => (matrix[f]?.[p]?.type || '-').padEnd(8)).join(' ')}`);
      }
    }
  } catch {}
  // 5) fvSchemes / fvSolution 摘要
  for (const f of ['fvSchemes','fvSolution']) {
    try {
      const t = await fs.readFile(path.join(cd, 'system', f), 'utf8');
      lines.push(`\n## system/${f}（前 280 字符）\n  ${t.slice(0, 280).replace(/\s+/g,' ')}…`);
    } catch {}
  }
  // 6) 完整文件树（递归）
  try {
    lines.push(`\n## 完整文件清单（递归）`);
    const all = [];
    await walkDir(cd, async (rel, abs, e) => {
      if (e.isDirectory()) return;
      let sz = 0; try { sz = (await fs.stat(abs)).size; } catch {}
      all.push({ rel: rel.replaceAll('\\','/'), size: sz });
    }, { maxDepth: 6 });
    all.sort((a,b) => a.rel.localeCompare(b.rel));
    for (const x of all.slice(0, 200)) lines.push(`  ${x.rel}  (${x.size}B)`);
    if (all.length > 200) lines.push(`  …(共 ${all.length} 文件，省略 ${all.length-200} 项)`);
  } catch {}
  return lines.join('\n');
}

// ====================== OpenFOAM 求解器异步监测 ======================
const SOLVER_RUNS = new Map();  // runId -> { proc, casePath, command, log:[], started, ended, exitCode, subs:Set<ws> }

async function foamRunSolverAsync({ case_path, command }, ws) {
  if (!case_path) throw new Error('case_path 必填');
  if (!command) throw new Error('command 必填');
  const cd = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  const runId = crypto.randomBytes(4).toString('hex');
  const isWin = IS_WIN;
  let shell, shellArgs;
  if (isWin && SETTINGS.openfoamBash) {
    shell = 'cmd.exe'; shellArgs = ['/c', `call "${SETTINGS.openfoamBash}" && cd /d "${cd}" && ${command}`];
  } else if (isWin) {
    shell = 'cmd.exe'; shellArgs = ['/c', `cd /d "${cd}" && ${command}`];
  } else {
    let bashrc = SETTINGS.openfoamBash || '';
    if (!bashrc && SETTINGS.foamRoot) {
      const cand = path.join(SETTINGS.foamRoot, 'etc', 'bashrc');
      try { if ((await fs.stat(cand)).isFile()) bashrc = cand; } catch {}
    }
    const sourceLine = bashrc ? `source "${bashrc}"` : `source "$FOAM_BASH" 2>/dev/null || true`;
    shell = 'bash'; shellArgs = ['-c', `cd "${cd}" && (${sourceLine}); ${command}`];
  }
  const proc = spawn(shell, shellArgs, { cwd: cd });
  const run = { runId, proc, casePath: cd, command, log: [], started: Date.now(), ended: 0, exitCode: null, subs: new Set() };
  SOLVER_RUNS.set(runId, run);
  const onData = d => {
    const s = d.toString();
    s.split(/\r?\n/).forEach(l => { if (l) { run.log.push(l); if (run.log.length > 4000) run.log.splice(0, run.log.length - 4000); } });
    // 即时推送给订阅者
    for (const sub of run.subs) if (sub.readyState === 1) {
      sub.send(JSON.stringify({ type: 'solver_log', runId, lines: s.split(/\r?\n/).filter(Boolean) }));
    }
  };
  // 限制单行长度，避免恶意/异常进程把单行刷成 GB
  const MAX_LINE_CHARS = 2000;
  const _origPush = run.log.push.bind(run.log);
  run.log.push = function(line) { return _origPush(line.length > MAX_LINE_CHARS ? line.slice(0, MAX_LINE_CHARS) + ' …[行过长截断]' : line); };
  proc.stdout.on('data', onData); proc.stderr.on('data', onData);
  proc.on('close', code => { run.ended = Date.now(); run.exitCode = code;
    for (const sub of run.subs) if (sub.readyState === 1) sub.send(JSON.stringify({ type: 'solver_done', runId, exitCode: code }));
  });
  proc.on('error', err => { run.ended = Date.now(); run.exitCode = -1; run.log.push('[启动失败] ' + err.message); });
  if (ws) run.subs.add(ws);
  return `[已启动求解器]\n  runId: ${runId}\n  case:  ${cd}\n  cmd:   ${command}\n请用前端"求解器监测"面板订阅 runId=${runId}，或调用 foam_solver_status(${runId}) 轮询。`;
}

function foamSolverStatus(runId) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  const lines = run.log;
  const tail = lines.slice(-40);
  // 解析时间步：Time = 0.001
  let lastTime = '';
  for (let i = lines.length - 1; i >= 0; i--) {
    const m = lines[i].match(/^Time\s*=\s*([\d.eE+\-]+)/);
    if (m) { lastTime = m[1]; break; }
  }
  // 解析残差：Solving for X, Initial residual = 0.123, Final residual = 1e-7, No Iterations N
  const resLines = lines.filter(l => /Initial residual/.test(l)).slice(-20);
  const status = run.ended ? `已结束(exit=${run.exitCode})` : `运行中`;
  const dur = ((run.ended || Date.now()) - run.started) / 1000;
  return [
    `runId: ${runId}    状态: ${status}    用时: ${dur.toFixed(1)}s`,
    `case:  ${run.casePath}`,
    `cmd:   ${run.command}`,
    `当前 Time: ${lastTime || '(未识别)'}`,
    `\n--- 最近残差 (20 行) ---`,
    ...resLines,
    `\n--- 日志 tail (40 行) ---`,
    ...tail
  ].join('\n');
}

function foamSolverStop(runId) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  if (run.ended) return '[已结束]';
  try { run.proc.kill('SIGTERM'); } catch {}
  setTimeout(() => { try { run.proc.kill('SIGKILL'); } catch {} }, 3000);
  return `[已发送终止信号 runId=${runId}]`;
}

// ============== STL 几何检查（ASCII / Binary 自动识别）==============
async function foamStlInspect(stlPath) {
  if (!stlPath) throw new Error('stl_path 必填');
  const f = path.isAbsolute(stlPath) ? stlPath : path.resolve(WORKSPACE, stlPath);
  const buf = await fs.readFile(f);
  const head = buf.slice(0, Math.min(80, buf.length)).toString('ascii').toLowerCase();
  let tris = [];
  // ASCII STL：以 "solid" 开头但要确认是文本
  const looksAscii = head.startsWith('solid') && buf.includes(Buffer.from('facet normal'));
  if (looksAscii) {
    const txt = buf.toString('utf8');
    const re = /vertex\s+([\-\deE.+]+)\s+([\-\deE.+]+)\s+([\-\deE.+]+)/g;
    let m, verts = [];
    while ((m = re.exec(txt)) !== null) verts.push([+m[1], +m[2], +m[3]]);
    for (let i = 0; i + 2 < verts.length; i += 3) tris.push([verts[i], verts[i+1], verts[i+2]]);
  } else {
    // Binary：80 字节头 + uint32 数 + 50 字节/三角形
    if (buf.length < 84) throw new Error('STL 文件过小');
    const n = buf.readUInt32LE(80);
    if (84 + n * 50 !== buf.length) {
      // 兼容尾部多余字节但小于 50；至少检验 n 合理
      if (n * 50 + 84 > buf.length) throw new Error(`STL 三角形数声明 ${n} 与文件大小不一致`);
    }
    let p = 84;
    for (let i = 0; i < n; i++) {
      // 跳过法向量 12 字节
      const v0 = [buf.readFloatLE(p+12), buf.readFloatLE(p+16), buf.readFloatLE(p+20)];
      const v1 = [buf.readFloatLE(p+24), buf.readFloatLE(p+28), buf.readFloatLE(p+32)];
      const v2 = [buf.readFloatLE(p+36), buf.readFloatLE(p+40), buf.readFloatLE(p+44)];
      tris.push([v0, v1, v2]);
      p += 50;
    }
  }
  if (!tris.length) return '[STL 解析失败：未读到三角形]';
  // bbox / centroid / 面积近似 / 体积（Σ v0·(v1×v2)/6 带符号）
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  let cx = 0, cy = 0, cz = 0, area = 0, vol = 0;
  for (const t of tris) {
    for (const v of t) {
      for (let k = 0; k < 3; k++) { if (v[k] < min[k]) min[k] = v[k]; if (v[k] > max[k]) max[k] = v[k]; }
      cx += v[0]; cy += v[1]; cz += v[2];
    }
    const a = t[0], b = t[1], c = t[2];
    const ab = [b[0]-a[0], b[1]-a[1], b[2]-a[2]];
    const ac = [c[0]-a[0], c[1]-a[1], c[2]-a[2]];
    const cr = [ab[1]*ac[2]-ab[2]*ac[1], ab[2]*ac[0]-ab[0]*ac[2], ab[0]*ac[1]-ab[1]*ac[0]];
    area += 0.5 * Math.hypot(cr[0], cr[1], cr[2]);
    vol += (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0])) / 6;
  }
  const nv = tris.length * 3;
  const cent = [cx/nv, cy/nv, cz/nv];
  const size = [max[0]-min[0], max[1]-min[1], max[2]-min[2]];
  const maxDim = Math.max(...size);
  const recCell = +(maxDim / 30).toPrecision(3);
  // 单位推测：所有坐标绝对值都很小 (<0.01) 可能是米；若 1~10 m 可能是米；几十~几千更可能是 mm
  let unitGuess = '不确定';
  if (maxDim < 0.05) unitGuess = '可能为 m（极小物体）';
  else if (maxDim < 50) unitGuess = '可能为 m';
  else if (maxDim < 5000) unitGuess = '可能为 mm（建议 surfaceTransformPoints -scale 0.001 转 m）';
  return JSON.stringify({
    type: looksAscii ? 'ascii' : 'binary',
    file: path.relative(WORKSPACE, f) || f,
    triangles: tris.length,
    bbox_min: min.map(x => +x.toPrecision(6)),
    bbox_max: max.map(x => +x.toPrecision(6)),
    bbox_size: size.map(x => +x.toPrecision(6)),
    centroid: cent.map(x => +x.toPrecision(6)),
    surface_area: +area.toPrecision(6),
    signed_volume: +vol.toPrecision(6),
    closed_estimate: Math.abs(vol) > 1e-9 ? '近似封闭' : '可能不封闭',
    unit_guess: unitGuess,
    recommend_cell_size: recCell,
    recommend_blockmesh_padding: +(maxDim * 1.5).toPrecision(3),
    recommend_location_in_mesh: [
      +(cent[0]).toPrecision(4),
      +(cent[1]).toPrecision(4),
      +(max[2] + size[2] * 0.1).toPrecision(4)
    ]
  }, null, 2);
}

// ============== 自动生成 blockMesh + snappyHexMesh + surfaceFeatures 草案 ==============
// strategy 档位：default | coarsen | minimal | box_stl
//   coarsen  : cell_size×1.5, max_level-1, n_layers=0       — 第 2 次失败后尝试
//   minimal  : cell_size×2,  max_level=1, snap=false, layers=false — 第 3 次失败后尝试（只求拓扑能通过 checkMesh）
//   box_stl  : 同时生成外域 box STL，snappy 双 STL（用域 box 当 refinementRegion）— 第 4 次尝试组合策略
async function foamMeshPlan(args) {
  let { case_path, stl_path, target_cell_size, refinement_level_min = 1, refinement_level_max = 3, n_layers = 0, location_in_mesh, flow_direction = 'x', strategy = 'default' } = args;
  // —— 策略调参 —— //
  const _strategyApplied = strategy;
  let _snapFlag = true;
  let _addLayersFlag = n_layers > 0;
  let _writeBoxStl = false;
  if (strategy === 'coarsen') {
    if (target_cell_size) target_cell_size = target_cell_size * 1.5;
    refinement_level_max = Math.max(refinement_level_min, refinement_level_max - 1);
    n_layers = 0; _addLayersFlag = false;
  } else if (strategy === 'minimal') {
    if (target_cell_size) target_cell_size = target_cell_size * 2;
    refinement_level_min = 0;
    refinement_level_max = 1;
    n_layers = 0; _addLayersFlag = false;
    _snapFlag = false;
  } else if (strategy === 'box_stl') {
    _writeBoxStl = true;
  }
  if (!case_path || !stl_path) throw new Error('case_path 和 stl_path 必填');
  const cd = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  const stlAbs = path.isAbsolute(stl_path) ? stl_path : path.resolve(WORKSPACE, stl_path);
  await fs.mkdir(cd, { recursive: true });
  await fs.mkdir(path.join(cd, 'system'), { recursive: true });
  await fs.mkdir(path.join(cd, 'constant', 'triSurface'), { recursive: true });
  // 复制 STL 到 case
  const stlName = path.basename(stlAbs);
  const stlInCase = path.join(cd, 'constant', 'triSurface', stlName);
  await fs.copyFile(stlAbs, stlInCase);
  // 解析 bbox
  const inspectStr = await foamStlInspect(stlAbs);
  const info = JSON.parse(inspectStr);
  const [minX, minY, minZ] = info.bbox_min;
  const [maxX, maxY, maxZ] = info.bbox_max;
  const [sx, sy, sz] = info.bbox_size;
  const maxDim = Math.max(sx, sy, sz);
  const cell = +(target_cell_size || info.recommend_cell_size);
  // 背景域：沿主流方向放大；其他两维各放 1.5 倍
  const pad = maxDim * 0.5;
  const padFlow = maxDim * (flow_direction === 'x' ? 4 : flow_direction === 'y' ? 4 : 4);
  let bbMin = [minX - pad, minY - pad, minZ - pad];
  let bbMax = [maxX + pad, maxY + pad, maxZ + pad];
  if (flow_direction === 'x') { bbMin[0] = minX - maxDim * 1.5; bbMax[0] = maxX + maxDim * 5; }
  else if (flow_direction === 'y') { bbMin[1] = minY - maxDim * 1.5; bbMax[1] = maxY + maxDim * 5; }
  else { bbMin[2] = minZ - maxDim * 1.5; bbMax[2] = maxZ + maxDim * 5; }
  const nx = Math.max(8, Math.round((bbMax[0]-bbMin[0]) / cell));
  const ny = Math.max(8, Math.round((bbMax[1]-bbMin[1]) / cell));
  const nz = Math.max(8, Math.round((bbMax[2]-bbMin[2]) / cell));
  // 内部点
  const lim = location_in_mesh && location_in_mesh.length === 3 ? location_in_mesh : info.recommend_location_in_mesh;
  // patch 命名（按主流方向）
  const faceNames = { x: { in: 'inlet', out: 'outlet', side: ['front','back','top','bottom'] },
                      y: { in: 'inlet', out: 'outlet', side: ['left','right','top','bottom'] },
                      z: { in: 'inlet', out: 'outlet', side: ['left','right','front','back'] } }[flow_direction];
  const fHeader = (cls, obj) => `/*--------------------------------*- C++ -*----------------------------------*\\
| Auto-generated by NullFlux foam_mesh_plan                                   |
\\*---------------------------------------------------------------------------*/
FoamFile { version 2.0; format ascii; class ${cls}; object ${obj}; }
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
`;
  // blockMeshDict：按主流方向命名 inlet/outlet
  const f = (n) => n.toFixed(6);
  const bmd = fHeader('dictionary','blockMeshDict') + `
convertToMeters 1;

vertices
(
    (${f(bbMin[0])} ${f(bbMin[1])} ${f(bbMin[2])})
    (${f(bbMax[0])} ${f(bbMin[1])} ${f(bbMin[2])})
    (${f(bbMax[0])} ${f(bbMax[1])} ${f(bbMin[2])})
    (${f(bbMin[0])} ${f(bbMax[1])} ${f(bbMin[2])})
    (${f(bbMin[0])} ${f(bbMin[1])} ${f(bbMax[2])})
    (${f(bbMax[0])} ${f(bbMin[1])} ${f(bbMax[2])})
    (${f(bbMax[0])} ${f(bbMax[1])} ${f(bbMax[2])})
    (${f(bbMin[0])} ${f(bbMax[1])} ${f(bbMax[2])})
);

blocks
(
    hex (0 1 2 3 4 5 6 7) (${nx} ${ny} ${nz}) simpleGrading (1 1 1)
);

edges ();

boundary
(
    ${flow_direction === 'x' ? 'inlet  { type patch; faces ((0 4 7 3)); }\n    outlet { type patch; faces ((1 2 6 5)); }\n    front  { type patch; faces ((0 1 5 4)); }\n    back   { type patch; faces ((3 7 6 2)); }\n    bottom { type wall;  faces ((0 3 2 1)); }\n    top    { type patch; faces ((4 5 6 7)); }'
    : flow_direction === 'y' ? 'inlet  { type patch; faces ((0 1 5 4)); }\n    outlet { type patch; faces ((3 7 6 2)); }\n    left   { type patch; faces ((0 4 7 3)); }\n    right  { type patch; faces ((1 2 6 5)); }\n    bottom { type wall;  faces ((0 3 2 1)); }\n    top    { type patch; faces ((4 5 6 7)); }'
    : 'inlet  { type patch; faces ((0 3 2 1)); }\n    outlet { type patch; faces ((4 5 6 7)); }\n    left   { type patch; faces ((0 4 7 3)); }\n    right  { type patch; faces ((1 2 6 5)); }\n    front  { type patch; faces ((0 1 5 4)); }\n    back   { type patch; faces ((3 7 6 2)); }'}
);

mergePatchPairs ();
`;
  // snappyHexMeshDict
  const stlBase = stlName.replace(/\.stl$/i, '');
  const layersBlock = n_layers > 0 ? `
addLayersControls
{
    relativeSizes true;
    layers { "${stlBase}_.*" { nSurfaceLayers ${n_layers}; } }
    expansionRatio 1.2;
    finalLayerThickness 0.4;
    minThickness 0.05;
    nGrow 0;
    featureAngle 60;
    slipFeatureAngle 30;
    nRelaxIter 5;
    nSmoothSurfaceNormals 1;
    nSmoothNormals 3;
    nSmoothThickness 10;
    maxFaceThicknessRatio 0.5;
    maxThicknessToMedialRatio 0.3;
    minMedialAxisAngle 90;
    nBufferCellsNoExtrude 0;
    nLayerIter 50;
}
` : `
addLayersControls
{
    relativeSizes true;
    layers {}
    expansionRatio 1.2;
    finalLayerThickness 0.4;
    minThickness 0.05;
    nGrow 0;
    featureAngle 60;
    nRelaxIter 5;
    nSmoothSurfaceNormals 1;
    nSmoothNormals 3;
    nSmoothThickness 10;
    maxFaceThicknessRatio 0.5;
    maxThicknessToMedialRatio 0.3;
    minMedialAxisAngle 90;
    nBufferCellsNoExtrude 0;
    nLayerIter 50;
}
`;
  const shm = fHeader('dictionary','snappyHexMeshDict') + `
castellatedMesh true;
snap            ${_snapFlag ? 'true' : 'false'};
addLayers       ${_addLayersFlag ? 'true' : 'false'};

geometry
{
    ${stlBase}
    {
        type triSurfaceMesh;
        file "${stlName}";
    }
}

castellatedMeshControls
{
    maxLocalCells 1000000;
    maxGlobalCells 4000000;
    minRefinementCells 0;
    nCellsBetweenLevels 3;
    features
    (
        { file "${stlBase}.eMesh"; level ${refinement_level_max}; }
    );
    refinementSurfaces
    {
        ${stlBase}
        {
            level (${refinement_level_min} ${refinement_level_max});
        }
    }
    resolveFeatureAngle 30;
    refinementRegions {}
    locationInMesh (${f(lim[0])} ${f(lim[1])} ${f(lim[2])});
    allowFreeStandingZoneFaces true;
}

snapControls
{
    nSmoothPatch 3;
    tolerance 2.0;
    nSolveIter 30;
    nRelaxIter 5;
    nFeatureSnapIter 10;
    implicitFeatureSnap false;
    explicitFeatureSnap true;
    multiRegionFeatureSnap false;
}
${layersBlock}
meshQualityControls
{
    maxNonOrtho 65;
    maxBoundarySkewness 20;
    maxInternalSkewness 4;
    maxConcave 80;
    minVol 1e-13;
    minTetQuality 1e-15;
    minArea -1;
    minTwist 0.02;
    minDeterminant 0.001;
    minFaceWeight 0.05;
    minVolRatio 0.01;
    minTriangleTwist -1;
    nSmoothScale 4;
    errorReduction 0.75;
}

writeFlags ( scalarLevels layerSets layerFields );
mergeTolerance 1e-6;
`;
  // surfaceFeaturesDict（OF >= 1706）/ surfaceFeatureExtractDict（旧）
  const sfd = fHeader('dictionary','surfaceFeaturesDict') + `
surfaces ("${stlName}");
includedAngle   150;
subsetFeatures
{
    nonManifoldEdges no;
    openEdges        yes;
}
writeObj            yes;
`;
  const sfedict = fHeader('dictionary','surfaceFeatureExtractDict') + `
${stlName}
{
    extractionMethod    extractFromSurface;
    extractFromSurfaceCoeffs { includedAngle   150; }
    subsetFeatures { nonManifoldEdges no; openEdges yes; }
    writeObj                yes;
}
`;
  // 写文件
  const written = [];
  async function w(rel, content) {
    const fp = path.join(cd, rel);
    await fs.mkdir(path.dirname(fp), { recursive: true });
    await fs.writeFile(fp, content);
    written.push(rel);
  }
  await w('system/blockMeshDict', bmd);
  await w('system/snappyHexMeshDict', shm);
  await w('system/surfaceFeaturesDict', sfd);
  await w('system/surfaceFeatureExtractDict', sfedict);
  // 策略 box_stl：额外写一个外域 box STL（不强行接入 snappy，仅作为可视化/可选 refinementRegion 候选；agent 可手动改 snappy 字典加入）
  let boxStlNote = '';
  if (_writeBoxStl) {
    const boxName = 'domain_box.stl';
    const boxPath = path.join(cd, 'constant', 'triSurface', boxName);
    await writeBoxStl(boxPath, bbMin, bbMax, 'domain');
    boxStlNote = `\n额外生成: constant/triSurface/${boxName}（外域包围盒 STL，可手动加入 snappy 的 refinementRegions / 改成 internalCellZones 策略）`;
  }
  return [
    `[已生成网格方案] case=${path.relative(WORKSPACE, cd) || cd}  策略=${_strategyApplied}`,
    ``,
    `STL 摘要：tris=${info.triangles}, bbox=${info.bbox_size.join('×')}, 单位=${info.unit_guess}`,
    `背景域: (${bbMin.map(x=>x.toFixed(3)).join(', ')}) → (${bbMax.map(x=>x.toFixed(3)).join(', ')})`,
    `网格分辨率: ${nx}×${ny}×${nz} = ${(nx*ny*nz).toLocaleString()} cells (cell≈${cell})`,
    `加密级: surface ${refinement_level_min}–${refinement_level_max}, 边界层=${n_layers}`,
    `主流方向: ${flow_direction} (inlet/outlet 已按此命名)`,
    `内部点 locationInMesh = (${lim.map(x=>x.toFixed(3)).join(', ')})`,
    ``,
    `生成文件:`,
    ...written.map(x => `  - ${x}`),
    `  - constant/triSurface/${stlName}`,
    ``,
    `建议执行序列（用 foam_run_solver_async 后台执行）：`,
    `  1) blockMesh`,
    `  2) surfaceFeatures   # OF >=1706；旧版用 surfaceFeatureExtract`,
    `  3) snappyHexMesh -overwrite`,
    `  4) checkMesh`,
    ``,
    `若 unit_guess 提示 mm，请先 surfaceTransformPoints -scale 0.001 转换。`,
    boxStlNote
  ].filter(Boolean).join('\n');
}

// ============== 写一个 axis-aligned box 的 ASCII STL ==============
async function writeBoxStl(filepath, bbMin, bbMax, solidName = 'box') {
  const [x0,y0,z0] = bbMin, [x1,y1,z1] = bbMax;
  // 8 顶点
  const v = [
    [x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],
    [x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]
  ];
  // 12 三角面（每面 2 个），法向朝外
  const faces = [
    // bottom z=z0, n=(0,0,-1)
    [[0,2,1],[0,3,2], [0,0,-1]],
    // top z=z1, n=(0,0,1)
    [[4,5,6],[4,6,7], [0,0,1]],
    // front y=y0, n=(0,-1,0)
    [[0,1,5],[0,5,4], [0,-1,0]],
    // back y=y1, n=(0,1,0)
    [[3,7,6],[3,6,2], [0,1,0]],
    // left x=x0, n=(-1,0,0)
    [[0,4,7],[0,7,3], [-1,0,0]],
    // right x=x1, n=(1,0,0)
    [[1,2,6],[1,6,5], [1,0,0]],
  ];
  let out = `solid ${solidName}\n`;
  for (const grp of faces) {
    const n = grp[2];
    for (let i = 0; i < 2; i++) {
      const tri = grp[i];
      out += `  facet normal ${n[0]} ${n[1]} ${n[2]}\n`;
      out += `    outer loop\n`;
      for (const idx of tri) out += `      vertex ${v[idx][0]} ${v[idx][1]} ${v[idx][2]}\n`;
      out += `    endloop\n  endfacet\n`;
    }
  }
  out += `endsolid ${solidName}\n`;
  await fs.mkdir(path.dirname(filepath), { recursive: true });
  await fs.writeFile(filepath, out);
  return filepath;
}

// 工具入口：生成域 box STL
async function foamMeshBoxStl(args) {
  const { case_path, bbox_min, bbox_max, name = 'domain_box' } = args || {};
  if (!case_path || !Array.isArray(bbox_min) || !Array.isArray(bbox_max)) throw new Error('case_path / bbox_min[3] / bbox_max[3] 必填');
  const cd = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  const fp = path.join(cd, 'constant', 'triSurface', `${name}.stl`);
  await writeBoxStl(fp, bbox_min, bbox_max, name);
  return `[已生成 box STL] ${path.relative(WORKSPACE, fp) || fp}\nbbox: (${bbox_min.join(', ')}) → (${bbox_max.join(', ')})`;
}

// ============== 残差时序结构化 ==============
function foamResidualSeries(runId, maxPoints = 60, fields = null) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  const lines = run.log;
  // 解析模型：扫描行，遇 "Time = X" 切到新时间步；行内 "Solving for FIELD, Initial residual = A, Final residual = B, No Iterations N"
  const series = []; // [{t, residuals: {U:{init,final,iters}, p:..., ...}}]
  let cur = null;
  const reTime = /^Time\s*=\s*([\d.eE+\-]+)/;
  const reRes = /Solving for ([A-Za-z][\w]*),\s*Initial residual\s*=\s*([\d.eE+\-]+),\s*Final residual\s*=\s*([\d.eE+\-]+),\s*No Iterations\s*(\d+)/;
  for (const l of lines) {
    const tm = l.match(reTime);
    if (tm) { cur = { t: +tm[1], res: {} }; series.push(cur); continue; }
    if (!cur) continue;
    const rm = l.match(reRes);
    if (rm) {
      const fld = rm[1];
      if (fields && !fields.includes(fld)) continue;
      // 同一时间步内同一 field 出现多次（PISO 多次校正）→ 取最后一次
      cur.res[fld] = { init: +rm[2], final: +rm[3], iters: +rm[4] };
    }
  }
  const tail = series.slice(-maxPoints);
  // 收敛趋势：取每个 field 最近 10 步初始残差，做对数斜率
  const allFields = new Set();
  tail.forEach(s => Object.keys(s.res).forEach(k => allFields.add(k)));
  const trends = {};
  for (const f of allFields) {
    const xs = tail.filter(s => s.res[f] && isFinite(s.res[f].init) && s.res[f].init > 0).slice(-10);
    if (xs.length < 3) { trends[f] = { samples: xs.length, status: 'insufficient' }; continue; }
    const ys = xs.map(s => Math.log10(s.res[f].init));
    const n = ys.length;
    const meanX = (n - 1) / 2;
    const meanY = ys.reduce((a, b) => a + b, 0) / n;
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) { num += (i - meanX) * (ys[i] - meanY); den += (i - meanX) ** 2; }
    const slope = den > 0 ? num / den : 0; // log10 残差/步
    const last = ys[ys.length - 1], first = ys[0];
    let status;
    if (slope < -0.05) status = '收敛中';
    else if (slope > 0.05) status = '发散/震荡';
    else if (last > -3) status = '停滞-高残差';
    else status = '停滞-已稳态';
    trends[f] = { samples: n, slope_log10_per_step: +slope.toFixed(3), last_log10: +last.toFixed(2), first_log10: +first.toFixed(2), status };
  }
  return JSON.stringify({
    runId, total_time_steps: series.length, returned: tail.length,
    last_time: tail.length ? tail[tail.length-1].t : null,
    fields: [...allFields],
    trends,
    series: tail.map(s => ({ t: s.t, ...Object.fromEntries(Object.entries(s.res).map(([k,v]) => [k, v.init])) }))
  }, null, 2);
}

// ============== 算例对比并排渲染 ==============
async function foamCompareRender(args, ws) {
  const { case_a, case_b, label_a, label_b, field, time_step, azimuth = 30, elevation = 15 } = args;
  if (!case_a || !case_b) throw new Error('case_a 和 case_b 必填');
  const a = path.isAbsolute(case_a) ? case_a : path.resolve(WORKSPACE, case_a);
  const b = path.isAbsolute(case_b) ? case_b : path.resolve(WORKSPACE, case_b);
  // 串行渲染（pvpython 同时跑会抢 GPU；并行也行但风险大）
  const r1 = await pvRenderOffscreen({ casePath: a, azimuth, elevation, field: field || '', timeStep: time_step ?? null });
  const r2 = await pvRenderOffscreen({ casePath: b, azimuth, elevation, field: field || '', timeStep: time_step ?? null });
  // 通过 ws 推一条 sim_compare 给前端，前端把两个 dataUrl 并排渲染
  const labelA = label_a || path.basename(a);
  const labelB = label_b || path.basename(b);
  const payload = {
    type: 'sim_compare',
    a: { dataUrl: r1.dataUrl, label: labelA, meta: r1.meta || {} },
    b: { dataUrl: r2.dataUrl, label: labelB, meta: r2.meta || {} },
    field: field || '', timeStep: time_step ?? null
  };
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(payload));
  else for (const c of allClients) if (c.readyState === 1) c.send(JSON.stringify(payload));
  return [
    `[对比渲染完成] field=${field || '(默认)'}  t=${time_step ?? '(默认)'}`,
    `A: ${labelA}  →  ${a}`,
    `B: ${labelB}  →  ${b}`,
    `已推送 sim_compare 到聊天界面（左右并排）。`,
    r1.meta && r1.meta.fields ? `A 可用场: ${(r1.meta.fields||[]).join(', ')}` : '',
    r2.meta && r2.meta.fields ? `B 可用场: ${(r2.meta.fields||[]).join(', ')}` : ''
  ].filter(Boolean).join('\n');
}

// ====================== v4.6 网格自动核对 / STL 预检 / patch 对照 ======================
// 把 dataUrl(base64 PNG) 写到 tmp 路径，返回路径（给 visionAnalyze 用）
async function _dataUrlToTmpPng(dataUrl, tag) {
  const m = /^data:image\/png;base64,(.+)$/.exec(dataUrl || '');
  if (!m) throw new Error('dataUrl 解析失败');
  const buf = Buffer.from(m[1], 'base64');
  const p = path.join(os.tmpdir(), `dscm_mv_${tag || 'x'}_${crypto.randomBytes(6).toString('hex')}.png`);
  await fs.writeFile(p, buf);
  return p;
}

function _parseCheckMeshOutput(txt) {
  const out = { meshOk: null, nCells: null, nFaces: null, nPoints: null, maxNonOrtho: null, maxSkew: null, maxAspectRatio: null, nNegativeVolumeCells: 0, nOpenCells: 0, failedChecks: [], warnings: [] };
  const m1 = /Mesh OK\./.exec(txt); if (m1) out.meshOk = true;
  const m2 = /Failed\s+(\d+)\s+mesh checks/i.exec(txt); if (m2) { out.meshOk = false; out.failedChecks.push(`Failed ${m2[1]} checks`); }
  const grab = (re, key) => { const m = re.exec(txt); if (m) out[key] = parseFloat(m[1]); };
  grab(/cells:\s*(\d+)/i, 'nCells');
  grab(/faces:\s*(\d+)/i, 'nFaces');
  grab(/points:\s*(\d+)/i, 'nPoints');
  grab(/Max non-orthogonality\s*=\s*([\d.eE+-]+)/, 'maxNonOrtho');
  grab(/Max skewness\s*=\s*([\d.eE+-]+)/, 'maxSkew');
  grab(/Max aspect ratio\s*=\s*([\d.eE+-]+)/, 'maxAspectRatio');
  const neg = /([\d]+)\s+cells with negative volume/i.exec(txt); if (neg) out.nNegativeVolumeCells = parseInt(neg[1], 10);
  const open = /Number of open cells.*?:\s*(\d+)/i.exec(txt); if (open) out.nOpenCells = parseInt(open[1], 10);
  // 收集 *** Warning / *** Failed 行
  for (const line of txt.split(/\r?\n/)) {
    if (/^\s*\*{2,3}\s*/.test(line)) out.warnings.push(line.trim().slice(0, 200));
  }
  // 兜底判断：没有显式 Mesh OK 但也没有 negVol/failed，就按 warnings 判
  if (out.meshOk === null) {
    out.meshOk = (out.nNegativeVolumeCells === 0 && out.failedChecks.length === 0 && (out.maxNonOrtho === null || out.maxNonOrtho < 70) && (out.maxSkew === null || out.maxSkew < 4));
  }
  return out;
}

function _meshVerifyJudge(metrics, stage) {
  const issues = [];
  const suggestions = [];
  if (metrics.nNegativeVolumeCells > 0) { issues.push(`存在 ${metrics.nNegativeVolumeCells} 个负体积 cell`); suggestions.push('降低 snappy refinementSurfaces level 或 location_in_mesh 远离表面；blockMesh 可粗化背景网格'); }
  if (metrics.nOpenCells > 0) { issues.push(`存在 ${metrics.nOpenCells} 个 open cell（拓扑破洞）`); suggestions.push('STL 不封闭或 snappy 没切干净：先 foam_stl_render 检 STL 法向/封闭，必要时 surfaceFeatures 改 includedAngle'); }
  if (metrics.maxNonOrtho !== null && metrics.maxNonOrtho > 70) { issues.push(`maxNonOrtho=${metrics.maxNonOrtho} > 70°`); suggestions.push('加 nNonOrthogonalCorrectors=2~3；或在 fvSchemes 用 limited 0.5'); }
  if (metrics.maxSkew !== null && metrics.maxSkew > 4) { issues.push(`maxSkew=${metrics.maxSkew} > 4`); suggestions.push('降低 snappy refinement 跨级差；增加 nSmoothPatch / nRelaxIter'); }
  if (metrics.maxAspectRatio !== null && metrics.maxAspectRatio > 1000) { issues.push(`maxAspectRatio=${metrics.maxAspectRatio} > 1000`); suggestions.push('边界层第一层太薄：减小 finalLayerThickness 或 expansionRatio'); }
  if (metrics.failedChecks.length) { issues.push(...metrics.failedChecks); }
  const pass = metrics.meshOk === true && metrics.nNegativeVolumeCells === 0 && metrics.nOpenCells === 0 && issues.length === 0;
  return { pass, issues, suggestions };
}

async function foamMeshVerify(args, ws, session) {
  const { case_path, stage = 'final', ask_vision = true, n_views = 2 } = args || {};
  if (!case_path) throw new Error('foam_mesh_verify: case_path 必填');
  const abs = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  // 1) checkMesh
  const checkOut = await runOpenFoam({ casePath: abs, command: 'checkMesh -allTopology -allGeometry' }, ws);
  const metrics = _parseCheckMeshOutput(checkOut);
  // 2) 渲染 n_views 张（覆盖等角 + 顶视，stage=snappy 时多加一个侧切）
  const camPresets = [
    { azimuth: 30, elevation: 20, tag: 'iso' },
    { azimuth: 0,  elevation: 89, tag: 'top' },
    { azimuth: 90, elevation: 0,  tag: 'side' },
    { azimuth: 60, elevation: -10, tag: 'iso2' }
  ];
  const k = Math.max(1, Math.min(4, n_views | 0 || 2));
  const renders = [];
  for (let i = 0; i < k; i++) {
    try {
      const cam = camPresets[i];
      const r = await pvRenderOffscreen({ casePath: abs, azimuth: cam.azimuth, elevation: cam.elevation });
      const p = await _dataUrlToTmpPng(r.dataUrl, `${stage}_${cam.tag}`);
      renders.push({ tag: cam.tag, path: p });
      // 顺手广播到前端 ParaView 面板
      try { pvBroadcast({ type: 'sim_frame', dataUrl: r.dataUrl, meta: { ...(r.meta||{}), label: `mesh_verify/${stage}/${cam.tag}` } }); } catch {}
    } catch (e) {
      renders.push({ tag: camPresets[i].tag, error: e.message });
    }
  }
  // 3) 视觉裁判（可选）
  let vision = '';
  const okRenders = renders.filter(x => x.path).map(x => x.path);
  if (ask_vision && okRenders.length) {
    const q = `这是 OpenFOAM 算例在 ${stage} 阶段的网格渲染图（${okRenders.length} 个视角）。请按以下硬性 checklist 逐条判断并只输出 JSON：\n` +
      `{"shape_ok": true/false, "shape_reason": "...",\n` +
      ` "boundary_clean": true/false, "boundary_reason": "...",\n` +
      ` "refinement_reasonable": true/false, "refinement_reason": "...",\n` +
      ` "obvious_defects": ["..."],\n` +
      ` "overall_pass": true/false}\n` +
      `检查点：① 整体几何外形是否与预期 case 一致（不要变形/缺角）；② 边界面是否干净、没有锯齿状破裂；③ 加密区域是否合理（贴近物体、不浪费在空气）；④ 有无明显的孔洞、悬空 cell、超长拉伸。回答全部用中文。`;
    try {
      const progress = session && typeof session._progressPub === 'function' ? session._progressPub : null;
      vision = await visionAnalyze(okRenders, q, 800, progress);
    } catch (e) { vision = 'vision_analyze 调用失败：' + e.message; }
  }
  // 4) 综合裁决
  const j = _meshVerifyJudge(metrics, stage);
  // 视觉若明显反对，也降为 fail
  let visionPass = null;
  const mvJson = /\{[\s\S]*"overall_pass"\s*:\s*(true|false)[\s\S]*\}/.exec(vision || '');
  if (mvJson) visionPass = mvJson[1] === 'true';
  const finalPass = j.pass && (visionPass !== false);
  const result = {
    pass: finalPass,
    stage,
    metrics,
    issues: j.issues,
    suggestions: j.suggestions,
    renders: renders.map(r => r.path ? { tag: r.tag, path: r.path } : { tag: r.tag, error: r.error }),
    vision_pass: visionPass,
    vision: vision || '(未调用 VLM)'
  };
  // 给 LLM 一个紧凑可读的文本 + JSON 双视图
  const head = finalPass ? `✓ [mesh_verify/${stage}] 通过` : `✗ [mesh_verify/${stage}] 未通过 (${j.issues.length} 项问题)`;
  return `${head}\n` +
    `metrics: cells=${metrics.nCells} faces=${metrics.nFaces} maxNonOrtho=${metrics.maxNonOrtho} maxSkew=${metrics.maxSkew} negVol=${metrics.nNegativeVolumeCells} openCells=${metrics.nOpenCells}\n` +
    (j.issues.length ? `issues:\n  - ${j.issues.join('\n  - ')}\n` : '') +
    (j.suggestions.length ? `suggestions:\n  - ${j.suggestions.join('\n  - ')}\n` : '') +
    (vision ? `\n=== VLM 视觉评审 ===\n${vision.slice(0, 1200)}\n` : '') +
    `\n=== JSON ===\n${JSON.stringify(result, null, 2)}`;
}

async function foamStlRender(args, ws) {
  const { stl_path, n_views = 3 } = args || {};
  if (!stl_path) throw new Error('foam_stl_render: stl_path 必填');
  const abs = path.isAbsolute(stl_path) ? stl_path : path.resolve(WORKSPACE, stl_path);
  await fs.access(abs);
  // 先取一份几何元数据（复用现有 inspect）
  let inspect = null;
  try { inspect = await foamStlInspect(stl_path); } catch (e) { inspect = '(foam_stl_inspect 失败: ' + e.message + ')'; }
  const presets = [
    { azimuth: 0,  elevation: 0,  tag: 'front' },
    { azimuth: 0,  elevation: 89, tag: 'top' },
    { azimuth: 30, elevation: 20, tag: 'iso' },
    { azimuth: 90, elevation: 0,  tag: 'side' }
  ];
  const k = Math.max(1, Math.min(4, n_views | 0 || 3));
  const out = [];
  for (let i = 0; i < k; i++) {
    const cam = presets[i];
    try {
      const r = await pvRenderOffscreen({ casePath: abs, azimuth: cam.azimuth, elevation: cam.elevation });
      const p = await _dataUrlToTmpPng(r.dataUrl, `stl_${cam.tag}`);
      out.push({ tag: cam.tag, path: p });
      try { pvBroadcast({ type: 'sim_frame', dataUrl: r.dataUrl, meta: { label: `stl_render/${cam.tag}` } }); } catch {}
    } catch (e) { out.push({ tag: cam.tag, error: e.message }); }
  }
  const head = `[foam_stl_render] ${path.basename(abs)} → ${out.filter(x => x.path).length}/${k} 视角已渲染并推送到 ParaView 面板。`;
  return head + '\n\n=== foam_stl_inspect ===\n' + (typeof inspect === 'string' ? inspect : JSON.stringify(inspect, null, 2)) +
    '\n\n=== 渲染图路径（可传给 vision_analyze） ===\n' + JSON.stringify(out, null, 2);
}

// 解析 constant/polyMesh/boundary（OpenFOAM 文本字典）→ [{name,type,nFaces,startFace}]
function _parseFoamBoundary(txt) {
  const patches = [];
  // 找顶层 ( ... ) 区块
  const top = /\(([\s\S]*)\)\s*\/\/?\s*\*?\s*$/.exec(txt) || /\(([\s\S]*)\)\s*$/.exec(txt);
  const body = top ? top[1] : txt;
  // 每个 patch 形如：name { type ...; nFaces ...; startFace ...; }
  const re = /([A-Za-z_][A-Za-z0-9_.\-]*)\s*\{([^}]*)\}/g;
  let m;
  while ((m = re.exec(body))) {
    const name = m[1];
    if (name === 'FoamFile') continue;
    const block = m[2];
    const get = (k) => { const r = new RegExp(k + '\\s+([^;\\s]+)\\s*;').exec(block); return r ? r[1] : null; };
    patches.push({
      name,
      type: get('type'),
      physicalType: get('physicalType'),
      nFaces: parseInt(get('nFaces') || '0', 10) || 0,
      startFace: parseInt(get('startFace') || '0', 10) || 0
    });
  }
  return patches;
}

async function foamPatchDiff(args) {
  const { case_path, snapshot_before } = args || {};
  if (!case_path) throw new Error('foam_patch_diff: case_path 必填');
  const abs = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  const bfile = path.join(abs, 'constant', 'polyMesh', 'boundary');
  let txt;
  try { txt = await fs.readFile(bfile, 'utf8'); }
  catch (e) { throw new Error('读不到 constant/polyMesh/boundary（mesh 还没生成？）: ' + e.message); }
  const patches = _parseFoamBoundary(txt);
  let diff = null;
  if (snapshot_before) {
    try {
      const prev = JSON.parse(snapshot_before);
      const prevMap = new Map((prev.patches || prev).map(p => [p.name, p]));
      const curMap = new Map(patches.map(p => [p.name, p]));
      const added = [], removed = [], changed = [];
      for (const [n, p] of curMap) if (!prevMap.has(n)) added.push(p);
      for (const [n, p] of prevMap) if (!curMap.has(n)) removed.push(p);
      for (const [n, p] of curMap) {
        const pv = prevMap.get(n);
        if (pv && (pv.type !== p.type || pv.nFaces !== p.nFaces)) changed.push({ name: n, before: pv, after: p });
      }
      diff = { added, removed, changed };
    } catch (e) { diff = { error: 'snapshot_before 解析失败: ' + e.message }; }
  }
  const summary = patches.map(p => `  ${p.name.padEnd(20)} ${String(p.type).padEnd(14)} nFaces=${p.nFaces}`).join('\n');
  return `[foam_patch_diff] ${path.relative(WORKSPACE, abs)} 共 ${patches.length} 个 patch:\n${summary}\n\n=== JSON ===\n${JSON.stringify({ patches, diff }, null, 2)}`;
}

async function execTool(name, args, session, ws) {
  switch (name) {
    case 'list_dir': {
      const dir = safePath(args.path || '.');
      const entries = await fs.readdir(dir, { withFileTypes: true });
      return entries.map(e => e.isDirectory() ? e.name + '/' : e.name).sort().join('\n');
    }
    case 'read_file': {
      const f = safePath(args.path);
      const c = await fs.readFile(f, 'utf8');
      const sl = args.start_line, el = args.end_line;
      if (sl || el) {
        const lines = c.split('\n');
        const a = Math.max(1, sl || 1) - 1;
        const b = Math.min(lines.length, el || lines.length);
        const slice = lines.slice(a, b).map((line, i) => `${a + i + 1}\t${line}`).join('\n');
        return `${args.path} (行 ${a+1}-${b}, 共 ${lines.length} 行)\n${slice}`;
      }
      return c.length > 100_000 ? c.slice(0, 100_000) + `\n...[已截断，原文 ${c.length} B，请用 start_line/end_line]` : c;
    }
    case 'write_file': {
      const f = safePath(args.path);
      let oldContent = null; try { oldContent = await fs.readFile(f, 'utf8'); } catch {}
      await fs.mkdir(path.dirname(f), { recursive: true });
      await fs.writeFile(f, args.content, 'utf8');
      addPendingEdit(session, { id: crypto.randomBytes(4).toString('hex'), path: args.path, action: oldContent === null ? 'create' : 'write', oldContent, newContent: args.content, timestamp: Date.now() });
      broadcastEdits(ws); broadcastTree();
      return `已写入 ${args.path}（${args.content.length} 字符）`;
    }
    case 'edit_file': {
      const f = safePath(args.path);
      const orig = await fs.readFile(f, 'utf8');
      const idx = orig.indexOf(args.old_str);
      if (idx === -1) return `错误：未找到 old_str`;
      if (orig.indexOf(args.old_str, idx + 1) !== -1) return `错误：old_str 匹配多处`;
      const updated = orig.slice(0, idx) + args.new_str + orig.slice(idx + args.old_str.length);
      await fs.writeFile(f, updated, 'utf8');
      addPendingEdit(session, { id: crypto.randomBytes(4).toString('hex'), path: args.path, action: 'edit', oldContent: orig, newContent: updated, timestamp: Date.now() });
      broadcastEdits(ws); broadcastTree();
      return `已编辑 ${args.path}`;
    }
    case 'multi_edit': {
      const f = safePath(args.path);
      const orig = await fs.readFile(f, 'utf8');
      let cur = orig;
      const edits = Array.isArray(args.edits) ? args.edits : [];
      if (edits.length === 0) return '错误：edits 为空';
      for (let i = 0; i < edits.length; i++) {
        const e = edits[i];
        const idx = cur.indexOf(e.old_str);
        if (idx === -1) return `错误：第 ${i+1} 个 edit 未找到 old_str`;
        if (cur.indexOf(e.old_str, idx + 1) !== -1) return `错误：第 ${i+1} 个 edit 匹配多处`;
        cur = cur.slice(0, idx) + e.new_str + cur.slice(idx + e.old_str.length);
      }
      await fs.writeFile(f, cur, 'utf8');
      addPendingEdit(session, { id: crypto.randomBytes(4).toString('hex'), path: args.path, action: 'edit', oldContent: orig, newContent: cur, timestamp: Date.now() });
      broadcastEdits(ws); broadcastTree();
      return `已应用 ${edits.length} 处编辑到 ${args.path}`;
    }
    case 'glob': {
      const root = safePath(args.path || '.');
      const pat = args.pattern || '**/*';
      const re = globToRegExp(pat);
      const out = []; const max = 200;
      async function walkG(dir) {
        if (out.length >= max) return;
        let entries = []; try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
        for (const e of entries) {
          if (out.length >= max) return;
          if (IGNORE.has(e.name)) continue;
          const full = path.join(dir, e.name);
          const rel = path.relative(WORKSPACE, full).replace(/\\/g, '/');
          if (e.isDirectory()) await walkG(full);
          else if (re.test(rel)) out.push(rel);
        }
      }
      await walkG(root);
      return out.length ? out.join('\n') + (out.length === max ? `\n...[已截断@${max}]` : '') : '（无匹配）';
    }
    case 'grep_search': {
      const re = new RegExp(args.pattern, 'gm');
      const root = safePath(args.path || '.');
      const results = [];
      async function walk(dir) {
        if (results.length >= 50) return;
        let entries = []; try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
        for (const e of entries) {
          if (results.length >= 50) return;
          if (IGNORE.has(e.name)) continue;
          const full = path.join(dir, e.name);
          if (e.isDirectory()) await walk(full);
          else if (e.isFile()) {
            try { const c = await fs.readFile(full, 'utf8');
              c.split('\n').forEach((line, i) => { if (results.length >= 50) return; if (re.test(line)) results.push(`${path.relative(WORKSPACE, full)}:${i+1}: ${line.trim().slice(0,200)}`); re.lastIndex = 0; });
            } catch {}
          }
        }
      }
      await walk(root);
      return results.length ? results.join('\n') : '（无匹配）';
    }
    case 'run_command': return await runShell(args.command, args.timeout_ms || 60000, session, ws);
    case 'update_todos': {
      session.todos = (args.items || []).map(it => ({ text: String(it.text || ''), done: !!it.done }));
      broadcastTodos(ws);
      const total = session.todos.length, done = session.todos.filter(t => t.done).length;
      return `已更新待办：${done}/${total} 完成`;
    }
    case 'task_complete': {
      session.taskComplete = true;
      ws.send(JSON.stringify({ type: 'task_complete', summary: args.summary || '' }));
      return `任务标记完成：${args.summary || ''}`;
    }
    case 'sim_open_paraview': {
      try {
        const r = await launchParaView(args.case_path);
        ws.send(JSON.stringify({ type: 'sim_started', pid: r.pid, casePath: args.case_path || '' }));
        return r.reused ? `ParaView 已在运行（PID ${r.pid}），已切换到投影` : `已启动 ParaView（PID ${r.pid}），开始投影窗口`;
      } catch (e) { return `启动失败：${e.message}`; }
    }
    case 'sim_run_openfoam': return await runOpenFoam(args, ws);
    case 'foam_find_tutorial': return await foamFindTutorial(args.query, args.top_k || 12);
    case 'foam_find_source':   return await foamFindSource(args.query, args.kind || 'all', args.top_k || 12);
    case 'foam_clone_tutorial':return await foamCloneTutorial(args.tutorial_path, args.dest);
    case 'foam_inspect_case':  return await foamInspectCase(args.case_path);
    case 'foam_run_solver_async': return await foamRunSolverAsync({ case_path: args.case_path, command: args.command }, ws);
    case 'foam_solver_status': return foamSolverStatus(args.run_id);
    case 'foam_solver_stop':   return foamSolverStop(args.run_id);
    case 'foam_stl_inspect':   return await foamStlInspect(args.stl_path);
    case 'foam_mesh_plan':     return await foamMeshPlan(args);
    case 'foam_mesh_box_stl':  return await foamMeshBoxStl(args);
    case 'foam_residual_series': return foamResidualSeries(args.run_id, args.max_points || 60, args.fields || null);
    case 'foam_compare_render':  return await foamCompareRender(args, ws);
    case 'foam_mesh_verify':     return await foamMeshVerify(args, ws, session);
    case 'foam_stl_render':      return await foamStlRender(args, ws);
    case 'foam_patch_diff':      return await foamPatchDiff(args);
    // ---------- MFIX-Beta dispatch ----------
    case 'mfix_find_tutorial':    return await mfixFindTutorial(args.query, args.top_k || 12);
    case 'mfix_clone_tutorial':   return await mfixCloneTutorial(args.tutorial_path, args.dest);
    case 'mfix_inspect_case':     return await mfixInspectCase(args.case_path);
    case 'mfix_run_solver_async': return await mfixRunSolverAsync({ case_path: args.case_path, command: args.command }, ws);
    case 'mfix_solver_status':    return mfixSolverStatus(args.run_id);
    case 'mfix_solver_stop':      return mfixSolverStop(args.run_id);
    // ---------- LBM-Beta dispatch ----------
    case 'lbm_find_tutorial':  return await lbmFindTutorial(args.query, args.top_k || 12);
    case 'lbm_clone_tutorial': return await lbmCloneTutorial(args.tutorial_path, args.dest);
    case 'lbm_inspect_case':   return await lbmInspectCase(args.case_path, args.algorithm || '');
    case 'lbm_run_async':      return await lbmRunAsync({ case_path: args.case_path, command: args.command }, ws);
    case 'lbm_solver_status':  return lbmSolverStatus(args.run_id);
    case 'lbm_solver_stop':    return lbmSolverStop(args.run_id);
    case 'web_search': return await webSearch(args.query, args.top_k || 6, { topic: args.topic, time_range: args.time_range, include_answer: args.include_answer, progress: session?._progressPub });
    case 'image_search': {
      try {
        const imgs = await imageSearch(args.query, Math.min(30, args.top_k || 12));
        // 把图片广播到所有客户端的图片库
        broadcastImages(imgs, args.query);
        if (!imgs.length) return '未找到图片（可能被反爬，可尝试改换关键词或开代理）';
        return `[image_search] "${args.query}" → ${imgs.length} 张图片，已发到右侧"图片库"面板。\n` +
          imgs.slice(0, 8).map((x, i) => `${i+1}. ${x.title || ''}\n   图片: ${x.image}\n   来源: ${x.source || ''}`).join('\n');
      } catch (e) { return '搜图失败：' + e.message; }
    }
    case 'fetch_url': return await fetchUrlText(args.url, args.max_chars || 6000, args.with_images !== false, session?._progressPub);
    case 'read_document': return await readDocument(args.path, session?._progressPub);
    case 'request_user_digitize': return await requestUserDigitize(args || {}, ws, session);
    case 'read_paper': return await readPaper(args.path, args.focus || '', session?._progressPub);
    case 'paper_search': return await paperSearch(args.query, { topK: args.top_k || 8, year: args.year, openAccessOnly: !!args.open_access_only, fieldsOfStudy: args.fields_of_study, progress: session?._progressPub });
    case 'paper_fetch': return await paperFetch(args.id, { download: !!args.download, maxRefs: args.max_refs || 30, progress: session?._progressPub });
    case 'vision_analyze': return await visionAnalyze(args.images || [], args.question || '', args.max_tokens || 1500, session?._progressPub);
    case 'download_file': return await downloadFile(args.url, args.save_as);
    case 'sim_render': {
      try {
        const r = await pvRenderOffscreen({ casePath: args.case_path, azimuth: args.azimuth, elevation: args.elevation, zoom: args.zoom, field: args.field, timeStep: args.time_step });
        pvBroadcast({ type: 'sim_frame', dataUrl: r.dataUrl, meta: r.meta });
        ws.send(JSON.stringify({ type: 'sim_started', pid: 0, casePath: args.case_path }));
        return `已渲染 ${args.case_path}（${r.width}x${r.height}，${r.bytes} bytes）。画面已发到右侧面板。` + (r.meta ? `\n可用场：${r.meta.fields.join(', ') || '(无)'}\n时间步数：${r.meta.times.length}` : '');
      } catch (e) { return `渲染失败：${e.message}`; }
    }
    default: return `未知工具：${name}`;
  }
}

async function runShell(command, timeout, session, ws) {
  return await new Promise((resolve) => {
    const shell = IS_WIN ? (process.env.COMSPEC || 'cmd.exe') : 'bash';
    let cmd = command;
    if (SETTINGS.pythonPath) {
      const py = `"${SETTINGS.pythonPath}"`;
      const dir = path.dirname(SETTINGS.pythonPath);
      const pip = IS_WIN ? `"${path.join(dir, 'Scripts', 'pip.exe')}"` : `"${path.join(dir, 'pip')}"`;
      const tokenPy = /(^|\s|&&\s*|\|\|\s*|;\s*|\(\s*)(python(?:3)?(?:\.exe)?|py(?:\s+-3)?)\b/g;
      const tokenPip = /(^|\s|&&\s*|\|\|\s*|;\s*|\(\s*)(pip(?:3)?(?:\.exe)?)\b/g;
      const tokenJp = /(^|\s|&&\s*|\|\|\s*|;\s*|\(\s*)(jupyter(?:\.exe)?)\b/g;
      cmd = cmd.replace(tokenPy, (_,p) => p + py);
      cmd = cmd.replace(tokenPip, (_,p) => p + py + ' -m pip');
      cmd = cmd.replace(tokenJp, (_,p) => p + py + ' -m jupyter');
    }
    const shellArgs = IS_WIN ? ['/c', cmd] : ['-c', cmd];
    ws.send(JSON.stringify({ type: 'term', line: `$ ${cmd}` }));
    const env = { ...process.env };
    if (SETTINGS.pythonPath) {
      const dir = path.dirname(SETTINGS.pythonPath);
      env.PATH = dir + path.delimiter + (env.PATH || env.Path || '');
      env.VIRTUAL_ENV = dir.replace(/[\\/](Scripts|bin)$/i, '');
      env.PYTHONIOENCODING = 'utf-8';
    }
    const child = spawn(shell, shellArgs, { cwd: WORKSPACE, env });
    session.currentProc = child;
    let out = '';
    const onData = d => { const s = d.toString(); out += s; s.split(/\r?\n/).forEach(l => l && ws.send(JSON.stringify({ type: 'term', line: l }))); };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    const t = setTimeout(() => { try { child.kill(); } catch {}; ws.send(JSON.stringify({ type: 'term', line: '[超时已终止]' })); }, timeout);
    child.on('close', code => { clearTimeout(t); session.currentProc = null;
      ws.send(JSON.stringify({ type: 'term', line: `[退出码 ${code}]` })); broadcastTree();
      resolve(`[退出码 ${code}]\n${out.slice(0, 50000)}`); });
    child.on('error', err => { clearTimeout(t); session.currentProc = null; resolve(`[启动失败] ${err.message}`); });
  });
}

async function undoEdit(session, editId) {
  const idx = session.pendingEdits.findIndex(e => e.id === editId);
  if (idx === -1) throw new Error('编辑记录不存在');
  const edit = session.pendingEdits[idx];
  const f = safePath(edit.path);
  if (edit.oldContent === null) { try { await fs.unlink(f); } catch {} } else await fs.writeFile(f, edit.oldContent, 'utf8');
  session.pendingEdits.splice(idx, 1); return edit;
}
function keepEdit(session, editId) { const idx = session.pendingEdits.findIndex(e => e.id === editId); if (idx === -1) throw new Error('编辑记录不存在'); return session.pendingEdits.splice(idx, 1)[0]; }
function newCheckpoint(session, label) { const cp = { id: crypto.randomBytes(4).toString('hex'), label: label || '新任务', timestamp: Date.now(), files: {} }; session.checkpoints.push(cp); session.currentCheckpoint = cp; return cp; }
async function restoreCheckpoint(session, id) {
  const idx = session.checkpoints.findIndex(c => c.id === id);
  if (idx === -1) throw new Error('检查点不存在');
  const earliest = {};
  for (let i = idx; i < session.checkpoints.length; i++)
    for (const [p, oc] of Object.entries(session.checkpoints[i].files)) if (!(p in earliest)) earliest[p] = oc;
  let restored = 0;
  for (const [rel, oc] of Object.entries(earliest)) {
    const f = safePath(rel);
    if (oc === null) { try { await fs.unlink(f); } catch {} }
    else { await fs.mkdir(path.dirname(f), { recursive: true }); await fs.writeFile(f, oc, 'utf8'); }
    restored++;
  }
  session.checkpoints.splice(idx); session.currentCheckpoint = null;
  session.pendingEdits = session.pendingEdits.filter(e => !(e.path in earliest));
  return restored;
}

async function buildTree(dir = WORKSPACE, depth = 0) {
  const name = path.basename(dir); const children = [];
  if (depth <= 6) {
    let entries = []; try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return { name, path: '.', type: 'dir', children }; }
    entries.sort((a, b) => (b.isDirectory() ? 1 : 0) - (a.isDirectory() ? 1 : 0) || a.name.localeCompare(b.name));
    for (const e of entries) {
      if (IGNORE.has(e.name) || e.name.startsWith('.')) continue;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) children.push(await buildTree(full, depth + 1));
      else children.push({ name: e.name, path: path.relative(WORKSPACE, full).replaceAll('\\', '/'), type: 'file' });
    }
  }
  return { name, path: path.relative(WORKSPACE, dir).replaceAll('\\', '/') || '.', type: 'dir', children };
}

const allClients = new Set();
let treeBT = null;
function broadcastTree() {
  if (treeBT) return;
  treeBT = setTimeout(async () => { treeBT = null;
    try { const tree = await buildTree(); const msg = JSON.stringify({ type: 'tree', tree });
      for (const ws of allClients) if (ws.readyState === 1) ws.send(msg); } catch {}
  }, 200);
}

async function flatList() {
  const out = [];
  async function walk(dir) {
    let entries = []; try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (IGNORE.has(e.name) || e.name.startsWith('.')) continue;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) await walk(full);
      else out.push(path.relative(WORKSPACE, full).replaceAll('\\', '/'));
      if (out.length > 2000) return;
    }
  }
  await walk(WORKSPACE); return out;
}

async function buildUserContent(text, attachments) {
  let textPart = text || '';
  // 附件上限：防止把大 PDF / 二进制文件当 utf8 塞进 prompt导致 LLM 400 token 超限
  const ATT_MAX_CHARS = parseInt(process.env.ATT_MAX_CHARS || '80000', 10);
  const BIN_EXT = new Set(['pdf','docx','pptx','xlsx','doc','ppt','xls','png','jpg','jpeg','gif','webp','bmp','tiff','tif','zip','tar','gz','7z','exe','dll','so','bin','stl','vtu','vtk','mp3','mp4','wav','avi','mov']);
  for (const a of (attachments || [])) {
    if (a.type === 'context_file' && a.path) {
      try {
        const abs = safePath(a.path);
        const st = await fs.stat(abs);
        const ext = (path.extname(a.path) || '').slice(1).toLowerCase();
        // 按扩展名直接判定为二进制类附件 → 不读文本，让 agent 自己调 read_document
        if (BIN_EXT.has(ext)) {
          textPart += `\n\n--- 附件 ${a.path} (.${ext} · ${st.size} 字节) 为二进制文档；请调用 read_document("${a.path}") 提取文本与图片 ---`;
          continue;
        }
        if (st.size > 8 * 1024 * 1024) {
          textPart += `\n\n--- 附件 ${a.path} 过大（${(st.size/1024/1024).toFixed(1)} MB）已跳过；请调 read_document("${a.path}") 提取文本 ---`;
          continue;
        }
        // 二进制探测：前 4KB 调 NUL
        const fh = await fs.open(abs, 'r'); const buf = Buffer.alloc(Math.min(4096, st.size));
        await fh.read(buf, 0, buf.length, 0); await fh.close();
        let nul = 0; for (let i = 0; i < buf.length; i++) if (buf[i] === 0) { nul++; if (nul > 2) break; }
        if (nul > 2) {
          textPart += `\n\n--- 附件 ${a.path} 为二进制/PDF（${st.size} 字节），不能当文本读；请调 read_document("${a.path}") ---`;
          continue;
        }
        let c = await fs.readFile(abs, 'utf8');
        let banner = '';
        if (c.length > ATT_MAX_CHARS) {
          banner = `\n... [附件共 ${c.length} 字符，仅截取前 ${ATT_MAX_CHARS}；需全文调 read_file/read_document] ...`;
          c = c.slice(0, ATT_MAX_CHARS);
        }
        textPart += `\n\n--- 附件文件 ${a.path} (${st.size} 字节) ---\n${c}${banner}\n--- 文件结束 ---`;
      } catch (e) {
        textPart += `\n\n[附件 ${a.path} 读取失败：${e.message}]`;
      }
    }
  }
  const imgs = (attachments || []).filter(a => a.type === 'image');
  if (imgs.length === 0) return textPart;
  const content = [{ type: 'text', text: textPart }];
  for (const im of imgs) content.push({ type: 'image_url', image_url: { url: im.dataUrl, detail: 'high' } });
  return content;
}

async function callLLM(messages, ws, abortSignal, toolsForCall) {
  if (SETTINGS.provider === 'copilot') return callCopilot(messages, ws, abortSignal, toolsForCall);
  if (!SETTINGS.apiKey) throw new Error('未配置 API Key，请到设置中填入');
  const TOOLS_FOR_CALL = toolsForCall || TOOLS;
  const resp = await fetch(`${SETTINGS.baseUrl.replace(/\/$/,'')}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SETTINGS.apiKey}` },
    body: JSON.stringify({ model: SETTINGS.model, messages, tools: TOOLS_FOR_CALL, tool_choice: 'auto', stream: true, stream_options: { include_usage: true }, temperature: 0.2 }),
    signal: abortSignal
  });
  if (!resp.ok) {
    const body = await resp.text();
    const hint = resp.status === 404 ? '（模型名不存在？请到 ⚙ 设置中改成 deepseek-ai/DeepSeek-V3 等有效模型）' : '';
    throw new Error(`API ${resp.status} ${hint}: ${body.slice(0, 400)}`);
  }
  return await consumeOpenAIStream(resp, ws);
}

async function consumeOpenAIStream(resp, ws) {
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let assistantMsg = { role: 'assistant', content: '', tool_calls: [] };
  let usage = null;
  // 流空闲看门狗：超过 IDLE_MS 没收到任何 chunk 就主动断开，避免 LLM/代理静默卡住把整个 agent 卡死
  const IDLE_MS = 90_000;
  let idleTimer = null;
  let idleAborted = false;
  function armIdle() {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      idleAborted = true;
      try { reader.cancel('idle-timeout'); } catch {}
    }, IDLE_MS);
  }
  armIdle();
  // 阶段心跳：在首个 token 到达前每 2s 向前端推一次 phase ，之后转入 streaming
  let firstChunk = true;
  let waitStart = Date.now();
  let phaseTimer = setInterval(() => {
    if (firstChunk) {
      const sec = ((Date.now() - waitStart) / 1000).toFixed(1);
      try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'llm_thinking', detail: `等 LLM 首个 token ${sec}s`, elapsed_ms: Date.now() - waitStart })); } catch {}
    }
  }, 2000);
  try {
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      armIdle();
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n'); buffer = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim(); if (data === '[DONE]') continue;
        try {
          const j = JSON.parse(data);
          if (j.usage) usage = j.usage;
          const delta = j.choices?.[0]?.delta; if (!delta) continue;
          if (delta.content) { assistantMsg.content += delta.content; if (firstChunk) { firstChunk = false; try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'streaming', detail: 'LLM 输出中' })); } catch {} } ws.send(JSON.stringify({ type: 'delta', text: delta.content })); }
          if (delta.tool_calls) {
            if (firstChunk) { firstChunk = false; try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'streaming', detail: 'LLM 决定调用工具' })); } catch {} }
            for (const tc of delta.tool_calls) {
              const idx = tc.index;
              if (!assistantMsg.tool_calls[idx]) assistantMsg.tool_calls[idx] = { id: tc.id || '', type: 'function', function: { name: '', arguments: '' } };
              const slot = assistantMsg.tool_calls[idx];
              if (tc.id) slot.id = tc.id;
              if (tc.function?.name) slot.function.name += tc.function.name;
              if (tc.function?.arguments) slot.function.arguments += tc.function.arguments;
            }
          }
        } catch {}
      }
    }
    // 处理流结束后残留的最后一段（部分上游不会以 \n 结尾），避免漏掉最后一个 tool_call/usage
    if (buffer && buffer.startsWith('data:')) {
      const data = buffer.slice(5).trim();
      if (data && data !== '[DONE]') {
        try {
          const j = JSON.parse(data);
          if (j.usage) usage = j.usage;
          const delta = j.choices?.[0]?.delta;
          if (delta) {
            if (delta.content) { assistantMsg.content += delta.content; if (firstChunk) { firstChunk = false; try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'streaming', detail: 'LLM 输出中' })); } catch {} } ws.send(JSON.stringify({ type: 'delta', text: delta.content })); }
            if (delta.tool_calls) {
              if (firstChunk) { firstChunk = false; try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'streaming', detail: 'LLM 决定调用工具' })); } catch {} }
              for (const tc of delta.tool_calls) {
                const idx = tc.index;
                if (!assistantMsg.tool_calls[idx]) assistantMsg.tool_calls[idx] = { id: tc.id || '', type: 'function', function: { name: '', arguments: '' } };
                const slot = assistantMsg.tool_calls[idx];
                if (tc.id) slot.id = tc.id;
                if (tc.function?.name) slot.function.name += tc.function.name;
                if (tc.function?.arguments) slot.function.arguments += tc.function.arguments;
              }
            }
          }
        } catch {}
      }
    }
  } finally {
    if (idleTimer) clearTimeout(idleTimer);
    if (phaseTimer) clearInterval(phaseTimer);
  }
  if (idleAborted) throw new Error(`LLM 流空闲超时 ${IDLE_MS/1000}s（已自动中止，可重试）`);
  if (assistantMsg.tool_calls.length === 0) delete assistantMsg.tool_calls;
  if (usage) ws.send(JSON.stringify({ type: 'usage', usage }));
  return assistantMsg;
}

// ============ GitHub Copilot Provider ============
const COPILOT = {
  clientId: 'Iv1.b507a08c87ecfe98',         // VSCode 的 GitHub OAuth client_id
  ghToken: '',                               // gho_... (long-lived OAuth)
  apiToken: '',                              // 短期 Copilot token
  apiTokenExpires: 0,                        // unix seconds
  modelsCache: null, modelsCacheTs: 0,
};
const COPILOT_FILE = path.join(__dirname, 'copilot.json');

async function loadCopilotState() {
  try {
    const j = JSON.parse(await fs.readFile(COPILOT_FILE, 'utf8'));
    COPILOT.ghToken = j.ghToken || '';
  } catch {}
}
async function saveCopilotState() {
  await fs.writeFile(COPILOT_FILE, JSON.stringify({ ghToken: COPILOT.ghToken }, null, 2), 'utf8');
}

async function copilotDeviceStart() {
  const r = await fetch('https://github.com/login/device/code', {
    method: 'POST',
    headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'User-Agent': 'GithubCopilot/1.155.0' },
    body: JSON.stringify({ client_id: COPILOT.clientId, scope: 'read:user' })
  });
  if (!r.ok) throw new Error('GitHub device 接口失败：' + r.status);
  return await r.json();    // {device_code, user_code, verification_uri, interval, expires_in}
}
async function copilotDevicePoll(deviceCode) {
  let lastErr;
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'User-Agent': 'GithubCopilot/1.155.0' },
        body: JSON.stringify({ client_id: COPILOT.clientId, device_code: deviceCode, grant_type: 'urn:ietf:params:oauth:grant-type:device_code' })
      });
      return await r.json();
    } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 800 * (i + 1))); }
  }
  throw lastErr;
}
async function copilotRefreshApiToken() {
  if (!COPILOT.ghToken) throw new Error('未登录 GitHub Copilot，请先点 🔑 登录');
  const now = Math.floor(Date.now() / 1000);
  if (COPILOT.apiToken && COPILOT.apiTokenExpires - now > 120) return COPILOT.apiToken;
  const r = await fetch('https://api.github.com/copilot_internal/v2/token', {
    headers: { 'Authorization': `token ${COPILOT.ghToken}`, 'Accept': 'application/json', 'User-Agent': 'GithubCopilot/1.155.0', 'Editor-Version': 'vscode/1.95.0', 'Editor-Plugin-Version': 'copilot-chat/0.20.0' }
  });
  if (!r.ok) {
    const t = await r.text();
    if (r.status === 401 || r.status === 403) { COPILOT.ghToken = ''; await saveCopilotState(); throw new Error('GitHub 凭据失效，请重新登录：' + t.slice(0, 200)); }
    throw new Error('Copilot token 失败 ' + r.status + ': ' + t.slice(0, 200));
  }
  const j = await r.json();
  COPILOT.apiToken = j.token; COPILOT.apiTokenExpires = j.expires_at || (now + 1500);
  return COPILOT.apiToken;
}
function copilotHeaders(token) {
  return {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Editor-Version': 'vscode/1.95.0',
    'Editor-Plugin-Version': 'copilot-chat/0.20.0',
    'Copilot-Integration-Id': 'vscode-chat',
    'User-Agent': 'GitHubCopilotChat/0.20.0',
    'Openai-Intent': 'conversation-panel',
    'X-Github-Api-Version': '2025-04-01'
  };
}
async function copilotListModels() {
  const now = Date.now();
  if (COPILOT.modelsCache && now - COPILOT.modelsCacheTs < 5 * 60 * 1000) return COPILOT.modelsCache;
  const tok = await copilotRefreshApiToken();
  const r = await fetch('https://api.githubcopilot.com/models', { headers: copilotHeaders(tok) });
  if (!r.ok) throw new Error('列出模型失败 ' + r.status + ': ' + (await r.text()).slice(0, 200));
  const j = await r.json();
  // 兼容多种返回结构：{data:[]} 或直接 []
  const raw = Array.isArray(j) ? j : (j.data || j.models || []);
  // 只保留 chat 类（排除 embedding）；如果 capabilities 缺失则一律保留
  const list = raw.filter(m => {
    const t = m?.capabilities?.type;
    return !t || t === 'chat' || t === 'completion';
  }).map(m => ({
    id: m.id,
    name: m.name || m.id,
    vendor: m.vendor || (m.id || '').split('-')[0] || '',
    tool: !!(m?.capabilities?.supports?.tool_calls),
    streaming: !!(m?.capabilities?.supports?.streaming),
    picker: m.model_picker_enabled !== false,
  }));
  COPILOT.modelsCache = list; COPILOT.modelsCacheTs = now;
  return list;
}
async function callCopilot(messages, ws, abortSignal, toolsForCall) {
  const tok = await copilotRefreshApiToken();
  const TOOLS_FOR_CALL = toolsForCall || TOOLS;
  const body = { model: SETTINGS.copilotModel || 'gpt-4.1', messages, stream: true, stream_options: { include_usage: true }, temperature: 0.2 };
  // 非所有 Copilot 模型都支持 tools；先尝试带，失败时去掉重试
  body.tools = TOOLS_FOR_CALL; body.tool_choice = 'auto';
  let resp = await fetch('https://api.githubcopilot.com/chat/completions', { method: 'POST', headers: copilotHeaders(tok), body: JSON.stringify(body), signal: abortSignal });
  if (!resp.ok) {
    const txt = await resp.text();
    if (resp.status === 400 && /tool|function/i.test(txt)) {
      delete body.tools; delete body.tool_choice;
      resp = await fetch('https://api.githubcopilot.com/chat/completions', { method: 'POST', headers: copilotHeaders(tok), body: JSON.stringify(body), signal: abortSignal });
      if (!resp.ok) throw new Error('Copilot ' + resp.status + ': ' + (await resp.text()).slice(0, 300));
      ws.send(JSON.stringify({ type: 'term', line: `[Copilot] 模型 ${body.model} 不支持 tools，已降级为纯对话` }));
    } else if (resp.status === 401) {
      COPILOT.apiToken = ''; throw new Error('Copilot 401：' + txt.slice(0, 200));
    } else {
      throw new Error('Copilot ' + resp.status + ': ' + txt.slice(0, 300));
    }
  }
  return await consumeOpenAIStream(resp, ws);
}



const SYSTEM_PROMPT_BASE = (ws) => `你是 NullFlux —— 中文编码 + CFD 仿真智能体（作者 LZF），运行在用户本机（${process.platform}）。

# 工作目录
${ws}

# Python 解释器（用户在顶部 🐍 按钮选择的）
${SETTINGS.pythonPath ? SETTINGS.pythonPath : '（未选择，将使用 PATH 上默认 python）'}
> 你只需照常写 "python xxx.py" / "pip install xxx"，后端会自动替换为上面这个解释器。

# 重要：运行代码的规则
- 用户说"运行 xxx.py" / "执行 xxx" / "跑一下" → **立即调 run_command**，不要先咨询。
- 输出会实时出现在本地终端面板。
- 缺依赖先 \`pip install xxx\` 也用 run_command（会自动装到选中的环境）。
- .ipynb 执行：run_command("jupyter nbconvert --to notebook --execute --inplace xxx.ipynb")。

# 联网工具（如启用）
- web_search(query, top_k?, topic?, time_range?)：通用联网搜索；优先 Tavily/Serper/Brave/SearXNG，无 Key 时回落 HTML 爬取。**找新闻 / 教程 / 文档** 用这个。
- paper_search(query, top_k?, year?, open_access_only?)：**学术论文检索**（Semantic Scholar + arXiv 合并），按引用 + 新鲜度排序。找算法原文、综述、SOTA → 优先用它，不要用 web_search。
- paper_fetch(id, download?, max_refs?)：按 DOI/ARXIV/S2-ID 拿摘要 + TLDR + references；download=true 可把 OA PDF 存到 downloads/papers/。
- fetch_url(url, max_chars?, with_images?)：拉网页正文；with_images=true 同时列出页内图片链接。
- read_paper(path, focus?)：**比 read_document 更强**，自动切 Abstract/Methods/Results/References 并统计公式与图表数；focus="..." 高亮命中段落。读论文优先用它。
- vision_analyze(images[], question)：**高清细看图片**（detail=high + 专用 VLM 提示）。需要读曲线数值 / 公式 / 表格 / 流程图就用它，比把图片当附件粘进对话更可靠。
- image_search(query)：图片搜索。

# 文献工作流（论文/算法复现专用）
1. paper_search → 用户选编号 →
2. paper_fetch(id, download=true) → 拿到 downloads/papers/xxx.pdf →
3. read_paper(path, focus="drag model" / "boundary condition" / "lattice scheme") →
4. 如果有关键图表（流程图/曲线/公式/物性表）：vision_analyze 提取数值 →
5. update_todos 把算法步骤拆成 5–15 项，再按 FOAM/MFIX/LBM 工作流落地。

# 长程任务
1. 任务复杂时先 update_todos 拆 5–20 项可验证待办（多拆不差）。
2. 完成一项 → done=true。
3. 改完代码 → run_command 跑试试 → 失败读错 → 修→再跑。
4. 全部完成才调 task_complete。

# 规则
- 修改文件前一句话说明意图；优先 edit_file。
- 中文回答、中文注释。

# 网格自动核对闭环（v4.6 强制策略 / OpenFOAM 模式）
- **凡是 foam_run_solver_async 跑 blockMesh / snappyHexMesh / snappyHexMesh -overwrite，结束后必须立刻调 foam_mesh_verify(case_path, stage='blockMesh' 或 'snappy')，再决定下一步。** 不允许直接进求解器。
- **凡是要做 snappy，先 foam_stl_render(stl_path) 肉眼核对法向/封闭/比例，再 foam_mesh_plan。**
- foam_mesh_verify 返回 pass=false 时：① 看 metrics 的 maxNonOrtho/skew/negVol；② 看 vision 的视觉描述；③ 用 edit_file 修 system/blockMeshDict 或 system/snappyHexMeshDict；④ 重新跑 → 再 verify。最多 3 次失败后启动**自动降档**：foam_mesh_plan(strategy='coarsen') → 'minimal' → 'box_stl'。
- snappy 之后必须 foam_patch_diff(case_path) 确认 inlet/outlet/walls 是否真的切出来；丢 patch 就是 mesh_plan 的 location_in_mesh 选错了。
- 这套闭环是硬约束，不要因为"看起来网格还行"就跳过 verify。`;

// SIM_PROMPT removed in v2: lightweight sim-mode hint was redundant.
// ParaView tools (sim_render / sim_open_paraview / sim_run_openfoam) remain available
// and are referenced from FOAM_PROMPT / MFIX_PROMPT / LBM_PROMPT directly when those Beta modes are enabled.

const sessions = new Map();

// ====================== 工具执行进度心跳（让用户看见 agent 在干啥） ======================
// 在每次 execTool 周围发出 ⏳ 开始 / 周期性 …仍在运行 Ns / ✔ 完成 用时 的终端日志。
const PROGRESS_INSTANT = new Set(['list_dir','read_file','grep_search','glob','update_todos','task_complete']);
function _summarizeArgs(args) {
  try {
    if (!args || typeof args !== 'object') return '';
    const keys = Object.keys(args);
    if (!keys.length) return '';
    const k = keys[0];
    let v = args[k];
    if (Array.isArray(v)) v = `[${v.length} 项]`;
    else if (typeof v === 'object' && v) v = JSON.stringify(v).slice(0, 80);
    else v = String(v);
    v = v.replace(/\s+/g, ' ').slice(0, 100);
    return `${k}=${v}${keys.length > 1 ? `, +${keys.length-1} 参` : ''}`;
  } catch { return ''; }
}
async function execToolWithProgress(name, args, session, ws) {
  // 即时类工具不打心跳（否则刷屏）
  if (PROGRESS_INSTANT.has(name)) return execTool(name, args, session, ws);
  const start = Date.now();
  const summary = _summarizeArgs(args);
  try { ws.send(JSON.stringify({ type: 'term', line: `⏳ ${name}(${summary}) …` })); } catch {}
  let lastTick = start;
  const interval = setInterval(() => {
    const sec = ((Date.now() - start) / 1000).toFixed(1);
    try { ws.send(JSON.stringify({ type: 'term', line: `   …${name} 仍在运行 ${sec}s（可点 ⏹ 随时终止）` })); } catch {}
    try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'tool_exec', detail: `${name} 运行 ${sec}s`, tool: name, elapsed_ms: Date.now() - start })); } catch {}
    lastTick = Date.now();
  }, 2500);
  // 把心跳通道暴露给工具内部（webSearch/paperSearch 可用）
  const prevPub = session._progressPub;
  session._progressPub = (line) => { try { ws.send(JSON.stringify({ type: 'term', line: `   · ${name}: ${line}` })); } catch {} };
  // 不保证工具内部响应 abort 信号（很多 fetch 没走 signal）。
  // 用 Promise.race 跟 abortPromise 赛跑：一旦用户点停止，立刻返回【已取消】，
  // 不再等任何慢工具跑完才出环。
  const abortPromise = new Promise((resolve) => {
    if (!session.aborter || !session.aborter.signal) return;
    const sig = session.aborter.signal;
    if (sig.aborted) return resolve('__ABORTED__');
    sig.addEventListener('abort', () => resolve('__ABORTED__'), { once: true });
  });
  try {
    const winner = await Promise.race([
      execTool(name, args, session, ws).then(v => ({ ok: true, v })).catch(e => ({ ok: false, e })),
      abortPromise.then(() => ({ ok: 'abort' }))
    ]);
    if (winner.ok === 'abort') {
      const sec = ((Date.now() - start) / 1000).toFixed(2);
      try { ws.send(JSON.stringify({ type: 'term', line: `⦻ ${name} 已取消（耗时 ${sec}s，用户请求停止）` })); } catch {}
      return '[已取消：用户请求终止]';
    }
    if (winner.ok === false) { throw winner.e; }
    const r = winner.v;
    const sec = ((Date.now() - start) / 1000).toFixed(2);
    const size = typeof r === 'string' ? r.length : 0;
    try { ws.send(JSON.stringify({ type: 'term', line: `✔ ${name} 完成（耗时 ${sec}s，返回 ${size} 字符）` })); } catch {}
    return r;
  } catch (e) {
    const sec = ((Date.now() - start) / 1000).toFixed(2);
    try { ws.send(JSON.stringify({ type: 'term', line: `✘ ${name} 失败（耗时 ${sec}s）：${e.message || e}` })); } catch {}
    throw e;
  } finally {
    clearInterval(interval);
    session._progressPub = prevPub;
  }
}

function broadcastCheckpoints(ws) { const s = sessions.get(ws); if (!s) return;
  ws.send(JSON.stringify({ type: 'checkpoints', list: s.checkpoints.map(c => ({ id: c.id, label: c.label, timestamp: c.timestamp, fileCount: Object.keys(c.files).length })) })); }
const FOAM_PROMPT = `

# OpenFOAM Beta 仿真模式（已开启）
OpenFOAM 根目录：${SETTINGS.foamRoot || '(未设置！请先 /api/foam/config 或在 Beta 面板填写)'}

## 你拥有的额外工具
- foam_find_tutorial(query, top_k?)：查 tutorials/。
- foam_find_source(query, kind?)：查 src/ + applications/。
- foam_clone_tutorial(tutorial_path, dest)：把 tutorial 拷到工作区。
- foam_inspect_case(case_path)：列 0/ constant/ system/ + 边界条件矩阵 + **完整文件清单（递归）**。
- foam_run_solver_async(case_path, command)：**长任务专用**。后台启动求解器/blockMesh/checkMesh，立刻返回 runId，不阻塞会话。
- foam_solver_status(run_id)：取最新 Time、最近残差、log tail、是否还在跑。
- foam_solver_stop(run_id)：终止后台作业。
- 已有：list_dir / read_file / edit_file / multi_edit / sim_render / sim_run_openfoam（短命令同步用）。

## 🌊 流水式工作流（必须严格按 5 步走）

**第 1 步 · 问意图**
开口先问：「你**已经有具体算例**了吗？」给出两个明确选项让用户回（用户也可能直接点 UI 按钮帮你选）：
  ① 我有具体算例 —— 请提供 case 路径，或在工作区里指给我看；
  ② 我没有 —— 请告诉我**关键词**（如 bubbleColumn / twoPhaseEulerFoam / RANS / 自然对流 …）

**第 2 步 · 算例选择**
- 若用户答①：直接到第 3 步。
- 若用户答②：调用 \`foam_find_tutorial\` 用关键词搜本地 tutorials/，取前 8–12 个候选；用 \`update_todos\` 列出**带编号的候选清单**（每条一行：solver / 物理 / 路径），并在聊天里**用 1) 2) 3) 编号**列给用户，让用户回编号选 1 个。**禁止**直接帮用户选。
- 用户选了之后调 \`foam_clone_tutorial\` 拷到工作区。

**第 3 步 · 完整遍历 + 分析**
对最终的 case 路径调 \`foam_inspect_case\` 一次（**它已经包含递归文件清单**，不要再一个个 read_file 列目录）。
拿到结果后做两件事：
  a. **列出所有可改项**：边界条件 / 物性 / 网格(blockMeshDict) / 求解器选择 / 时间步 / 写出频率 / 并行分解 …  用 \`update_todos\` 写成 5–20 项的清单；
  b. 在聊天里**给用户「推荐选项按钮」**：每一项给 1 个推荐默认值 + 2~4 个常见可选值，用 1)2)3) 编号列出，明确标注「**默认：B**」让用户能 1 个回车跳过。例：
       「U 入口速度 (b.c.)：1) fixedValue 0.1 m/s ✅默认  2) flowRateInletVelocity  3) codedFixedValue  → 回 1/2/3 或直接回车用默认」

**第 4 步 · 一次只问 1 项 + 应用**
按 todo 顺序一次只问一个，等用户回；
- 用户回了就调 \`edit_file\` / \`multi_edit\` 改对应 dictionary，
- 调 \`update_todos\` 把这一项 done=true，
- 紧接着问下一项；
**禁止**一次抛 5 个问题给用户。

**第 5 步 · 跑算例 + 间隔监测**
所有 todo 都 done 之后：
  1. **逐步跑**（每一步用 \`foam_run_solver_async\` 启动，告诉用户 runId，让用户在「求解器监测」面板订阅）：
       blockMesh → checkMesh → (decomposePar 可选) → 求解器
  2. **每个 runId 启动后**，**不要立刻接着调** \`foam_solver_status\`。告诉用户：
       「已启动 runId=xxxx。监测面板每 N 秒自动刷新；你也可以让我查询 \`foam_solver_status\`。」
  3. 用户问"现在跑成什么样了"时再调 status；用户说"停"就 \`foam_solver_stop\`。
  4. 求解器结束后调 \`sim_render\` 出图。

## 重要纪律
- **回答尽量短**，多用编号清单，不要长段落。
- **没问明白前不动 edit_file**。
- 长任务一律走 \`foam_run_solver_async\`，**绝不**用同步 \`sim_run_openfoam\` 跑会跑几分钟以上的求解器。
- 若 foamRoot 未设：先告诉用户在右边 "OpenFOAM (Beta)" 面板填写 OpenFOAM 安装路径。

## 📄 论文 → OpenFOAM 植入工作流（独立子流程）

当用户提供 PDF 路径，或说"把这篇论文里的算法实现到 OpenFOAM"，按如下步骤：

**P1 · 读论文**
- 调 \`read_document(path)\` 拿全文（已自动 PDF/DOCX 解析）。返回长度上限 ~20K 字，足够定位算法。
- 如果太长，再次 \`read_document\` 不会更多——直接基于已抓到的文本提炼。

**P2 · 总结成 4 项摘要**（用 \`update_todos\` 写成可勾选清单）：
  ① **算法名 / 类别**（drag model / turbulence closure / interfacial heat / population balance / VOF surface tension / …）
  ② **核心公式**（用 LaTeX 或纯文本贴出关键式 1–3 个，标 Eq. 编号）
  ③ **变量与常数**（输入字段：U, alpha, d, ρ, μ, T, k, ε…；常数：a, b, n, Re_c…）
  ④ **应替换/扩展的 OpenFOAM 模块类别**（drag / turbulence / phaseSystem / radiation / fvOptions / boundary condition / solver 主程序）

**P3 · 在源码中找最近的"参考实现"**
- 调 \`foam_find_source(query, kind)\`：query = 同类已有模型名（如 SchillerNaumann / WenYu / Ergun / kEpsilon / MulesAdvect / dragModel / phaseModel），kind = solver/model/bc/all。
- 用 \`read_file\` 读其 .H/.C 各一份，**把骨架贴回聊天**（≤80 行核心段），说明：
   - 类继承关系（如 \`: public dragModel\`）
   - runTimeSelectionTable 注册宏
   - 关键虚函数：\`K()\` / \`CdRe()\` / \`Cv()\` / \`updateCoeffs()\` …

**P4 · 给用户决策菜单**（每项 1)2)3) 编号，**默认值 ✅**）：
  1) 实现方式：1) **新增** Foo 模型 ✅ 与原模型并列，runTimeSelection 选；2) 直接修改某已有模型；3) 在已有 case 里 \`fvOptions\` codedSource 注入
  2) 放在哪个目录：1) **工作区** \`models/dragModels/Foo/\` ✅；2) OpenFOAM 源码树（需重编 lib，不推荐）
  3) 物理参数怎么传：1) **从 phaseProperties 读** ✅；2) 写死编译；3) 用 \`fvOptions\` dictionary
  4) 验证 case：1) **克隆** bubbleColumn 教程 ✅ + 把 drag 换成 Foo；2) 用户给 case；3) 不验证

**P5 · 落地（只有用户回了 P4 的 4 个选项才动）**
- 按选定方式，**逐文件** \`write_file\` 创建 \`Foo.H\` / \`Foo.C\` / \`Make/files\` / \`Make/options\`，每个文件 commit 前先在聊天里贴 diff 摘要。
- 如果新增模型：再帮用户在 case 的 \`constant/phaseProperties\` 把 dragModel 选项改成 \`Foo\`。
- 用 \`foam_run_solver_async\` 调 \`wmake libso\` 编译；编译失败把错误最后 30 行抓出来定位。
- 编译过了再启动验证 case 的 blockMesh→checkMesh→solver。

**P6 · 出图与对比**
- \`sim_render\` 出最终时刻的关键场（α / U / k / ε），上色看是否定性合理。
- 若用户给了原论文图，提示用户用相同截面/时刻渲染做对比。

**纪律**
- P2 摘要别超过 200 字；引用论文里的 Eq. 编号让用户能复核。
- 没有 P3 的参考实现就**不要凭空**写 .C，先告诉用户"没找到合适参考，建议手动指一个最像的现成模型给我"。
- 编译错误别一次塞 100 行 log，只贴最关键的 \`error:\` / \`undefined reference\` 那 5–10 行。

## 🔧 STL → 网格自动化工作流（用户给 STL 时走这个）

当用户提供 STL（绕物外流 / 内流 / 反应器），按如下步骤：

**M1 · 几何检查** \`foam_stl_inspect(stl_path)\` → 拿到 bbox/centroid/单位猜测/推荐 cell_size。
   - 若 unit_guess 提示 mm，**先**告诉用户"你的 STL 像是毫米单位，建议先 surfaceTransformPoints -scale 0.001 转米"，等用户确认。

**M2 · 工况确认（一次性问完，编号选项 + ✅ 默认）**
   1) 流动类型：1) **外流绕物 ✅**（inlet/outlet/wall）；2) 内流通道；3) 自然对流
   2) 主流方向：1) **+x ✅**；2) +y；3) +z
   3) 雷诺数 / 来流速度（给个推荐范围）
   4) 求解器：1) **simpleFoam ✅** 稳态不可压；2) pimpleFoam 瞬态；3) rhoSimpleFoam 可压；4) interFoam 多相
   5) 湍流：1) **k-omega SST ✅**；2) k-epsilon；3) Spalart-Allmaras；4) 层流
   6) 网格细度：1) **粗 (~50K cells)**；2) **中 ✅ (~300K)**；3) 细 (~2M)
   7) 边界层：0 / 3 / 5 层（推荐根据 y+ ≈ 30）

**M3 · 网格生成（3 次失败倒换梯子）**
   - **默认档 (attempt 1：strategy=default)**：调 \`foam_mesh_plan(case_path, stl_path, target_cell_size, refinement_level_min, refinement_level_max, n_layers, flow_direction)\` 一次性写出 blockMeshDict / snappyHexMeshDict / surfaceFeaturesDict + 复制 STL 到 constant/triSurface/。
   - 然后 \`foam_run_solver_async\` 按序执行：blockMesh → surfaceFeatures（或 surfaceFeatureExtract）→ snappyHexMesh -overwrite → checkMesh。
   - 每步只在前一步 \`foam_solver_status\` 显示 exit=0 之后再启动下一步。

   - **重试梯子 — blockMesh / snappyHexMesh 连续失败时**（严格遵守，避免重复调同一参数浪费时间）：
     - **attempt 2 (总第2次)**：同一错误发生过一次 → 换 \`strategy='coarsen'\` 重调 \`foam_mesh_plan\`（cell×1.5、max_level-1、取消边界层）。
     - **attempt 3**：还不行 → \`strategy='minimal'\`（cell×2、只留 castellated，snap=false、addLayers=false），先保证 checkMesh 能过。
     - **attempt 4 （梯子末端）**：倒换“纯STL”组合策略：
        1. 调 \`foam_mesh_box_stl(case_path, bbox_min, bbox_max, name='domain_box')\` 写出外域包围盒 STL（bbox 取 foam_stl_inspect 结果外扩 1.5×~5×，同 default 逻辑）。
        2. 手动改 snappyHexMeshDict：在 geometry 里加入 domain_box.stl（作为外埌），原 STL 作为内部 refinement；locationInMesh 放在 domain_box 内、物体外。
        3. 还是 blockMesh 起步（粗背景） → snappyHexMesh 靠双 STL 控制实际流场边界。
     - **超过 4 次仍失败**：停下来，把 最后一次 checkMesh / snappyHexMesh 的关键错误行（5–10 行）贴回聊天，问用户是否：① 提供替代 STL；② 手动给 locationInMesh；③ 改用 \`foam_clone_tutorial\` 拉个最接近的现成模板。不要再倒换。

   - **每轮重试前必须告诉用户**：「第 N 次尝试，换策略 X，原因：error = ...」，然后再调用。避免默默反复跳。

**M4 · 物理与边界条件**
   - 用 \`foam_clone_tutorial\` 拉一个最近模板的 0/、constant/turbulenceProperties、constant/transportProperties，复制进当前 case；按 M2 的回答改 inlet U/p/k/omega、wall noSlip。
   - **不要**手写 0/ 文件夹的 11 个场，直接拷模板再改值。

**M5 · 跑求解 + 监测**
   - \`foam_run_solver_async\` 启动 simpleFoam（或选定求解器）。
   - **每隔 3–5 步迭代或 30s** 调一次 \`foam_residual_series(run_id, max_points=30, fields=['U','p','k','omega'])\`，把 trends 段贴回聊天（不是整个 series）：
     - 若 trends.U.status === '发散/震荡' → 告诉用户"建议把 nNonOrthogonalCorrectors 加到 2，或松弛因子 p 0.3 → 0.2"。
     - 若 'stagnation-高残差' → 网格质量差，建议重跑 checkMesh 看 maxNonOrtho。
     - 若 '收敛中' → 继续等。
   - **绝不**把整个 series 数组贴回聊天，只贴 trends + 最后 5 步。

**M6 · 渲染对比**
   - 收敛后 \`sim_render(case_path, field='U')\` 出图。
   - 如有 baseline case 或论文参数，调 \`foam_compare_render(case_a, case_b, field='U')\` 并排出图自动推到聊天。

## 📊 残差时序读取规则（任何求解器跑起来都适用）

调 \`foam_residual_series\` 后，**只把 trends 字段** + 最后 3 步的 series 贴回聊天，例如：
\`\`\`
U: slope=-0.42, last=-5.1, 收敛中 ✅
p: slope=-0.18, last=-3.4, 收敛中 ✅
k: slope=+0.12, last=-2.0, 发散/震荡 ⚠
\`\`\`
然后**直接给修复建议**，不让用户自己看 80 行残差表。
`;

const MFIX_PROMPT = `

# MFIX Beta 仿真模式（已开启）
MFIX 根目录：${SETTINGS.mfixRoot || '(未设置！请到右侧 "MFIX (Beta)" 面板填写 MFIX 安装路径)'}
MFIX 激活脚本：${SETTINGS.mfixBash || '(未设置 — 通常是 \\$MFIX_HOME/build/.../activate 或 conda activate mfix)'}

## 你拥有的额外工具
- mfix_find_tutorial(query, top_k?)：在 MFIX 安装的 tutorials/ 中按关键字搜算例（含 mfix.dat / *.mfx 的目录）。
- mfix_clone_tutorial(tutorial_path, dest)：把 tutorial 拷到工作区。
- mfix_inspect_case(case_path)：解析 mfix.dat / *.mfx，提取 RUN_TYPE / TIME / DT / GEOMETRY / IMAX-JMAX-KMAX / MMAX / BC_* / IC_* 关键 keyword + 列文件清单。
- mfix_run_solver_async(case_path, command?)：**长任务专用**。默认 \`mfixsolver\`；可用 \`mpirun -np N mfixsolver\` 或 \`mfixsolver -f xxx.mfx\`。立刻返回 runId，不阻塞会话。需审批。
- mfix_solver_status(run_id)：取最新 Time、最近残差行、log tail、是否还在跑。
- mfix_solver_stop(run_id)：终止后台作业。
- 渲染：用 sim_render(case_path) 调 pvpython 离屏渲染（MFIX 会生成 VTK / VTU / PVD 输出，自动识别）。

## 🌊 流水式工作流（必须严格按 5 步走，和 OpenFOAM 同款）

**第 1 步 · 问意图**
开口先问：「你**已经有具体算例**了吗？」给两个选项：
  ① 我有具体算例 — 请提供 case 路径；
  ② 我没有 — 请告诉我**关键词**（如 fluidBed / spouted / 喷动床 / 颗粒 / TFM / DEM / PIC / Geldart-B …）

**第 2 步 · 算例选择**
- 用户答①：直接到第 3 步。
- 用户答②：调 \`mfix_find_tutorial\` 取 8–12 个候选；用 \`update_todos\` 列编号清单，并在聊天里用 1) 2) 3) 让用户回编号选 1 个。**禁止**直接代选。
- 用户选好后 \`mfix_clone_tutorial\` 拷到工作区。

**第 3 步 · 解析 + 列可改项**
对最终 case 调 \`mfix_inspect_case\` 一次（已含文件清单，**不要**再 read_file 一个个列）。然后做两件事：
  a. **列出所有可改项**：几何 (IMAX/JMAX/KMAX、XLENGTH 等) / 时间 (DT, TSTOP) / 物理 (MU_g, RO_g, RO_s, D_p) / 边界 (BC_* — Type/U_g/V_g/P_g) / 初始 (IC_* — EP_g, T_g) / 输出频率 (RES_DT, SPX_DT) / 求解模式 (RUN_TYPE NEW/RESTART_1)。用 \`update_todos\` 写成 5–15 项清单。
  b. 在聊天里给「推荐选项按钮」：每项 1 个推荐 + 2~4 常见选项，标注「**默认：B**」。例：「DT (时间步长)：1) 5e-4 ✅默认  2) 1e-3 (粗)  3) 1e-4 (细)  → 回 1/2/3 或直接回车」。

**第 4 步 · 一次只问 1 项 + 应用**
按 todo 顺序一次只问一个；用户答了就 \`edit_file\` 改对应 keyword（注意 MFIX keyword 是 \`KEYWORD = value\` 大写格式），\`update_todos\` 标 done，紧接着下一项。**禁止**一次抛 5 个问题。

**第 5 步 · 跑算例 + 监测**
所有 todo 都 done 之后：
  1. 用 \`mfix_run_solver_async(case_path)\` 启动求解器；告诉用户 runId 与监测面板。
  2. **不要立刻**接着调 \`mfix_solver_status\`。监测面板会自动刷新；用户问"现在怎么样"再调 status；用户说"停"就 \`mfix_solver_stop\`。
  3. 跑完后调 \`sim_render(case_path)\` 出图（MFIX VTK 输出会自动识别）。

## 重要纪律
- **回答短**，多用编号清单。
- **没问明白前不动 edit_file**。
- 长任务一律走 \`mfix_run_solver_async\`，**禁止**用同步 run_command 跑会跑几分钟以上的求解器。
- 若 mfixRoot 未设：先告诉用户在右侧 "MFIX (Beta)" 面板填写 MFIX 安装路径。
- MFIX keyword 改值时注意：单位制 SI（kg, m, s）；颗粒相 MMAX 索引从 1 开始；BC_ID 范围。
- 中文回答、中文注释。
`;

const LBM_PROMPT = `

# LBM Beta 仿真模式（已开启）
LBM 算例根目录（用户提供）：${SETTINGS.lbmTutorialRoot || '(未设置！请到右侧 "LBM (Beta)" 面板填写)'}
LBM 默认运行命令：${SETTINGS.lbmRunCmd || '(未设置 — 每次让用户给或在面板填默认模板)'}

## 你拥有的额外工具
- lbm_find_tutorial(query, top_k?)：在用户提供的算例根目录里按关键字搜（任何含 README/*.py/*.cpp/input.*/params.* 的子目录都算候选）。
- lbm_clone_tutorial(tutorial_path, dest)：把算例拷到工作区。
- lbm_inspect_case(case_path, algorithm?)：列文件清单 + 自动识别算法骨架（D2Q9/D3Q19/D3Q27、BGK/MRT/TRT/Cumulant/Regularized、是否多相 Shan-Chen / 自由能、是否含 collision/propagate/equilibrium）+ 提取 README/params 关键参数。
- lbm_run_async(case_path, command?)：**长任务专用**。后台跑任意命令（python3 main.py / ./lb / mpirun -np 4 ./lb / cmake --build … && ./run）。立刻返回 runId。需审批。
- lbm_solver_status(run_id)：取 log tail，自动提取通用 print 风格的时间步与误差/macroscopic 指标。
- lbm_solver_stop(run_id)：终止后台作业。
- 渲染：用 sim_render(case_path) 调 pvpython 离屏渲染（LBM 通常输出 *.vti / *.vtk / *.npz；前两种自动识别）。

## 🌊 工作流（5 步）

**第 1 步 · 问意图**
开口先问 3 件事，用编号让用户回：
  ① 你**算法**用什么？1) D2Q9-BGK  2) D3Q19-BGK  3) D3Q19-MRT  4) D3Q27-Cumulant  5) 多相 Shan-Chen  6) 其他（请告诉我）
  ② 你有**具体算例**吗？1) 有，路径=…  2) 没有，让我列教程候选（需 \`lbm_find_tutorial\`）  3) 我只有论文，让你帮我从零搭
  ③ 你要的**目标**：1) 重跑验证  2) 改 Re/Ma/网格做参数扫描  3) 改算法（如 BGK→MRT 稳定性测试）

**第 2 步 · 算例就绪**
- 选 ①.2：\`lbm_find_tutorial\` 取候选，编号列给用户，等回数字。\`lbm_clone_tutorial\` 拷过来。
- 选 ①.3：先 \`read_document(pdf)\` 读论文，按 OpenFOAM 论文植入工作流（P1–P6）的方式拆"算法-公式-变量-OpenFOAM 等价"四要素，但**不要**真去改 OpenFOAM 源码——LBM 是用户自己的代码。先确认算法主体（D2Q9 BGK 还是 D3Q19 MRT），再让用户给一个最近的代码模板做改写起点。

**第 3 步 · 检查 + 列可改项**
调 \`lbm_inspect_case(case_path, algorithm)\` 一次。然后用 \`update_todos\` 写出可改项：
  - 网格分辨率 NX/NY/NZ
  - 雷诺数 Re（或同时给 tau, u_lb 推 Re）
  - 总步数 / 输出频率
  - 边界条件（Zou-He / bounce-back / extrapolation）
  - 初始条件（uniform / Couette / shear layer）
  - 算法切换（BGK→MRT / MRT→Cumulant）
每项给推荐 + 选项。

**第 4 步 · 一次一问 + 应用**
按 todo 顺序，每次只问一项；用户答完 \`edit_file\` 改源码 / params / input；\`update_todos\` 标 done；下一项。

**第 5 步 · 跑 + 监测**
  1. 若是 C++ 算例先 \`lbm_run_async(case_path, "cmake -S . -B build && cmake --build build -j")\` 编译。
  2. 然后 \`lbm_run_async(case_path, "<run command>")\`。
  3. 不要立刻调 status；监测面板自动刷新。
  4. 跑完调 \`sim_render(case_path)\` 出图（找最新的 *.vti / *.vtk）。

## 重要纪律
- **回答短**，多用编号清单。
- LBM 收敛判据：跟踪 \`||u^{n+1}-u^n||/||u^n||\` 而非 OpenFOAM 风格残差；如果用户的 print 里有这类指标，调 status 时把它提出来。
- 算法核心三函数：\`equilibrium / collision / streaming\`——改算法时**先**找出这三处，再讨论改什么。
- 单位用格子单位（lattice units），告诉用户 \`u_lb < 0.1\` 才稳，否则建议把 NX 加大或 dt 减小。
- 没有数据库 → 任何"哪个 tutorial 含 XX 算法"都必须通过 \`lbm_find_tutorial\` 实地搜，**禁止**编造路径。
- 中文回答、中文注释。
`;

// ====================== MFIX-Beta 实现 ======================
function mfixRoot() {
  const r = SETTINGS.mfixRoot && String(SETTINGS.mfixRoot).trim();
  if (!r) throw new Error('未设置 MFIX 根目录。请在右侧 "MFIX (Beta)" 面板填写，或 POST /api/mfix/config {root}');
  return r;
}
async function mfixFindTutorial(query, topK = 12) {
  const root = mfixRoot();
  const tut = path.join(root, 'tutorials');
  try { if (!(await fs.stat(tut)).isDirectory()) throw 0; } catch { throw new Error(`tutorials 目录不存在：${tut}`); }
  const q = String(query || '').toLowerCase();
  const hits = []; // {p, score}
  async function walk(dir, depth = 0) {
    if (depth > 6) return;
    let ents; try { ents = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    let hasInput = false;
    for (const e of ents) if (!e.isDirectory() && (e.name === 'mfix.dat' || /\.mfx$/i.test(e.name))) { hasInput = true; break; }
    if (hasInput) {
      const rel = path.relative(tut, dir);
      const score = (rel.toLowerCase().includes(q) ? 10 : 0) + (path.basename(dir).toLowerCase().includes(q) ? 5 : 0);
      if (q === '' || score > 0) hits.push({ p: rel || path.basename(dir), score });
    }
    for (const e of ents) if (e.isDirectory()) await walk(path.join(dir, e.name), depth + 1);
  }
  await walk(tut);
  hits.sort((a, b) => b.score - a.score);
  const top = hits.slice(0, topK);
  if (!top.length) return `[mfix_find_tutorial] "${query}" → 0 条候选。请换关键词或检查 ${tut} 是否含 mfix.dat / *.mfx。`;
  return `[mfix_find_tutorial] "${query}" → ${top.length} 条候选（按相关度）：\n` +
    top.map((h, i) => `  ${i + 1}) ${h.p}`).join('\n');
}
async function mfixCloneTutorial(tutorialPath, dest) {
  if (!tutorialPath) throw new Error('tutorial_path 必填');
  if (!dest) throw new Error('dest 必填');
  const root = mfixRoot();
  const src = path.isAbsolute(tutorialPath) ? tutorialPath : path.join(root, 'tutorials', tutorialPath);
  try { if (!(await fs.stat(src)).isDirectory()) throw 0; } catch { throw new Error(`源目录不存在：${src}`); }
  const hasInput = (await fs.readdir(src)).some(n => n === 'mfix.dat' || /\.mfx$/i.test(n));
  if (!hasInput) return `警告：${src} 看起来不是 MFIX case（缺 mfix.dat / *.mfx），未复制。请先用 mfix_find_tutorial 定位到具体 case。`;
  const target = path.isAbsolute(dest) ? dest : path.resolve(WORKSPACE, dest);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.cp(src, target, { recursive: true, force: false, errorOnExist: false });
  return `已复制 MFIX tutorial：\n  源：${src}\n  目标：${path.relative(WORKSPACE, target)}\n建议下一步：mfix_inspect_case("${path.relative(WORKSPACE, target)}")`;
}
async function mfixInspectCase(casePath) {
  if (!casePath) throw new Error('case_path 必填');
  const cd = path.isAbsolute(casePath) ? casePath : path.resolve(WORKSPACE, casePath);
  try { if (!(await fs.stat(cd)).isDirectory()) throw 0; } catch { throw new Error(`目录不存在：${cd}`); }
  const ents = await fs.readdir(cd);
  const inputs = ents.filter(n => n === 'mfix.dat' || /\.mfx$/i.test(n));
  if (!inputs.length) return `[mfix_inspect_case] ${cd}\n未发现 mfix.dat 或 *.mfx 输入文件。`;
  const out = [`[mfix_inspect_case] ${cd}`, `输入文件: ${inputs.join(', ')}`, ''];
  for (const f of inputs.slice(0, 2)) {
    const full = path.join(cd, f);
    let raw = '';
    try { raw = await fs.readFile(full, 'utf8'); } catch (e) { out.push(`[读取失败] ${f}: ${e.message}`); continue; }
    out.push(`--- ${f} 关键 keyword ---`);
    const KEYS = /^\s*(RUN_NAME|RUN_TYPE|DESCRIPTION|UNITS|TIME|TSTOP|DT|DT_MIN|DT_MAX|COORDINATES|XLENGTH|YLENGTH|ZLENGTH|IMAX|JMAX|KMAX|MMAX|MU_g0|MU_g|RO_g0|RO_g|MW_AVG|D_p\d*|RO_s\d*|EP_star|GRAVITY|FRICTION_MODEL|BC_X_[ew]|BC_Y_[ns]|BC_Z_[tb]|BC_TYPE|BC_U_g|BC_V_g|BC_W_g|BC_P_g|BC_T_g|BC_EP_g|IC_X_[ew]|IC_Y_[ns]|IC_Z_[tb]|IC_EP_g|IC_U_g|IC_V_g|IC_W_g|IC_P_g|IC_T_g|RES_DT|SPX_DT|OUT_DT|NODESI|NODESJ|NODESK|SOLIDS_MODEL|KT_TYPE)\s*=/i;
    for (const line of raw.split(/\r?\n/)) {
      if (KEYS.test(line) && line.length < 200) out.push('  ' + line.trim());
    }
    out.push('');
  }
  // 文件清单（递归，最多 400 项）
  out.push('--- 文件清单 (递归) ---');
  const allFiles = [];
  async function walk(dir, rel = '') {
    if (allFiles.length > 400) return;
    let es; try { es = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of es) {
      if (allFiles.length > 400) return;
      const sub = path.join(dir, e.name); const rsub = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) await walk(sub, rsub); else allFiles.push(rsub);
    }
  }
  await walk(cd);
  out.push(...allFiles.map(f => '  ' + f));
  if (allFiles.length > 400) out.push('  … (已截断，超过 400 项)');
  return out.join('\n');
}
async function mfixRunSolverAsync({ case_path, command }, ws) {
  if (!case_path) throw new Error('case_path 必填');
  const cd = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  const cmd = (command && command.trim()) || 'mfixsolver';
  const runId = crypto.randomBytes(4).toString('hex');
  const isWin = IS_WIN;
  let shell, shellArgs;
  if (isWin) {
    if (SETTINGS.mfixBash) shellArgs = ['/c', `call "${SETTINGS.mfixBash}" && cd /d "${cd}" && ${cmd}`];
    else                   shellArgs = ['/c', `cd /d "${cd}" && ${cmd}`];
    shell = 'cmd.exe';
  } else {
    const sourceLine = SETTINGS.mfixBash ? `source "${SETTINGS.mfixBash}"` : `true`;
    shell = 'bash'; shellArgs = ['-c', `cd "${cd}" && (${sourceLine}); ${cmd}`];
  }
  const proc = spawn(shell, shellArgs, { cwd: cd });
  const run = { runId, proc, casePath: cd, command: cmd, log: [], started: Date.now(), ended: 0, exitCode: null, subs: new Set(), kind: 'mfix' };
  SOLVER_RUNS.set(runId, run);
  const onData = d => {
    const s = d.toString();
    s.split(/\r?\n/).forEach(l => { if (l) { run.log.push(l); if (run.log.length > 4000) run.log.splice(0, run.log.length - 4000); } });
    for (const sub of run.subs) if (sub.readyState === 1) sub.send(JSON.stringify({ type: 'solver_log', runId, lines: s.split(/\r?\n/).filter(Boolean) }));
  };
  proc.stdout.on('data', onData); proc.stderr.on('data', onData);
  proc.on('close', code => { run.ended = Date.now(); run.exitCode = code;
    for (const sub of run.subs) if (sub.readyState === 1) sub.send(JSON.stringify({ type: 'solver_done', runId, exitCode: code })); });
  proc.on('error', err => { run.ended = Date.now(); run.exitCode = -1; run.log.push('[启动失败] ' + err.message); });
  if (ws) run.subs.add(ws);
  return `[已启动 MFIX 求解器]\n  runId: ${runId}\n  case:  ${cd}\n  cmd:   ${cmd}\n请在"求解器监测"面板订阅 runId=${runId}，或调用 mfix_solver_status(${runId})。`;
}
function mfixSolverStatus(runId) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  const lines = run.log; const tail = lines.slice(-40);
  // MFIX 时间步格式: "Time= 1.234E-02" or "T= ..." 或 "Time, dt:"
  let lastTime = '';
  for (let i = lines.length - 1; i >= 0; i--) {
    const m = lines[i].match(/(?:Time|T|TIME)\s*[=:]\s*([\d.eE+\-]+)/);
    if (m) { lastTime = m[1]; break; }
  }
  // MFIX 残差: "Residual:" 或包含 "P_g" / "U_g" / norm
  const resLines = lines.filter(l => /(Residual|Norm|P_g\s|U_g\s|V_g\s|W_g\s|EP_g\s)/.test(l)).slice(-20);
  const status = run.ended ? `已结束(exit=${run.exitCode})` : '运行中';
  const dur = ((run.ended || Date.now()) - run.started) / 1000;
  return [
    `runId: ${runId}    状态: ${status}    用时: ${dur.toFixed(1)}s    [MFIX]`,
    `case:  ${run.casePath}`,
    `cmd:   ${run.command}`,
    `当前 Time: ${lastTime || '(未识别)'}`,
    `\n--- 最近残差/norm (20 行) ---`,
    ...resLines,
    `\n--- 日志 tail (40 行) ---`,
    ...tail
  ].join('\n');
}
function mfixSolverStop(runId) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  if (run.ended) return '[已结束]';
  try { run.proc.kill('SIGTERM'); } catch {}
  setTimeout(() => { try { run.proc.kill('SIGKILL'); } catch {} }, 3000);
  return `[已发送终止信号 runId=${runId}]`;
}

// ====================== LBM-Beta 实现 ======================
function lbmRootDir() {
  const r = SETTINGS.lbmTutorialRoot && String(SETTINGS.lbmTutorialRoot).trim();
  if (!r) throw new Error('未设置 LBM 算例根目录。请在右侧 "LBM (Beta)" 面板填写，或 POST /api/lbm/config {tutorialRoot}');
  return r;
}
async function lbmFindTutorial(query, topK = 12) {
  const root = lbmRootDir();
  try { if (!(await fs.stat(root)).isDirectory()) throw 0; } catch { throw new Error(`目录不存在：${root}`); }
  const q = String(query || '').toLowerCase();
  const hits = []; // {p, score}
  const CASE_FILE = /^(README(\.md|\.txt)?|input\.|params\.|main\.(py|cpp|c|cu|f90)|.*\.(py|cpp|cu|f90|ini|json|yaml|yml|toml))$/i;
  async function walk(dir, depth = 0) {
    if (depth > 6) return;
    let ents; try { ents = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    let isCase = false;
    for (const e of ents) if (!e.isDirectory() && CASE_FILE.test(e.name)) { isCase = true; break; }
    if (isCase) {
      const rel = path.relative(root, dir);
      // 算分：路径含 query / 算法名加权
      const bn = path.basename(dir).toLowerCase();
      const fullRel = rel.toLowerCase();
      let score = 0;
      if (q && fullRel.includes(q)) score += 10;
      if (q && bn.includes(q)) score += 5;
      // 读 README/前 2 个源文件首 4KB 做内容打分（仅当 q 非空）
      if (q) {
        const probes = ents.filter(e => !e.isDirectory() && /^(README|main\.|input\.|params\.)/i.test(e.name)).slice(0, 3);
        for (const e of probes) {
          try {
            const txt = (await fs.readFile(path.join(dir, e.name), 'utf8')).slice(0, 4096).toLowerCase();
            if (txt.includes(q)) { score += 3; break; }
          } catch {}
        }
      }
      if (q === '' || score > 0) hits.push({ p: rel || path.basename(dir), score });
    }
    for (const e of ents) if (e.isDirectory() && !/^(\.|build|__pycache__|node_modules)/.test(e.name)) await walk(path.join(dir, e.name), depth + 1);
  }
  await walk(root);
  hits.sort((a, b) => b.score - a.score);
  const top = hits.slice(0, topK);
  if (!top.length) return `[lbm_find_tutorial] "${query}" → 0 条候选。请换关键词或检查 ${root}。`;
  return `[lbm_find_tutorial] "${query}" → ${top.length} 条候选（按相关度）：\n` +
    top.map((h, i) => `  ${i + 1}) ${h.p}`).join('\n');
}
async function lbmCloneTutorial(tutorialPath, dest) {
  if (!tutorialPath) throw new Error('tutorial_path 必填');
  if (!dest) throw new Error('dest 必填');
  const root = lbmRootDir();
  const src = path.isAbsolute(tutorialPath) ? tutorialPath : path.join(root, tutorialPath);
  try { if (!(await fs.stat(src)).isDirectory()) throw 0; } catch { throw new Error(`源目录不存在：${src}`); }
  const target = path.isAbsolute(dest) ? dest : path.resolve(WORKSPACE, dest);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.cp(src, target, { recursive: true, force: false, errorOnExist: false });
  return `已复制 LBM 算例：\n  源：${src}\n  目标：${path.relative(WORKSPACE, target)}\n建议下一步：lbm_inspect_case("${path.relative(WORKSPACE, target)}")`;
}
async function lbmInspectCase(casePath, algorithmHint = '') {
  if (!casePath) throw new Error('case_path 必填');
  const cd = path.isAbsolute(casePath) ? casePath : path.resolve(WORKSPACE, casePath);
  try { if (!(await fs.stat(cd)).isDirectory()) throw 0; } catch { throw new Error(`目录不存在：${cd}`); }
  const out = [`[lbm_inspect_case] ${cd}`];
  if (algorithmHint) out.push(`用户提示算法：${algorithmHint}`);
  // 收集文件清单（递归，前 300）
  const allFiles = [];
  async function walk(dir, rel = '') {
    if (allFiles.length > 300) return;
    let es; try { es = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of es) {
      if (allFiles.length > 300) return;
      if (/^(\.|build|__pycache__|node_modules)/.test(e.name)) continue;
      const sub = path.join(dir, e.name); const rsub = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) await walk(sub, rsub); else allFiles.push(rsub);
    }
  }
  await walk(cd);
  // 算法骨架识别：读所有源文件首 16KB
  const SCAN_EXT = /\.(py|cpp|c|cu|cuh|h|hpp|f90|jl|m)$/i;
  const sources = allFiles.filter(f => SCAN_EXT.test(f)).slice(0, 12);
  const detected = new Set();
  const fnHits = { equilibrium: [], collision: [], streaming: [], propagate: [] };
  for (const f of sources) {
    try {
      const txt = (await fs.readFile(path.join(cd, f), 'utf8')).slice(0, 16384);
      const lower = txt.toLowerCase();
      // 格子模型
      for (const lm of ['d2q9','d3q7','d3q15','d3q19','d3q27']) if (lower.includes(lm)) detected.add(lm.toUpperCase());
      // 碰撞算子
      for (const co of [['bgk','BGK'],['mrt','MRT'],['trt','TRT'],['cumulant','Cumulant'],['regularized','Regularized'],['srt','SRT'],['kbc','KBC']])
        if (new RegExp('\\b' + co[0] + '\\b').test(lower)) detected.add(co[1]);
      // 多相
      if (/shan.?chen|free.?energy|color.?gradient|interface.?tracking/.test(lower)) detected.add('多相LBM');
      // 三大核心函数定位
      for (const k of Object.keys(fnHits)) {
        const re = new RegExp('(def|void|inline|static|template[^\\n]*?>\\s*\\w+|subroutine|function)\\s+\\w*' + k + '\\w*', 'gi');
        let m; while ((m = re.exec(txt)) && fnHits[k].length < 3) fnHits[k].push(`${f}: ${m[0].slice(0,80)}`);
      }
    } catch {}
  }
  out.push('--- 算法骨架识别 ---');
  out.push('  检测到: ' + (detected.size ? [...detected].join(', ') : '(未识别 — 用户提示可补充)'));
  for (const k of Object.keys(fnHits)) if (fnHits[k].length) out.push(`  ${k}(): \n` + fnHits[k].map(s => '    - ' + s).join('\n'));
  // README / params
  const readmes = allFiles.filter(f => /^(README|params|input)/i.test(path.basename(f))).slice(0, 3);
  for (const r of readmes) {
    try {
      const txt = await fs.readFile(path.join(cd, r), 'utf8');
      out.push(`\n--- ${r} (前 60 行) ---`);
      out.push(...txt.split(/\r?\n/).slice(0, 60));
    } catch {}
  }
  out.push('\n--- 文件清单 (递归, 前 300) ---');
  out.push(...allFiles.map(f => '  ' + f));
  return out.join('\n');
}
async function lbmRunAsync({ case_path, command }, ws) {
  if (!case_path) throw new Error('case_path 必填');
  const cd = path.isAbsolute(case_path) ? case_path : path.resolve(WORKSPACE, case_path);
  const cmd = (command && command.trim()) || (SETTINGS.lbmRunCmd && SETTINGS.lbmRunCmd.trim());
  if (!cmd) throw new Error('未提供 command 且 SETTINGS.lbmRunCmd 为空。请提供运行命令或在面板填默认模板。');
  const runId = crypto.randomBytes(4).toString('hex');
  const shell = IS_WIN ? 'cmd.exe' : 'bash';
  const shellArgs = IS_WIN ? ['/c', `cd /d "${cd}" && ${cmd}`] : ['-c', `cd "${cd}" && ${cmd}`];
  const proc = spawn(shell, shellArgs, { cwd: cd });
  const run = { runId, proc, casePath: cd, command: cmd, log: [], started: Date.now(), ended: 0, exitCode: null, subs: new Set(), kind: 'lbm' };
  SOLVER_RUNS.set(runId, run);
  const onData = d => {
    const s = d.toString();
    s.split(/\r?\n/).forEach(l => { if (l) { run.log.push(l); if (run.log.length > 4000) run.log.splice(0, run.log.length - 4000); } });
    for (const sub of run.subs) if (sub.readyState === 1) sub.send(JSON.stringify({ type: 'solver_log', runId, lines: s.split(/\r?\n/).filter(Boolean) }));
  };
  proc.stdout.on('data', onData); proc.stderr.on('data', onData);
  proc.on('close', code => { run.ended = Date.now(); run.exitCode = code;
    for (const sub of run.subs) if (sub.readyState === 1) sub.send(JSON.stringify({ type: 'solver_done', runId, exitCode: code })); });
  proc.on('error', err => { run.ended = Date.now(); run.exitCode = -1; run.log.push('[启动失败] ' + err.message); });
  if (ws) run.subs.add(ws);
  return `[已启动 LBM 作业]\n  runId: ${runId}\n  case:  ${cd}\n  cmd:   ${cmd}\n请在"求解器监测"面板订阅 runId=${runId}，或调用 lbm_solver_status(${runId})。`;
}
function lbmSolverStatus(runId) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  const lines = run.log; const tail = lines.slice(-40);
  // LBM 通用 print 风格: "step 1000" / "iter=1000" / "t=0.05" / "||u^{n+1}-u^n||=1e-6"
  let lastStep = '';
  for (let i = lines.length - 1; i >= 0; i--) {
    const m = lines[i].match(/(?:step|iter|iteration|t)\s*[=:]?\s*([\d.eE+\-]+)/i);
    if (m) { lastStep = m[1]; break; }
  }
  const metricLines = lines.filter(l => /(\|\|.*\|\||residual|error|err|rmse|conv|mach|cfl|u_max)\s*[=:]/i.test(l)).slice(-20);
  const status = run.ended ? `已结束(exit=${run.exitCode})` : '运行中';
  const dur = ((run.ended || Date.now()) - run.started) / 1000;
  return [
    `runId: ${runId}    状态: ${status}    用时: ${dur.toFixed(1)}s    [LBM]`,
    `case:  ${run.casePath}`,
    `cmd:   ${run.command}`,
    `当前 step/iter/t: ${lastStep || '(未识别)'}`,
    `\n--- 关键 metric (20 行) ---`,
    ...metricLines,
    `\n--- 日志 tail (40 行) ---`,
    ...tail
  ].join('\n');
}
function lbmSolverStop(runId) {
  const run = SOLVER_RUNS.get(runId);
  if (!run) return '[未知 runId]';
  if (run.ended) return '[已结束]';
  try { run.proc.kill('SIGTERM'); } catch {}
  setTimeout(() => { try { run.proc.kill('SIGKILL'); } catch {} }, 3000);
  return `[已发送终止信号 runId=${runId}]`;
}

function buildSystemPrompt(s) {
  let p = SYSTEM_PROMPT_BASE(WORKSPACE);
  if (s.foamMode) p += FOAM_PROMPT;
  if (s.mfixMode) p += MFIX_PROMPT;
  if (s.lbmMode)  p += LBM_PROMPT;
  if (s.customMode && SETTINGS.customPrompt && SETTINGS.customPrompt.trim()) {
    const name = SETTINGS.customName || '自定义工作流';
    const root = SETTINGS.customRoot ? `根目录：${SETTINGS.customRoot}\n` : '';
    p += `\n\n========== 已启用《${name}》工作流（用户自定义 Beta）==========\n${root}${SETTINGS.customPrompt.trim()}\n========== 工作流定义结束 ==========\n`;
  }
  return p;
}

async function runAgent(ws, userText, attachments) {
  const session = sessions.get(ws);
  newCheckpoint(session, userText.slice(0, 40) || '新任务');
  broadcastCheckpoints(ws);
  const userContent = await buildUserContent(userText, attachments);
  session.messages.push({ role: 'user', content: userContent });
  session.aborter = new AbortController();
  session.aborted = false; session.taskComplete = false;
  ws.send(JSON.stringify({ type: 'agent_start' }));

  try {
    let nudgeCount = 0;
    // 循环安全卫士：最近 N 个工具调用指纹 (name + args hash)。连续同指纹 >= 5 调则硬断，>=3 插入纠正提示。
    const recentFP = [];        // 循环调用指纹序列
    let warnedDup = false;       // 重复提醒只插一次
    function fp(name, args) {
      try { return name + ':' + JSON.stringify(args).slice(0, 240); } catch { return name + ':?'; }
    }
    function consecutiveDupes() {
      if (recentFP.length < 2) return 0;
      const last = recentFP[recentFP.length - 1];
      let n = 1;
      for (let i = recentFP.length - 2; i >= 0 && recentFP[i] === last; i--) n++;
      return n;
    }
    for (let step = 0; step < MAX_AUTO_STEPS; step++) {
      if (session.aborted) { ws.send(JSON.stringify({ type: 'term', line: '[已停止]' })); break; }
      autoCompactIfNeeded(session, ws);
      ws.send(JSON.stringify({ type: 'assistant_start' }));
      ws.send(JSON.stringify({ type: 'agent_phase', phase: 'llm_thinking', detail: `调用 LLM (第 ${step+1} 步)` }));
      let msg;
      try { msg = await callLLM(session.messages, ws, session.aborter.signal, filterTools(session.enabledTools || DEFAULT_ENABLED)); }
      catch (e) { if (session.aborted) { ws.send(JSON.stringify({ type: 'term', line: '[已停止]' })); break; }
        ws.send(JSON.stringify({ type: 'error', message: String(e.message || e) })); break; }
      session.messages.push(msg);
      ws.send(JSON.stringify({ type: 'assistant_end' }));
      const hasTools = Array.isArray(msg.tool_calls) && msg.tool_calls.length > 0;
        // V4 人在回路：assistant 文本里抛出编号选项且无 tool_call → 强制停下等用户回复
        try {
          if (!hasTools && typeof msg.content === 'string' && msg.content.trim()) {
            const c = msg.content;
            const numbered = (c.match(/(^|\n)\s*[1-9][\)、.．]/g) || []).length;
            const hasOptionWord = /(请选择|请回复|请回|请选|哪个|选哪|你想|你要|确认一下|要不要|是否|回[\s]?[1-9]\s*[\/、]\s*[1-9])/.test(c);
            const endsWithQ = /[?？]\s*$/.test(c.trim());
            if (numbered >= 2 || (hasOptionWord && (endsWithQ || numbered >= 1))) {
              session.awaitingUserChoice = true;
              ws.send(JSON.stringify({ type: 'agent_phase', phase: 'awaiting_user', detail: '等待用户回复选项 / 确认' }));
              ws.send(JSON.stringify({ type: 'term', line: '[人在回路] Agent 抛出选项 → 已暂停等待你的回复（V4）' }));
              break;
            }
          }
        } catch {}
      if (hasTools) {
        let stop = false;
        // 已完成响应的 tool_call_id 集合；若 abort 中断，把剩余未响应的 tool_calls 用占位补齐，
        // 否则下一轮发给 LLM 会因「assistant.tool_calls 无配对 tool 响应」而被 OpenAI 拒收 400。
        const respondedIds = new Set();
        const allCallIds = msg.tool_calls.map(tc => tc.id);
        // 若全部为只读工具，并行执行以加速
        const READONLY = new Set(['list_dir','read_file','grep_search','glob','web_search','fetch_url']);
        const allReadonly = msg.tool_calls.length > 1 && msg.tool_calls.every(tc => READONLY.has(tc.function.name) && !NEEDS_APPROVAL.has(tc.function.name));
        if (allReadonly) {
          ws.send(JSON.stringify({ type: 'term', line: `[Parallel] 并行执行 ${msg.tool_calls.length} 个只读工具` }));
          const tasks = msg.tool_calls.map(tc => {
            const name = tc.function.name;
            let args = {}; try { args = JSON.parse(tc.function.arguments || '{}'); } catch {}
            ws.send(JSON.stringify({ type: 'tool_call', id: tc.id, name, args }));
            return execToolWithProgress(name, args, session, ws).then(r => ({ tc, name, result: r })).catch(e => ({ tc, name, result: `执行失败：${e.message || e}` }));
          });
          let results = [];
          try { results = await Promise.all(tasks); } catch (e) {
            ws.send(JSON.stringify({ type: 'error', message: `并行工具异常：${e.message || e}` }));
          }
          for (const { tc, name, result } of results) {
            ws.send(JSON.stringify({ type: 'tool_result', id: tc.id, name, result }));
            session.messages.push({ role: 'tool', tool_call_id: tc.id, content: clipForHistory(result) });
            respondedIds.add(tc.id);
          }
          // 补齐未响应的（理论上 Promise.all 已等齐，此处兜底）
          for (const id of allCallIds) if (!respondedIds.has(id)) {
            session.messages.push({ role: 'tool', tool_call_id: id, content: '[未执行：流程中断]' });
          }
          if (session.aborted) break;
          continue;
        }
        for (const tc of msg.tool_calls) {
          if (session.aborted) { stop = true; break; }
          const name = tc.function.name;
          let args = {}; try { args = JSON.parse(tc.function.arguments || '{}'); } catch {}
          ws.send(JSON.stringify({ type: 'tool_call', id: tc.id, name, args }));
          if (NEEDS_APPROVAL.has(name)) {
            // Auto 模式下自动放行（用户可随时点 ⏹ 停止）
            if (session.autoMode) {
              ws.send(JSON.stringify({ type: 'term', line: `[Auto 批准] ${name}: ${args.command || args.case_path || ''}` }));
            } else {
              const ok = await new Promise((res) => { session.pendingApproval = res; ws.send(JSON.stringify({ type: 'approval_request', id: tc.id, name, args })); });
              if (session.aborted) { stop = true; break; }
              if (!ok) { const r = '用户拒绝执行。';
                ws.send(JSON.stringify({ type: 'tool_result', id: tc.id, name, result: r }));
                session.messages.push({ role: 'tool', tool_call_id: tc.id, content: r });
                respondedIds.add(tc.id);
                continue; }
            }
          }
          let result; try { ws.send(JSON.stringify({ type: 'agent_phase', phase: 'tool_exec', detail: `执行 ${name}`, tool: name })); result = await execToolWithProgress(name, args, session, ws); } catch (e) { result = `执行失败：${e.message || e}`; }
          ws.send(JSON.stringify({ type: 'tool_result', id: tc.id, name, result }));
          ws.send(JSON.stringify({ type: 'agent_phase', phase: 'tool_done', detail: `${name} 返回`, tool: name }));
          session.messages.push({ role: 'tool', tool_call_id: tc.id, content: clipForHistory(result) });
          respondedIds.add(tc.id);
          if (MODIFYING.has(name)) broadcastCheckpoints(ws);
          // 重复检测：同一工具+同一参数 连续调用
          recentFP.push(fp(name, args)); if (recentFP.length > 12) recentFP.shift();
          const dup = consecutiveDupes();
          if (dup >= 5) {
            ws.send(JSON.stringify({ type: 'term', line: `[循环保护] 检测到 ${name} 连续 ${dup} 次同参调用，已强制中断。` }));
            session.messages.push({ role: 'user', content: `[系统] 你连续${dup}次以完全相同的参数调用 ${name}，这是循环。请立即停下来，总结已得到的结果，如需继续请换一种思路或调用 task_complete。` });
            stop = true; break;
          } else if (dup === 3 && !warnedDup) {
            warnedDup = true;
            session.messages.push({ role: 'user', content: `[提示] 检测到 ${name} 以相同参数被调用 ${dup} 次。如果结果一样，换个思路或使用不同的参数/工具，不要被动刷同样的试探。` });
          }
          if (session.taskComplete) { stop = true; break; }
        }
        // 关键：中断/终止前补齐剩余未响应的 tool_call，避免下一轮 400
        for (const id of allCallIds) if (!respondedIds.has(id)) {
          session.messages.push({ role: 'tool', tool_call_id: id, content: '[未执行：流程中断]' });
        }
        if (stop) break;
        continue;
      }
      if (session.taskComplete) break;
      const undone = (session.todos || []).filter(t => !t.done);
      if (session.autoMode && undone.length > 0 && nudgeCount < 5 && !session.awaitingUserChoice) {
        nudgeCount++;
        session.messages.push({ role: 'user', content: `你尚未调用 task_complete，仍有 ${undone.length} 项未完成：\n` + undone.map((t,i) => `${i+1}. ${t.text}`).join('\n') + `\n请继续推进；如确实已完成全部，调用 task_complete。` });
        ws.send(JSON.stringify({ type: 'term', line: `[Auto 续跑（${nudgeCount}/5）]` }));
        continue;
      }
      break;
    }
  } finally {
    session.currentCheckpoint = null; session.aborter = null;
    ws.send(JSON.stringify({ type: 'agent_end' }));
    broadcastCheckpoints(ws);
  }
}

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/config', (req, res) => res.json({ workspace: WORKSPACE, model: SETTINGS.model, name: 'NullFlux', author: 'LZF', platform: process.platform, hasApiKey: !!SETTINGS.apiKey, hasParaviewExe: !!SETTINGS.paraviewExe, pythonPath: SETTINGS.pythonPath || '', provider: SETTINGS.provider || 'sf', copilotModel: SETTINGS.copilotModel || 'gpt-4.1', copilotLoggedIn: !!COPILOT.ghToken }));
app.get('/api/settings', (req, res) => res.json({ ...SETTINGS, apiKey: SETTINGS.apiKey ? '***' + SETTINGS.apiKey.slice(-4) : '', visionApiKey: SETTINGS.visionApiKey ? '***' + SETTINGS.visionApiKey.slice(-4) : '' }));
app.post('/api/settings', async (req, res) => {
  const u = req.body || {};
  if (u.apiKey !== undefined && !u.apiKey.startsWith('***')) SETTINGS.apiKey = u.apiKey;
  if (u.baseUrl !== undefined) SETTINGS.baseUrl = u.baseUrl;
  if (u.model !== undefined) SETTINGS.model = u.model;
  if (u.provider !== undefined) SETTINGS.provider = u.provider;
  if (u.copilotModel !== undefined) SETTINGS.copilotModel = u.copilotModel;
  if (u.paraviewExe !== undefined) SETTINGS.paraviewExe = u.paraviewExe;
  if (u.paraviewPython !== undefined) SETTINGS.paraviewPython = u.paraviewPython;
  if (u.openfoamBash !== undefined) SETTINGS.openfoamBash = u.openfoamBash;
  if (u.pythonPath !== undefined) SETTINGS.pythonPath = u.pythonPath;
  // V4.1 专用视觉路由
  if (u.visionProvider !== undefined) SETTINGS.visionProvider = u.visionProvider;
  if (u.visionBaseUrl !== undefined) SETTINGS.visionBaseUrl = u.visionBaseUrl;
  if (u.visionModel !== undefined) SETTINGS.visionModel = u.visionModel;
  if (u.visionApiKey !== undefined && !u.visionApiKey.startsWith('***')) SETTINGS.visionApiKey = u.visionApiKey;
  await saveSettings(); res.json({ ok: true });
});

// ============ GitHub Copilot 端点 ============
app.get('/api/copilot/status', (req, res) => res.json({ loggedIn: !!COPILOT.ghToken, provider: SETTINGS.provider, model: SETTINGS.copilotModel }));
app.post('/api/copilot/auth/start', async (req, res) => {
  try { res.json(await copilotDeviceStart()); } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});
app.post('/api/copilot/auth/poll', async (req, res) => {
  try {
    const j = await copilotDevicePoll(req.body?.device_code);
    if (j.access_token) { COPILOT.ghToken = j.access_token; await saveCopilotState(); COPILOT.apiToken = ''; return res.json({ ok: true }); }
    res.json({ pending: true, ...j });
  } catch (e) {
    // 网络抖动（fetch failed / ECONNRESET / ETIMEDOUT）当作 pending 继续轮询，避免误判终止
    const msg = String(e.message || e);
    if (/fetch failed|ECONN|ETIMEDOUT|ENOTFOUND|EAI_AGAIN|socket hang up/i.test(msg)) {
      return res.json({ pending: true, error: 'authorization_pending', error_description: '网络抖动：' + msg });
    }
    res.status(500).json({ error: msg });
  }
});
app.post('/api/copilot/logout', async (req, res) => { COPILOT.ghToken = ''; COPILOT.apiToken = ''; COPILOT.modelsCache = null; await saveCopilotState(); res.json({ ok: true }); });
app.get('/api/copilot/models', async (req, res) => {
  try { res.json({ models: await copilotListModels() }); } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});
app.post('/api/copilot/select', async (req, res) => {
  const { provider, model } = req.body || {};
  if (provider) SETTINGS.provider = provider;
  if (model) SETTINGS.copilotModel = model;
  await saveSettings(); res.json({ ok: true });
});
app.post('/api/workspace', async (req, res) => {
  const { dir } = req.body; if (!dir) return res.status(400).json({ error: '缺少 dir' });
  WORKSPACE = path.resolve(dir); SETTINGS.workspace = WORKSPACE; await saveSettings();
  res.json({ workspace: WORKSPACE }); broadcastTree();
});
app.get('/api/tree', async (req, res) => { try { res.json(await buildTree()); } catch (e) { res.status(500).json({ error: String(e) }); } });
app.get('/api/flat', async (req, res) => { try { res.json({ files: await flatList() }); } catch (e) { res.status(500).json({ error: String(e) }); } });
app.get('/api/file', async (req, res) => {
  try {
    const f = safePath(req.query.path);
    const stat = await fs.stat(f);
    if (stat.isDirectory()) return res.json({ error: '路径是目录，不能作为文件打开' });
    // raw=1：二进制原文返回（供图片等预览）
    if (req.query.raw === '1' || req.query.raw === 'true') {
      const ext = path.extname(f).toLowerCase();
      const MIME = {
        '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.gif':'image/gif',
        '.webp':'image/webp', '.bmp':'image/bmp', '.svg':'image/svg+xml', '.ico':'image/x-icon',
        '.stl':'model/stl', '.obj':'text/plain',
        '.pdf':'application/pdf'
      };
      res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
      // PDF 必须 inline，否则浏览器走下载分支，iframe 渲染不出来
      if (ext === '.pdf') res.setHeader('Content-Disposition', 'inline; filename="' + encodeURIComponent(path.basename(f)) + '"');
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(f);
      return;
    }
    // 预览上限：超过 20MB 累拒；席位上限 2MB，超过则只返前 2MB + 提示。
    const HARD_MAX = 20 * 1024 * 1024, SOFT_MAX = 2 * 1024 * 1024;
    if (stat.size > HARD_MAX) return res.json({ content: `[文件过大 ${(stat.size/1024/1024).toFixed(1)} MB，超过 ${HARD_MAX/1024/1024} MB 硬上限，未加载。请用 read_document 或外部工具查看。]`, truncated: true, size: stat.size });
    // 二进制检测：读前 8KB 看有无 NUL 字节
    const fh = await fs.open(f, 'r');
    try {
      const sniffLen = Math.min(8192, stat.size);
      const buf = Buffer.alloc(sniffLen);
      await fh.read(buf, 0, sniffLen, 0);
      let nullCount = 0;
      for (let i = 0; i < sniffLen; i++) if (buf[i] === 0) { nullCount++; if (nullCount > 2) break; }
      if (nullCount > 2) return res.json({ binary: true, size: stat.size, error: null });
      // 超过席位上限：只读前 2MB + banner
      if (stat.size > SOFT_MAX) {
        const head = Buffer.alloc(SOFT_MAX);
        await fh.read(head, 0, SOFT_MAX, 0);
        const banner = `\n\n... [文件共 ${(stat.size/1024/1024).toFixed(2)} MB，仅预览前 2 MB；可用 read_document 或 grep_search 处理全部内容] ...\n`;
        return res.json({ content: head.toString('utf8') + banner, truncated: true, size: stat.size });
      }
    } finally { await fh.close(); }
    res.json({ content: await fs.readFile(f, 'utf8'), size: stat.size });
  } catch (e) { res.status(500).json({ error: String(e.message) }); }
});
app.post('/api/file', async (req, res) => {
  try { const { path: p, content } = req.body;
    if (typeof p !== 'string' || typeof content !== 'string') return res.status(400).json({ error: '参数错误' });
    const f = safePath(p); await fs.mkdir(path.dirname(f), { recursive: true });
    await fs.writeFile(f, content, 'utf8'); broadcastTree();
    res.json({ ok: true, bytes: Buffer.byteLength(content, 'utf8') });
  } catch (e) { res.status(500).json({ error: String(e.message) }); }
});
// 二进制附件上传（PDF/DOCX/PPTX/XLSX/图片等）：保存到 .cache/uploads/<safe>/ 下，返回相对路径
app.post('/api/upload', async (req, res) => {
  try {
    const { name, base64 } = req.body || {};
    if (typeof name !== 'string' || typeof base64 !== 'string') return res.status(400).json({ error: '参数错误' });
    const safeName = name.replace(/[^\w.\-\u4e00-\u9fa5]+/g, '_').slice(-200) || ('file_' + Date.now());
    const subdir = path.join('.cache', 'uploads', Date.now().toString(36));
    const rel = path.join(subdir, safeName).replace(/\\/g, '/');
    const abs = safePath(rel);
    await fs.mkdir(path.dirname(abs), { recursive: true });
    const buf = Buffer.from(base64, 'base64');
    await fs.writeFile(abs, buf);
    broadcastTree();
    res.json({ ok: true, path: rel, size: buf.length });
  } catch (e) { res.status(500).json({ error: String(e.message) }); }
});
app.post('/api/fs', async (req, res) => {
  try { const { op, path: p, isDir } = req.body; const f = safePath(p);
    if (op === 'create') {
      if (isDir) await fs.mkdir(f, { recursive: true });
      else { await fs.mkdir(path.dirname(f), { recursive: true }); await fs.writeFile(f, '', { flag: 'wx' }); }
    } else if (op === 'delete') await fs.rm(f, { recursive: true, force: true });
    else return res.status(400).json({ error: '未知操作' });
    broadcastTree(); res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e.message) }); }
});
app.get('/api/list-abs', async (req, res) => {
  try { const dir = req.query.path ? path.resolve(req.query.path) : os.homedir();
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const items = [];
    for (const e of entries) { if (e.name.startsWith('.')) continue;
      items.push({ name: e.name, path: path.join(dir, e.name), isDir: e.isDirectory() }); }
    items.sort((a,b) => (b.isDir?1:0) - (a.isDir?1:0) || a.name.localeCompare(b.name));
    res.json({ cwd: dir, parent: path.dirname(dir) === dir ? null : path.dirname(dir), items });
  } catch (e) { res.status(500).json({ error: String(e.message) }); }
});
app.post('/api/sim/launch', async (req, res) => {
  try { const r = await launchParaView(req.body?.casePath); res.json({ ok: true, ...r }); }
  catch (e) { res.status(500).json({ error: String(e.message) }); }
});
app.post('/api/sim/close', (req, res) => { killParaView(); res.json({ ok: true }); });

// ====================== Notebook Kernel 管理（逐 cell 执行） ======================
const NB_KERNELS = new Map(); // path -> { proc, subscribers:Set<ws>, ready, buffer }
function nbKernelStart(nbPath) {
  if (NB_KERNELS.has(nbPath)) return NB_KERNELS.get(nbPath);
  const py = SETTINGS.pythonPath || (IS_WIN ? 'python' : 'python3');
  const host = path.join(__dirname, 'nb_kernel_host.py');
  const proc = spawn(py, ['-u', host], { cwd: WORKSPACE, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
  const k = { proc, subscribers: new Set(), ready: false, buffer: '' };
  NB_KERNELS.set(nbPath, k);
  proc.stdout.setEncoding('utf8');
  proc.stdout.on('data', (d) => {
    k.buffer += d;
    let idx; while ((idx = k.buffer.indexOf('\n')) >= 0) {
      const line = k.buffer.slice(0, idx); k.buffer = k.buffer.slice(idx + 1);
      if (!line.trim()) continue;
      try {
        const msg = JSON.parse(line);
        if (msg.type === 'ready') k.ready = true;
        if (msg.type === 'fatal') k.fatal = msg.message;
        for (const ws of k.subscribers) if (ws.readyState === 1)
          ws.send(JSON.stringify({ type: 'nb_msg', path: nbPath, msg }));
      } catch {}
    }
  });
  proc.stderr.on('data', (d) => {
    const text = d.toString();
    for (const ws of k.subscribers) if (ws.readyState === 1)
      ws.send(JSON.stringify({ type: 'nb_msg', path: nbPath, msg: { type: 'stream', name: 'stderr', text, cell_id: '' } }));
  });
  proc.on('exit', (code) => {
    for (const ws of k.subscribers) if (ws.readyState === 1)
      ws.send(JSON.stringify({ type: 'nb_msg', path: nbPath, msg: { type: 'fatal', message: `kernel 退出 (code=${code})` } }));
    NB_KERNELS.delete(nbPath);
  });
  proc.on('error', (e) => {
    for (const ws of k.subscribers) if (ws.readyState === 1)
      ws.send(JSON.stringify({ type: 'nb_msg', path: nbPath, msg: { type: 'fatal', message: '启动失败：' + e.message } }));
    NB_KERNELS.delete(nbPath);
  });
  return k;
}
function nbKernelSend(nbPath, obj) {
  const k = NB_KERNELS.get(nbPath); if (!k) return false;
  try { k.proc.stdin.write(JSON.stringify(obj) + '\n'); return true; } catch { return false; }
}
function nbKernelStop(nbPath) {
  const k = NB_KERNELS.get(nbPath); if (!k) return;
  try { k.proc.stdin.write(JSON.stringify({ action: 'shutdown' }) + '\n'); } catch {}
  setTimeout(() => { try { if (!k.proc.killed) k.proc.kill(); } catch {} }, 800);
}

// 保存 notebook（全量覆写）
app.post('/api/notebook/save', async (req, res) => {
  try { const { path: rel, json: nb } = req.body || {};
    const f = safePath(rel);
    await fs.writeFile(f, JSON.stringify(nb, null, 1), 'utf8');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ====================== Notebook 一键走全本 ======================
app.post('/api/notebook/execute', async (req, res) => {
  const { path: rel } = req.body || {};
  if (!rel) return res.status(400).json({ error: '缺少 path' });
  let abs; try { abs = safePath(rel); } catch (e) { return res.status(400).json({ error: e.message }); }
  const py = SETTINGS.pythonPath || (IS_WIN ? 'python' : 'python3');
  const cmd = `"${py}" -m jupyter nbconvert --to notebook --execute --inplace "${abs}" --ExecutePreprocessor.timeout=600`;
  res.json({ started: true });
  // 后端广播到所有 ws
  for (const ws of allClients) ws.send(JSON.stringify({ type: 'term', line: `[Notebook] 执行中：${rel}` }));
  const child = spawn(IS_WIN ? (process.env.COMSPEC || 'cmd.exe') : 'bash', IS_WIN ? ['/c', cmd] : ['-c', cmd], { cwd: WORKSPACE });
  const broadcast = (line) => { for (const ws of allClients) ws.send(JSON.stringify({ type: 'term', line })); };
  broadcast(`$ ${cmd}`);
  const onData = d => d.toString().split(/\r?\n/).forEach(l => l && broadcast(l));
  child.stdout.on('data', onData); child.stderr.on('data', onData);
  child.on('close', (code) => { broadcast(`[Notebook 退出码 ${code}]`); for (const ws of allClients) ws.send(JSON.stringify({ type: 'notebook_done', path: rel, code })); });
});

// ====================== 联网工具 ======================
function stripHtml(s) {
  return s.replace(/<script[\s\S]*?<\/script>/gi, '')
          .replace(/<style[\s\S]*?<\/style>/gi, '')
          .replace(/<[^>]+>/g, ' ')
          .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#(\d+);/g, (_,n)=>String.fromCharCode(+n))
          .replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}
const UA_DESKTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
async function searchDDG(query, topK) {
  const r = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(query), { headers: { 'User-Agent': UA_DESKTOP, 'Accept': 'text/html', 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8' } });
  if (!r.ok) throw new Error('DDG ' + r.status);
  const html = await r.text();
  const out = [];
  const re = /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]*class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>/g;
  let m; while ((m = re.exec(html)) && out.length < topK) {
    let href = m[1];
    try { const u = new URL(href, 'https://duckduckgo.com'); const real = u.searchParams.get('uddg'); if (real) href = decodeURIComponent(real); } catch {}
    out.push({ title: stripHtml(m[2]).slice(0, 160), url: href, snippet: stripHtml(m[3]).slice(0, 300) });
  }
  return out;
}
async function searchBing(query, topK) {
  const r = await fetch('https://www.bing.com/search?q=' + encodeURIComponent(query) + '&setlang=zh-CN&FORM=QBLH', { headers: { 'User-Agent': UA_DESKTOP, 'Accept': 'text/html', 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8' } });
  if (!r.ok) throw new Error('Bing ' + r.status);
  const html = await r.text();
  const out = [];
  // Bing 结果项：<li class="b_algo"><h2><a href="...">title</a></h2>...<p ...>snippet</p>
  const re = /<li class="b_algo"[^>]*>[\s\S]*?<h2><a href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/g;
  let m; while ((m = re.exec(html)) && out.length < topK) {
    out.push({ title: stripHtml(m[2]).slice(0, 160), url: m[1], snippet: stripHtml(m[3]).slice(0, 300) });
  }
  return out;
}
async function searchBaidu(query, topK) {
  const r = await fetch('https://www.baidu.com/s?wd=' + encodeURIComponent(query), { headers: { 'User-Agent': UA_DESKTOP, 'Accept': 'text/html', 'Accept-Language': 'zh-CN,zh;q=0.9' } });
  if (!r.ok) throw new Error('Baidu ' + r.status);
  const html = await r.text();
  const out = [];
  const re = /<h3[^>]*class="[^"]*c-title[^"]*"[^>]*>[\s\S]*?<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m; while ((m = re.exec(html)) && out.length < topK) {
    out.push({ title: stripHtml(m[2]).slice(0, 160), url: m[1], snippet: '' });
  }
  return out;
}
async function webSearch(query, topK, opts) {
  opts = opts || {};
  const topic = opts.topic || 'general';
  const timeRange = opts.time_range || '';
  const includeAnswer = opts.include_answer !== false;
  const log = typeof opts.progress === 'function' ? opts.progress : () => {};
  const fmtList = (name, items) => `[来源: ${name}]\n` + items.slice(0, topK).map((x, i) => `${i+1}. ${x.title}\n   ${x.url}\n   ${x.snippet || ''}`).join('\n');

  // --- 1. Tavily（最适合 LLM Agent 的 SOTA 搜索） ---
  const TAVILY = process.env.TAVILY_API_KEY;
  if (TAVILY) {
    log(`Tavily 检索 "${query}" …`);
    try {
      const body = {
        query, max_results: Math.min(20, topK), topic,
        search_depth: 'advanced', chunks_per_source: 3,
        include_answer: includeAnswer ? 'advanced' : false,
      };
      if (timeRange) body.time_range = timeRange;
      const r = await fetch('https://api.tavily.com/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + TAVILY },
        body: JSON.stringify(body),
      });
      if (r.ok) {
        const j = await r.json();
        const ans = j.answer ? `\n\n📌 摘要：${j.answer}\n` : '';
        const items = (j.results || []).map(x => ({ title: x.title, url: x.url, snippet: (x.content || '').slice(0, 400) }));
        if (items.length) { log(`Tavily 命中 ${items.length} 条`); return fmtList('Tavily', items) + ans; }
      }
      log('Tavily 无结果，回落…');
    } catch (e) { log('Tavily 异常：' + e.message); }
  }
  // --- 2. Serper (google.serper.dev) ---
  const SERPER = process.env.SERPER_API_KEY;
  if (SERPER) {
    log('Serper(Google) 检索…');
    try {
      const r = await fetch('https://google.serper.dev/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-KEY': SERPER },
        body: JSON.stringify({ q: query, num: Math.min(20, topK), gl: 'us', hl: 'en' }),
      });
      if (r.ok) {
        const j = await r.json();
        const items = (j.organic || []).map(x => ({ title: x.title, url: x.link, snippet: x.snippet }));
        if (items.length) { log(`Serper 命中 ${items.length} 条`); return fmtList('Serper(Google)', items); }
      }
    } catch (e) { log('Serper 异常：' + e.message); }
  }
  // --- 3. Brave Search API ---
  const BRAVE = process.env.BRAVE_API_KEY;
  if (BRAVE) {
    log('Brave Search 检索…');
    try {
      const r = await fetch('https://api.search.brave.com/res/v1/web/search?q=' + encodeURIComponent(query) + '&count=' + Math.min(20, topK), {
        headers: { 'Accept': 'application/json', 'X-Subscription-Token': BRAVE },
      });
      if (r.ok) {
        const j = await r.json();
        const items = ((j.web && j.web.results) || []).map(x => ({ title: x.title, url: x.url, snippet: x.description }));
        if (items.length) { log(`Brave 命中 ${items.length} 条`); return fmtList('Brave', items); }
      }
    } catch (e) { log('Brave 异常：' + e.message); }
  }
  // --- 4. SearXNG 自托管 ---
  const SEARXNG = process.env.SEARXNG_URL;
  if (SEARXNG) {
    try {
      const u = SEARXNG.replace(/\/$/, '') + '/search?format=json&q=' + encodeURIComponent(query);
      const r = await fetch(u, { headers: { 'User-Agent': UA_DESKTOP, 'Accept': 'application/json' } });
      if (r.ok) {
        const j = await r.json();
        const items = (j.results || []).map(x => ({ title: x.title, url: x.url, snippet: x.content }));
        if (items.length) return fmtList('SearXNG', items);
      }
    } catch {}
  }
  // --- 5. 兜底：HTML 爬取链 ---
  log('回落到 HTML 爬取链（DuckDuckGo→Bing→Baidu）…');
  const errs = [];
  for (const [name, fn] of [['DuckDuckGo', searchDDG], ['Bing', searchBing], ['Baidu', searchBaidu]]) {
    log(`尝试 ${name} …`);
    try {
      const out = await fn(query, topK);
      if (out.length > 0) {
        log(`${name} 命中 ${out.length} 条`);
        return `[来源: ${name}]\n` + out.map((x, i) => `${i+1}. ${x.title}\n   ${x.url}\n   ${x.snippet}`).join('\n');
      }
      errs.push(`${name}: 0 条结果`);
    } catch (e) { errs.push(`${name}: ${e.message}`); }
  }
  return `（联网搜索均失败，可能需要代理或配置 TAVILY_API_KEY / SERPER_API_KEY / BRAVE_API_KEY / SEARXNG_URL）\n` + errs.join('\n');
}

// ====================== 学术：paper_search / paper_fetch ======================
// Semantic Scholar Graph API (free, no key required) + arXiv API merge
function _normTitle(t) { return (t || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
async function _semanticScholarSearch(query, opts) {
  const fields = 'title,abstract,year,authors.name,venue,citationCount,influentialCitationCount,openAccessPdf,externalIds,tldr,publicationDate';
  const params = new URLSearchParams({ query, limit: String(Math.min(100, opts.topK * 3)), fields });
  if (opts.year) params.set('year', opts.year);
  if (opts.openAccessOnly) params.set('openAccessPdf', '');
  if (opts.fieldsOfStudy) params.set('fieldsOfStudy', opts.fieldsOfStudy);
  const headers = { 'User-Agent': UA_DESKTOP, 'Accept': 'application/json' };
  if (process.env.SEMANTIC_SCHOLAR_API_KEY) headers['x-api-key'] = process.env.SEMANTIC_SCHOLAR_API_KEY;
  const r = await fetch('https://api.semanticscholar.org/graph/v1/paper/search?' + params.toString(), { headers });
  if (!r.ok) throw new Error('S2 ' + r.status);
  const j = await r.json();
  return (j.data || []).map(p => ({
    src: 'S2',
    paperId: p.paperId,
    title: p.title || '',
    abstract: p.abstract || (p.tldr && p.tldr.text) || '',
    year: p.year || (p.publicationDate ? p.publicationDate.slice(0, 4) : null),
    venue: p.venue || '',
    authors: (p.authors || []).map(a => a.name).slice(0, 8),
    citationCount: p.citationCount || 0,
    influentialCitationCount: p.influentialCitationCount || 0,
    doi: p.externalIds && p.externalIds.DOI || '',
    arxivId: p.externalIds && p.externalIds.ArXiv || '',
    pdf: p.openAccessPdf && p.openAccessPdf.url || '',
    tldr: p.tldr && p.tldr.text || '',
  }));
}
async function _arxivSearch(query, opts) {
  const params = new URLSearchParams({
    search_query: 'all:' + query,
    start: '0',
    max_results: String(Math.min(50, opts.topK * 2)),
    sortBy: 'relevance', sortOrder: 'descending',
  });
  const r = await fetch('http://export.arxiv.org/api/query?' + params.toString(), { headers: { 'User-Agent': UA_DESKTOP } });
  if (!r.ok) throw new Error('arXiv ' + r.status);
  const xml = await r.text();
  const out = [];
  const entryRe = /<entry>([\s\S]*?)<\/entry>/g; let m;
  while ((m = entryRe.exec(xml))) {
    const ent = m[1];
    const get = (tag) => { const mm = ent.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)<\\/' + tag + '>')); return mm ? stripHtml(mm[1]).trim() : ''; };
    const id = get('id');
    const arxivId = id.replace(/^https?:\/\/arxiv\.org\/abs\//, '').replace(/v\d+$/, '');
    const authors = [...ent.matchAll(/<name>([\s\S]*?)<\/name>/g)].map(x => x[1].trim()).slice(0, 8);
    const pubDate = get('published');
    out.push({
      src: 'arXiv',
      paperId: 'ARXIV:' + arxivId,
      title: get('title').replace(/\s+/g, ' '),
      abstract: get('summary').replace(/\s+/g, ' '),
      year: pubDate ? pubDate.slice(0, 4) : null,
      venue: 'arXiv',
      authors,
      citationCount: 0,
      influentialCitationCount: 0,
      doi: get('arxiv:doi') || '',
      arxivId,
      pdf: 'https://arxiv.org/pdf/' + arxivId + '.pdf',
      tldr: '',
    });
  }
  return out;
}
async function paperSearch(query, opts) {
  opts = opts || {}; const topK = opts.topK || 8;
  const log = typeof opts.progress === 'function' ? opts.progress : () => {};
  log(`并行检索 Semantic Scholar + arXiv "${query}" …`);
  const results = await Promise.allSettled([
    _semanticScholarSearch(query, { topK, year: opts.year, openAccessOnly: opts.openAccessOnly, fieldsOfStudy: opts.fieldsOfStudy }),
    _arxivSearch(query, { topK }),
  ]);
  const okCount = results.filter(r => r.status === 'fulfilled').length;
  log(`来源响应 ${okCount}/2，合并去重排序中…`);
  const all = [];
  for (const r of results) if (r.status === 'fulfilled') all.push(...r.value);
  if (!all.length) {
    const errs = results.filter(r => r.status === 'rejected').map(r => r.reason.message);
    return '论文检索失败：\n' + (errs.length ? errs.join('\n') : '没有匹配结果');
  }
  // 去重：先按 DOI，再按 arxivId，最后按归一化标题
  const seen = new Map();
  for (const p of all) {
    const key = (p.doi && p.doi.toLowerCase()) || (p.arxivId && 'arxiv:' + p.arxivId) || _normTitle(p.title);
    if (!seen.has(key)) seen.set(key, p);
    else {
      // 合并 Semantic Scholar 的 citationCount 到已存在 arXiv 条目
      const exist = seen.get(key);
      if (p.citationCount > exist.citationCount) exist.citationCount = p.citationCount;
      if (!exist.tldr && p.tldr) exist.tldr = p.tldr;
      if (!exist.pdf && p.pdf) exist.pdf = p.pdf;
      if (!exist.abstract && p.abstract) exist.abstract = p.abstract;
    }
  }
  const merged = [...seen.values()];
  // 排序：综合分 = log10(citations+1)*5 + 新鲜度（近 5 年加分）
  const nowY = new Date().getFullYear();
  merged.sort((a, b) => {
    const sa = Math.log10((a.citationCount || 0) + 1) * 5 + (a.year ? Math.max(0, 6 - (nowY - a.year)) : 0);
    const sb = Math.log10((b.citationCount || 0) + 1) * 5 + (b.year ? Math.max(0, 6 - (nowY - b.year)) : 0);
    return sb - sa;
  });
  if (opts.openAccessOnly) {
    for (let i = merged.length - 1; i >= 0; i--) if (!merged[i].pdf) merged.splice(i, 1);
  }
  const top = merged.slice(0, topK);
  return `[paper_search] "${query}" → 找到 ${merged.length} 篇（显示前 ${top.length}），按引用+新鲜度排序：\n\n` +
    top.map((p, i) => {
      const auth = p.authors.length ? p.authors.slice(0, 4).join(', ') + (p.authors.length > 4 ? ' et al.' : '') : '';
      const cites = p.citationCount ? `📎 ${p.citationCount} 引用` : (p.src === 'arXiv' ? '📎 arXiv preprint' : '');
      const ids = [p.doi && 'DOI:' + p.doi, p.arxivId && 'ARXIV:' + p.arxivId].filter(Boolean).join(' | ');
      const pdf = p.pdf ? `\n   📄 PDF: ${p.pdf}` : '';
      const tldr = p.tldr ? `\n   🧬 TL;DR: ${p.tldr}` : '';
      const abs = p.abstract ? `\n   摘要: ${p.abstract.slice(0, 500)}${p.abstract.length > 500 ? '…' : ''}` : '';
      return `${i+1}. ${p.title}  (${p.year || '?'}, ${p.venue || p.src})\n   作者: ${auth}\n   ${cites}  ${ids}${pdf}${tldr}${abs}`;
    }).join('\n\n') +
    `\n\n💡 用 paper_fetch("DOI:xxx" 或 "ARXIV:xxx") 拿完整 references；加 download:true 直接把 OA PDF 存到 downloads/papers/，再 read_paper 抽章节。`;
}
function _normalizeId(id) {
  id = (id || '').trim();
  if (/^10\.\d{4,}\//.test(id)) return 'DOI:' + id;                       // bare DOI
  if (/^\d{4}\.\d{4,5}(v\d+)?$/.test(id)) return 'ARXIV:' + id.replace(/v\d+$/, ''); // bare arXiv
  if (/^arxiv:/i.test(id)) return 'ARXIV:' + id.replace(/^arxiv:/i, '').replace(/v\d+$/, '');
  return id;
}
async function paperFetch(id, opts) {
  opts = opts || {}; const maxRefs = opts.maxRefs || 30;
  const log = typeof opts.progress === 'function' ? opts.progress : () => {};
  const norm = _normalizeId(id);
  log(`Semantic Scholar 拉取 ${norm} 元数据 + 引用…`);
  const headers = { 'User-Agent': UA_DESKTOP, 'Accept': 'application/json' };
  if (process.env.SEMANTIC_SCHOLAR_API_KEY) headers['x-api-key'] = process.env.SEMANTIC_SCHOLAR_API_KEY;
  const fields = 'title,abstract,year,authors.name,venue,citationCount,influentialCitationCount,openAccessPdf,externalIds,tldr,publicationDate,references.title,references.year,references.authors.name,references.externalIds,references.citationCount';
  const r = await fetch(`https://api.semanticscholar.org/graph/v1/paper/${encodeURIComponent(norm)}?fields=${encodeURIComponent(fields)}`, { headers });
  if (!r.ok) {
    if (r.status === 404) return `论文未找到：${norm}（确认 ID 形式：DOI:10.x/x、ARXIV:2106.15928、Semantic Scholar 40 位 hex）`;
    return `paper_fetch 失败：HTTP ${r.status} ${await r.text().catch(() => '')}`;
  }
  const p = await r.json();
  const auth = (p.authors || []).map(a => a.name).join(', ');
  const pdf = p.openAccessPdf && p.openAccessPdf.url || '';
  const refs = (p.references || []).slice(0, maxRefs).map((rf, i) => {
    const a = (rf.authors || []).map(x => x.name).slice(0, 3).join(', ');
    const doi = rf.externalIds && rf.externalIds.DOI ? ` DOI:${rf.externalIds.DOI}` : '';
    const arx = rf.externalIds && rf.externalIds.ArXiv ? ` ARXIV:${rf.externalIds.ArXiv}` : '';
    return `  [${i+1}] ${rf.title || '(无标题)'} — ${a || '?'} (${rf.year || '?'})${doi}${arx}${rf.citationCount ? ' ('+rf.citationCount+' cit)' : ''}`;
  }).join('\n');
  let dl = '';
  if (opts.download && pdf) {
    try {
      const safeName = (p.externalIds && (p.externalIds.DOI || p.externalIds.ArXiv) || p.paperId || 'paper').replace(/[^\w.\-]+/g, '_').slice(0, 80) + '.pdf';
      log(`下载 OA PDF: ${pdf} → downloads/papers/${safeName}`);
      dl = '\n\n' + await downloadFile(pdf, path.join('downloads', 'papers', safeName));
    } catch (e) { dl = '\n\n下载 PDF 失败：' + e.message; }
  } else if (opts.download && !pdf) {
    dl = '\n\n（无 Open-Access PDF 可下载）';
  }
  return `# ${p.title}
${auth}
${p.venue || ''}${p.year ? ', ' + p.year : ''}${p.citationCount ? `  •  ${p.citationCount} citations (${p.influentialCitationCount || 0} influential)` : ''}
${p.externalIds && p.externalIds.DOI ? 'DOI: ' + p.externalIds.DOI : ''}${p.externalIds && p.externalIds.ArXiv ? '  ARXIV:' + p.externalIds.ArXiv : ''}
${pdf ? 'OA PDF: ' + pdf : ''}

## TL;DR
${p.tldr && p.tldr.text || '（无）'}

## Abstract
${p.abstract || '（无）'}

## References (top ${Math.min(maxRefs, (p.references || []).length)} / ${(p.references || []).length})
${refs || '（无）'}${dl}`;
}

// ====================== 论文章节抽取 read_paper ======================
async function readPaper(p, focus, progress) {
  const log = typeof progress === 'function' ? progress : () => {};
  log(`PDF/DOCX → 文本：${p}`);
  const raw = await readDocument(p, log);
  log(`原文 ${raw.length} 字符，开始章节切分…`);
  // 找正文（去掉 readDocument 头部 [type · N 页 · WxH]）
  const headMatch = raw.match(/^\[[^\]]+\]\s*\n/);
  const body = headMatch ? raw.slice(headMatch[0].length) : raw;
  // 章节标题正则：行首或换行后大写或编号标题
  const SEC = [
    { key: 'Abstract',     re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?abstract\b[^\n]*\n/i },
    { key: 'Keywords',     re: /(?:^|\n)\s*(?:key\s*words?|keywords)\b[^\n]*\n/i },
    { key: 'Introduction', re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?introduction\b[^\n]*\n/i },
    { key: 'Background',   re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?(?:background|related\s*work|literature\s*review)\b[^\n]*\n/i },
    { key: 'Methods',      re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?(?:methods?|methodology|mathematical\s*model|governing\s*equations?|numerical\s*method|materials?\s*and\s*methods?|model(?:ing)?\s*(?:and|&)?\s*(?:simulation|equations?)?)\b[^\n]*\n/i },
    { key: 'Experiments',  re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?(?:experiments?|experimental\s*(?:setup|details?|procedure)|simulation\s*setup|case\s*setup|validation)\b[^\n]*\n/i },
    { key: 'Results',      re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?(?:results?|results?\s*and\s*discussions?|discussions?|findings)\b[^\n]*\n/i },
    { key: 'Conclusion',   re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?(?:conclusions?|concluding\s*remarks|summary)\b[^\n]*\n/i },
    { key: 'References',   re: /(?:^|\n)\s*(?:[IVX]+\.\s*|\d{0,2}\.?\s*)?(?:references?|bibliography)\b[^\n]*\n/i },
  ];
  const hits = [];
  for (const s of SEC) {
    const m = body.match(s.re);
    if (m) hits.push({ key: s.key, idx: m.index + m[0].indexOf(m[0].trimStart()), end: m.index + m[0].length });
  }
  hits.sort((a, b) => a.idx - b.idx);
  const sections = [];
  for (let i = 0; i < hits.length; i++) {
    const start = hits[i].end;
    const end = i + 1 < hits.length ? hits[i+1].idx : body.length;
    let txt = body.slice(start, end).trim();
    if (txt.length > 3500) txt = txt.slice(0, 3500) + '\n…[本节较长，已截断；如需全文请用 read_document 然后 grep_search]';
    sections.push({ key: hits[i].key, text: txt });
  }
  // 没识别出来任何章节 → 退化为前 3500 字
  if (!sections.length) {
    return `# ${path.basename(p)}\n\n（未识别出章节结构，可能是非论文 PDF——下面是正文前 3500 字）\n\n${body.slice(0, 3500)}`;
  }
  // 标题（优先取正文开头第一行非空、长度 < 200）
  let title = '';
  const firstLines = body.slice(0, 1500).split(/\n/).map(l => l.trim()).filter(Boolean);
  for (const l of firstLines) { if (l.length >= 6 && l.length < 200 && !/^abstract\b/i.test(l)) { title = l; break; } }
  // 方程编号统计
  const eqMatches = body.match(/\(\s*\d{1,3}[a-z]?\s*\)/g) || [];
  const eqCount = new Set(eqMatches).size;
  // 图表统计
  const figCount = (body.match(/\bFig(?:\.|ure)?\s*\d+/gi) || []).length;
  const tblCount = (body.match(/\bTable\s*\d+/gi) || []).length;

  let out = `# ${title || path.basename(p)}\n\n📊 结构：${sections.length} 个识别章节 · 公式编号 ${eqCount} 个 · 图 ${figCount} 处 · 表 ${tblCount} 处\n\n`;
  for (const s of sections) {
    out += `## ${s.key}\n${s.text}\n\n`;
  }
  if (focus) {
    const fr = new RegExp(focus.split(/\s+/).filter(Boolean).join('|'), 'gi');
    const paras = body.split(/\n\s*\n/);
    const hitsP = [];
    for (const para of paras) {
      const matches = para.match(fr);
      if (matches && matches.length >= 1 && para.length > 30) hitsP.push({ para, hits: matches.length });
      if (hitsP.length > 30) break;
    }
    hitsP.sort((a, b) => b.hits - a.hits);
    if (hitsP.length) {
      out += `## 🔍 focus="${focus}" 命中段落 (${hitsP.length} 段，按命中数排序，前 8)\n\n`;
      for (const h of hitsP.slice(0, 8)) {
        out += `> ${h.para.replace(/\s+/g, ' ').slice(0, 700)}${h.para.length > 700 ? '…' : ''}\n\n`;
      }
    } else {
      out += `## 🔍 focus="${focus}" 未在正文中命中关键词\n\n`;
    }
  }
  return out;
}

// ====================== vision_analyze ======================
async function _imageToDataUrl(p) {
  if (/^https?:\/\//i.test(p)) {
    const r = await fetch(p, { headers: { 'User-Agent': UA_DESKTOP } });
    if (!r.ok) throw new Error('图片下载失败：HTTP ' + r.status + ' ' + p);
    const ct = r.headers.get('content-type') || 'image/png';
    const buf = Buffer.from(await r.arrayBuffer());
    return 'data:' + ct.split(';')[0] + ';base64,' + buf.toString('base64');
  }
  const abs = path.isAbsolute(p) ? p : safePath(p);
  const buf = await fs.readFile(abs);
  const ext = path.extname(abs).slice(1).toLowerCase();
  const mimeMap = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp' };
  const mime = mimeMap[ext] || 'image/png';
  return 'data:' + mime + ';base64,' + buf.toString('base64');
}
async function visionAnalyze(images, question, maxTokens, progress) {
  const log = typeof progress === 'function' ? progress : () => {};
  if (!images || !images.length) return 'vision_analyze 需要至少 1 张图片路径';
  if (!question) return 'vision_analyze 需要 question 参数';
  log(`编码 ${Math.min(images.length, 6)} 张图为 base64 …`);
  const dataUrls = [];
  for (const im of images.slice(0, 6)) {
    try { dataUrls.push(await _imageToDataUrl(im)); }
    catch (e) { return '读图失败：' + e.message; }
  }
  log(`调用 VLM (专用视觉模型路由，detail=high) …`);
  const sys = '你是高精度科技图像分析助手。任务：严格按用户问题从图片中提取信息，给出有数值、有单位、有坐标的结构化回答。如果是曲线图：列出每条曲线的标签 + 关键点 (x,y) 数值（在网格刻度间用线性插值估算并标注"估读"）。如果是公式：用 LaTeX 转写完整公式与等号两侧符号定义。如果是表格：用 Markdown 表格转写。如果是流程图：用编号列出节点与连接关系。无法确定的数值写"难以辨认"，绝不要编造。';
  const userContent = [
    { type: 'text', text: question + '\n\n（请按上述格式严格作答；引用图片时用 [图1] [图2] 编号）' },
    ...dataUrls.map(u => ({ type: 'image_url', image_url: { url: u, detail: 'high' } })),
  ];
  const messages = [
    { role: 'system', content: sys },
    { role: 'user', content: userContent },
  ];
  try {
    // V4.1 专用视觉路由：若配了 visionModel，不论主模型是 Copilot/DeepSeek 还是别的都主动走这个端点，
    // 避免主模型 "not a VLM" 400。结果以文字回传给主模型。
    const useDedicated = !!(SETTINGS.visionModel && SETTINGS.visionBaseUrl);
    let resp, j;
    if (useDedicated) {
      const vkey = (SETTINGS.visionApiKey && SETTINGS.visionApiKey.trim()) || SETTINGS.apiKey;
      if (!vkey) return 'vision_analyze 失败：未配置 visionApiKey 且主 apiKey 为空';
      log(`→ VLM 端点: ${SETTINGS.visionBaseUrl}  模型: ${SETTINGS.visionModel}`);
      resp = await fetch(`${SETTINGS.visionBaseUrl.replace(/\/$/,'')}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + vkey },
        body: JSON.stringify({ model: SETTINGS.visionModel, messages, temperature: 0.0, max_tokens: maxTokens, stream: false }),
      });
    } else if (SETTINGS.provider === 'copilot') {
      const tok = await copilotRefreshApiToken();
      resp = await fetch('https://api.githubcopilot.com/chat/completions', {
        method: 'POST',
        headers: copilotHeaders(tok),
        body: JSON.stringify({ model: SETTINGS.copilotModel || SETTINGS.model || 'gpt-4.1', messages, temperature: 0.0, max_tokens: maxTokens, stream: false }),
      });
    } else {
      resp = await fetch(`${SETTINGS.baseUrl.replace(/\/$/,'')}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + SETTINGS.apiKey },
        body: JSON.stringify({ model: SETTINGS.model, messages, temperature: 0.0, max_tokens: maxTokens, stream: false }),
      });
    }
    if (!resp.ok) return 'vision_analyze HTTP ' + resp.status + ' (model=' + (useDedicated ? SETTINGS.visionModel : (SETTINGS.provider === 'copilot' ? (SETTINGS.copilotModel || SETTINGS.model) : SETTINGS.model)) + '): ' + (await resp.text().catch(() => '')).slice(0, 500) + '\n提示：如果提示 not a VLM，请在 ⚙ 设置里调整 visionModel（推荐 SiliconFlow: Pro/moonshotai/Kimi-K2.6 / Qwen/Qwen2.5-VL-72B-Instruct / deepseek-ai/deepseek-vl2）';
    j = await resp.json();
    const ans = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content || '（模型未返回内容）';
    const tag = useDedicated ? ` · ${SETTINGS.visionModel}` : '';
    return `[vision_analyze · ${dataUrls.length} 张图 · detail=high${tag}]\n\n` + ans;
  } catch (e) {
    return 'vision_analyze 异常：' + e.message;
  }
}

// ====================== 图片搜索（Bing Images） ======================
async function imageSearch(query, topK) {
  const url = 'https://www.bing.com/images/search?q=' + encodeURIComponent(query) + '&form=HDRSC2&FORM=IRFLTR&first=1';
  const r = await fetch(url, { headers: { 'User-Agent': UA_DESKTOP, 'Accept': 'text/html', 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8' } });
  if (!r.ok) throw new Error('Bing Images ' + r.status);
  const html = await r.text();
  const out = [];
  // Bing 把每张图的元数据 JSON 编码塞在 class="iusc" 元素的 m="..." 属性里
  const re = /<a[^>]+class="iusc"[^>]+m="([^"]+)"/g;
  let m; const seen = new Set();
  while ((m = re.exec(html)) && out.length < topK) {
    try {
      const meta = JSON.parse(m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
      const image = meta.murl || meta.turl;
      if (!image || seen.has(image)) continue;
      seen.add(image);
      out.push({
        image,
        thumb: meta.turl || image,
        title: meta.t || '',
        source: meta.purl || '',
        host: meta.dom || '',
        w: meta.mw, h: meta.mh
      });
    } catch {}
  }
  // 兜底：直接抓 <img class="mimg" src="...">
  if (out.length === 0) {
    const re2 = /<img[^>]+class="mimg"[^>]+src="([^"]+)"[^>]*>/g;
    while ((m = re2.exec(html)) && out.length < topK) {
      if (m[1].startsWith('http')) out.push({ image: m[1], thumb: m[1], title: '', source: '', host: '' });
    }
  }
  return out;
}

function broadcastImages(images, query) {
  const msg = JSON.stringify({ type: 'images', images, query });
  for (const ws of allClients) if (ws.readyState === 1) ws.send(msg);
}
async function fetchUrlText(url, maxChars, withImages, progress) {
  const log = typeof progress === 'function' ? progress : () => {};
  log(`GET ${url} …`);
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8' }, redirect: 'follow' });
  if (!r.ok) return `[HTTP ${r.status}] ${url}`;
  const ct = r.headers.get('content-type') || '';
  let raw = await r.text();
  log(`HTTP ${r.status} · ${ct || '?'} · ${raw.length} 字符`);
  let text = ct.includes('html') ? stripHtml(raw) : raw;
  text = text.slice(0, maxChars);
  if (withImages && ct.includes('html')) {
    try {
      const imgs = [];
      const re = /<img[^>]+>/gi;
      let m;
      while ((m = re.exec(raw)) && imgs.length < 20) {
        const tag = m[0];
        const src = (tag.match(/\bsrc\s*=\s*["']([^"']+)["']/i) || [])[1];
        const alt = (tag.match(/\balt\s*=\s*["']([^"']*)["']/i) || [])[1] || '';
        if (!src || src.startsWith('data:')) continue;
        const abs = new URL(src, url).href;
        imgs.push({ src: abs, alt });
      }
      if (imgs.length) {
        text += '\n\n--- 页面图片（共 ' + imgs.length + ' 张，可用 download_file 下载）---\n' +
                imgs.map((x, i) => `[${i+1}] ${x.alt || '(无 alt)'}\n     ${x.src}`).join('\n');
      }
    } catch {}
  }
  return text;
}

// ====================== 文档读取（PDF/DOCX/PPTX/XLSX/IMG） ======================
async function readDocument(p, progress) {
  const log = typeof progress === 'function' ? progress : () => {};
  if (!p) throw new Error('缺少 path');
  const abs = path.isAbsolute(p) ? p : safePath(p);
  await fs.access(abs);
  const py = SETTINGS.pythonPath || (IS_WIN ? 'python' : 'python3');
  const script = path.join(__dirname, 'doc_reader.py');
  log(`Python doc_reader.py 解析 ${path.basename(abs)} …`);
  // PDF 图片输出到工作区下 .cache/pdf_images/<safe>/  ——前端可通过 /api/file?raw=1&path= 预览
  const safeBase = path.basename(abs).replace(/[^\w.\-]+/g, '_').slice(0, 80);
  const imgOutAbs = path.join(WORKSPACE, '.cache', 'pdf_images', safeBase + '_' + Date.now().toString(36));
  try { await fs.mkdir(imgOutAbs, { recursive: true }); } catch {}
  return await new Promise((resolve) => {
    const proc = spawn(py, [script, abs], {
      windowsHide: true,
      env: { ...process.env, PDF_IMG_OUT_DIR: imgOutAbs },
    });
    let out = '', err = '', killed = false;
    const OUT_HARD_CAP = 8 * 1024 * 1024; // 8MB stdout 上限，防止 doc_reader 返回上百万字
    proc.stdout.on('data', d => {
      if (killed) return;
      out += d.toString();
      if (out.length > OUT_HARD_CAP) { killed = true; try { proc.kill(); } catch {} }
    });
    proc.stderr.on('data', d => { err += d.toString(); if (err.length > 65536) err = err.slice(-65536); });
    proc.on('error', e => resolve('调用 Python 失败：' + e.message + '（请在顶部 Python 选择器选好解释器）'));
    proc.on('close', () => {
      try {
        const j = JSON.parse(out);
        if (!j.ok) return resolve('读取失败：' + (j.error || '未知') + (err ? '\n' + err.slice(-300) : ''));
        const head = `[${j.type}${j.pages ? ` · ${j.pages} 页` : ''}${j.size ? ` · ${j.size.join('x')}` : ''}]`;
        const fullLen = (j.text || '').length;
        const body = (j.text || '').slice(0, 20000);
        const trailer = fullLen > 20000 ? `\n... [原文 ${fullLen} 字，仅返回前 20000；需定位其他部分请告知关键词后重调，或用 grep_search] ...` : '';
        // 图片：转为 /api/file?raw=1&path=<rel> 形式塞进结果尾部，前端 tool_result 自动提取并渲染缩略图
        let imgBlock = '';
        const imgs = Array.isArray(j.images) ? j.images : [];
        if (imgs.length) {
          const items = [];
          const galleryItems = [];
          for (const im of imgs.slice(0, 60)) {
            try {
              const rel = path.relative(WORKSPACE, im.path).replace(/\\/g, '/');
              if (rel.startsWith('..')) continue;
              const url = `/api/file?raw=1&path=${encodeURIComponent(rel)}`;
              const tag = im.kind === 'scan_page' ? `扫描页 P${im.page}` : `图 P${im.page}-${im.index}`;
              items.push(`${tag} ${im.w}x${im.h}: ${url}`);
              galleryItems.push({
                image: url, thumb: url,
                title: `${tag} ${im.w}x${im.h}` + (im.ocr ? ' · ' + im.ocr.slice(0, 40).replace(/\s+/g, ' ') : ''),
                source: url, host: 'PDF: ' + path.basename(abs),
              });
            } catch {}
          }
          if (items.length) {
            imgBlock = `\n\n--- 提取的图片（共 ${imgs.length}${imgs.length > 60 ? '，仅显示前 60' : ''} 张）---\n` + items.join('\n');
            try { broadcastImages(galleryItems, 'PDF: ' + path.basename(abs)); } catch {}
          }
        }
        resolve(head + (killed ? ' [stdout 被中断，返回过大]' : '') + '\n' + body + trailer + (j.ocr_error ? '\n(OCR: ' + j.ocr_error + ')' : '') + imgBlock);
      } catch (e) {
        resolve('解析失败：' + e.message + '\n' + (err || out).slice(-500));
      }
    });
  });
}

// ====================== 下载文件 ======================
async function downloadFile(url, saveAs) {
  if (!url) throw new Error('缺少 url');
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 DeepSimCodeMAX' }, redirect: 'follow' });
  if (!r.ok) return `[HTTP ${r.status}] ${url}`;
  let rel = saveAs;
  if (!rel) {
    const u = new URL(url);
    const base = path.basename(u.pathname) || ('file_' + Date.now());
    rel = path.join('downloads', base);
  }
  const abs = safePath(rel);
  await fs.mkdir(path.dirname(abs), { recursive: true });
  const buf = Buffer.from(await r.arrayBuffer());
  await fs.writeFile(abs, buf);
  const ct = r.headers.get('content-type') || '';
  return `已下载到 ${path.relative(WORKSPACE, abs)} (${buf.length} bytes, ${ct})`;
}

// ====================== pvpython 离屏渲染（可靠替代 PrintWindow） ======================
function pvpythonExe() {
  if (SETTINGS.paraviewPython) return SETTINGS.paraviewPython;
  if (SETTINGS.paraviewExe) {
    const dir = path.dirname(SETTINGS.paraviewExe);
    return path.join(dir, IS_WIN ? 'pvpython.exe' : 'pvpython');
  }
  // Windows 兜底：扫常见安装路径
  if (IS_WIN) {
    const roots = ['C:\\Program Files', 'C:\\Program Files (x86)'];
    for (const r of roots) {
      try {
        const dirs = fssync.readdirSync(r).filter(n => /^ParaView/i.test(n));
        for (const d of dirs) {
          const p = path.join(r, d, 'bin', 'pvpython.exe');
          if (fssync.existsSync(p)) return p;
        }
      } catch {}
    }
  } else {
    // Linux 兜底：常见路径 + /opt 下的官网 tarball 解压目录
    const cands = ['/usr/bin/pvpython', '/usr/local/bin/pvpython'];
    for (const r of ['/opt', '/usr/local']) {
      try {
        for (const d of fssync.readdirSync(r)) {
          if (/paraview/i.test(d)) {
            const p = path.join(r, d, 'bin', 'pvpython');
            cands.push(p);
          }
        }
      } catch {}
    }
    for (const p of cands) { if (fssync.existsSync(p)) return p; }
  }
  return IS_WIN ? 'pvpython.exe' : 'pvpython';
}
// 把宿主 PYTHONHOME / PYTHONPATH 从 env 里剔除，否则会劫持 pvpython 内嵌解释器
// 导致 `import paraview` 失败（典型现象：IMPORT_ERR No module named 'paraview'）
function pvCleanEnv() {
  const e = { ...process.env };
  delete e.PYTHONHOME;
  delete e.PYTHONPATH;
  delete e.PYTHONSTARTUP;
  delete e.PYTHONNOUSERSITE;
  return e;
}
async function pvRenderOffscreen({ casePath, width=1024, height=720, azimuth=30, elevation=15, zoom=1.0, field='', timeStep=null }) {
  if (!casePath) throw new Error('缺少 case_path');
  const abs = path.isAbsolute(casePath) ? casePath : safePath(casePath);
  await fs.access(abs);
  const exe = pvpythonExe();
  const outPng = path.join(os.tmpdir(), `dscm_pv_${crypto.randomBytes(12).toString('hex')}.png`);
  const metaPath = outPng + '.json';
  const fieldArg = (field || '').replace(/[^A-Za-z0-9_:]/g, '');
  const tsArg = (timeStep === null || timeStep === undefined || timeStep === '') ? 'None' : Number(timeStep);
  // 健壮版 pvpython 脚本：
  // 1) 自动选择 reader（OpenFOAM 目录优先用 OpenFOAMReader 而不是 case.foam，避免缓存问题）
  // 2) 启用所有 cell/point arrays（OpenFOAMReader 默认不读，需显式开启）
  // 3) 切到选定时间步后再 UpdatePipeline，再读取场清单（避免 t=0 时场为空）
  // 4) 把 stderr 错误也通过 print 输出，便于前端展示
  const py = `
import os, sys, json, traceback
def _err(tag, e):
    print('[' + tag + ']', e); print(traceback.format_exc())

try:
    from paraview.simple import *
except Exception as e:
    print('IMPORT_ERR', e); sys.exit(2)

paths_in = r"""${abs}"""
out      = r"""${outPng}"""
meta_out = r"""${metaPath}"""
field    = ${JSON.stringify(fieldArg)}
ts       = ${tsArg}

reader = None
is_dir = os.path.isdir(paths_in)
# OpenFOAM 目录：优先用原生 OpenFOAMReader 打开 case.foam（自动判别 reconstruct/decompose）
if is_dir:
    foam = os.path.join(paths_in, 'case.foam')
    try:
        if not os.path.exists(foam):
            with open(foam, 'a'): pass
    except Exception as e:
        _err('FOAM_TOUCH_ERR', e)
    try:
        reader = OpenFOAMReader(FileName=foam)
    except Exception:
        try: reader = OpenDataFile(foam)
        except Exception as e: _err('OPEN_DIR_ERR', e)
else:
    try: reader = OpenDataFile(paths_in)
    except Exception as e: _err('OPEN_FILE_ERR', e)

if reader is None:
    print('READER_NONE', paths_in); sys.exit(3)

# 启用所有可用 cell/point 数组（OpenFOAMReader 必需；其它 reader 也兼容）
def _enable_all(arr_status):
    try:
        names = list(arr_status.GetData()) if hasattr(arr_status, 'GetData') else list(arr_status)
    except Exception: names = []
    for n in names:
        try: arr_status.SetArrayStatus(n, 1)
        except Exception:
            try: arr_status[n] = 1
            except Exception: pass
    return names

cell_arrays_avail = []
point_arrays_avail = []
try:
    if hasattr(reader, 'CellArrays'):       cell_arrays_avail  = _enable_all(reader.CellArrays)
    if hasattr(reader, 'PointArrays'):      point_arrays_avail = _enable_all(reader.PointArrays)
    if hasattr(reader, 'CellArrayStatus'):  cell_arrays_avail  = cell_arrays_avail or _enable_all(reader.CellArrayStatus)
    if hasattr(reader, 'PointArrayStatus'): point_arrays_avail = point_arrays_avail or _enable_all(reader.PointArrayStatus)
except Exception as e: _err('ARR_ENABLE_ERR', e)

# OpenFOAM：默认只读 internalMesh，避免吐出 patch 多段
try:
    if hasattr(reader, 'MeshRegions'):
        regs = list(reader.MeshRegions.GetAvailable()) if hasattr(reader.MeshRegions, 'GetAvailable') else []
        if 'internalMesh' in regs: reader.MeshRegions = ['internalMesh']
except Exception: pass

try: reader.UpdatePipeline()
except Exception as e: _err('UPDATE_ERR', e)

# 时间步
times = []
try: times = list(getattr(reader, 'TimestepValues', []) or [])
except Exception: times = []

# 选时间步并刷新
sel_t = None
if ts is not None and len(times) > 0:
    idx = int(ts)
    if idx < 0: idx = len(times) - 1
    if idx >= len(times): idx = len(times) - 1
    sel_t = times[idx]
    try: reader.UpdatePipeline(sel_t)
    except Exception as e: _err('UPDATE_T_ERR', e)

# 选完时间步再扫一遍真正可用的场（避免 t=0 时为空）
point_arrays = []
cell_arrays = []
try:
    di = reader.GetDataInformation()
    pi = di.GetPointDataInformation()
    for i in range(pi.GetNumberOfArrays()):
        a = pi.GetArrayInformation(i).GetName()
        if a not in point_arrays: point_arrays.append(a)
    ci = di.GetCellDataInformation()
    for i in range(ci.GetNumberOfArrays()):
        a = ci.GetArrayInformation(i).GetName()
        if a not in cell_arrays: cell_arrays.append(a)
except Exception as e: _err('FIELDS_ERR', e)
# 后备：用 reader 上自报的列表
if not point_arrays and not cell_arrays:
    point_arrays = point_arrays_avail or []
    cell_arrays  = cell_arrays_avail or []

# 视图
view = GetActiveViewOrCreate('RenderView')
view.UseColorPaletteForBackground = 0
view.Background = [0.04, 0.03, 0.07]
view.ViewSize = [${width}, ${height}]
if sel_t is not None:
    try: view.ViewTime = sel_t
    except Exception: pass

disp = Show(reader, view)

# 上色
if field and (field in point_arrays or field in cell_arrays):
    assoc = 'POINTS' if field in point_arrays else 'CELLS'
    try:
        ColorBy(disp, (assoc, field))
        try: disp.RescaleTransferFunctionToDataRange(True, False)
        except Exception: pass
        try: disp.SetScalarBarVisibility(view, True)
        except Exception: pass
    except Exception as e: _err('COLORBY_ERR', e)
elif field:
    print('FIELD_NOT_FOUND', field, '| available cell:', cell_arrays, '| point:', point_arrays)

try: view.ResetCamera()
except Exception: pass
try:
    cam = GetActiveCamera()
    cam.Azimuth(${azimuth}); cam.Elevation(${elevation}); cam.Dolly(${zoom})
except Exception as e: _err('CAM_ERR', e)

try: Render(view)
except Exception as e: _err('RENDER_ERR', e)
try: SaveScreenshot(out, view, ImageResolution=[${width},${height}])
except Exception as e: print('SAVE_ERR', e); sys.exit(4)

with open(meta_out, 'w', encoding='utf-8') as f:
    json.dump({
        'times': times, 'point_arrays': point_arrays, 'cell_arrays': cell_arrays,
        'fields': cell_arrays + [p for p in point_arrays if p not in cell_arrays],
        'field_used': field if (field in point_arrays or field in cell_arrays) else '',
        'time_index': (int(ts) if ts is not None else None),
        'time_value': sel_t
    }, f, ensure_ascii=False)
print('OK', out)
`;
  return await new Promise((resolve, reject) => {
    const p = spawn(exe, ['-'], { cwd: WORKSPACE, windowsHide: true, env: pvCleanEnv() });
    let outBuf = '', errBuf = '';
    p.stdout.on('data', d => outBuf += d.toString());
    p.stderr.on('data', d => errBuf += d.toString());
    p.on('error', err => reject(new Error(`pvpython 启动失败：${err.message}（路径：${exe}）`)));
    const to = setTimeout(() => { try { p.kill(); } catch {} reject(new Error('pvpython 超时 (90s)')); }, 90000);
    p.on('close', async (code) => {
      clearTimeout(to);
      // 保留最后 8 行用于错误展示（含我们脚本里的 [TAG] 前缀）
      const tailOut = outBuf.split(/\r?\n/).filter(Boolean).slice(-8).join(' | ');
      const tailErr = errBuf.split(/\r?\n/).filter(Boolean).slice(-6).join(' | ');
      pvBroadcast({ type: 'term', line: `[pvpython exit ${code}] ${tailOut}${tailErr ? ' || stderr: ' + tailErr : ''}` });
      if (code !== 0) { return reject(new Error(`pvpython exit ${code}\n${tailErr || tailOut || '(无输出)'}`)); }
      try {
        const buf = await fs.readFile(outPng);
        fs.unlink(outPng).catch(()=>{});
        let meta = null;
        try { meta = JSON.parse(await fs.readFile(metaPath, 'utf8')); fs.unlink(metaPath).catch(()=>{}); } catch {}
        resolve({ dataUrl: 'data:image/png;base64,' + buf.toString('base64'), width, height, bytes: buf.length, meta });
      } catch (e) { reject(new Error('读取输出 PNG 失败：' + e.message)); }
    });
    p.stdin.write(py); p.stdin.end();
  });
}
app.post('/api/sim/render', async (req, res) => {
  try {
    const b = req.body || {};
    const opts = { casePath: b.case_path || b.casePath, azimuth: b.azimuth, elevation: b.elevation, zoom: b.zoom, width: b.width, height: b.height, field: b.field, timeStep: b.time_step };
    const r = await pvRenderOffscreen(opts);
    pvBroadcast({ type: 'sim_frame', dataUrl: r.dataUrl, meta: r.meta });
    res.json({ ok: true, width: r.width, height: r.height, meta: r.meta });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 浏览工作区，给 ParaView 面板做文件选择用
app.get('/api/sim/browse', async (req, res) => {
  try {
    const rel = req.query.path || '.';
    const abs = safePath(rel);
    const st = await fs.stat(abs);
    if (!st.isDirectory()) return res.json({ error: '不是目录' });
    const entries = await fs.readdir(abs, { withFileTypes: true });
    const SIM_EXT = /\.(foam|vtu|vtk|vtp|vtm|vti|stl|cgns|exo|case|pvd|ex2|pvtu|pvtp)$/i;
    const items = [];
    for (const e of entries) {
      if (e.name.startsWith('.')) continue;
      const isOf = e.isDirectory() && (e.name === 'system' || e.name === 'constant' || /^\d/.test(e.name));
      if (e.isDirectory() || SIM_EXT.test(e.name) || isOf) {
        items.push({ name: e.name, dir: e.isDirectory() });
      }
    }
    items.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
    const parent = path.relative(WORKSPACE, path.dirname(abs));
    res.json({ ok: true, path: path.relative(WORKSPACE, abs) || '.', parent: parent === path.relative(WORKSPACE, abs) ? null : parent, items });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ====================== 图片搜索 / 下载 HTTP ======================
app.post('/api/image_search', async (req, res) => {
  try {
    const { query, top_k } = req.body || {};
    if (!query) return res.json({ error: 'missing query' });
    const imgs = await imageSearch(query, Math.min(30, top_k || 12));
    broadcastImages(imgs, query);
    res.json({ ok: true, count: imgs.length, images: imgs });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/download_image', async (req, res) => {
  try {
    const { url, save_as } = req.body || {};
    if (!url) return res.json({ error: 'missing url' });
    const out = await downloadFile(url, save_as);
    res.json({ ok: true, message: out });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ====================== OpenFOAM Beta HTTP ======================
app.get('/api/foam/config', async (req, res) => {
  const root = SETTINGS.foamRoot || '';
  const exists = root ? await pathExists(root) : false;
  const hasTutorials = root ? await pathExists(path.join(root, 'tutorials')) : false;
  const hasSrc = root ? await pathExists(path.join(root, 'src')) : false;
  res.json({ root, exists, hasTutorials, hasSrc, foamMode: !!SETTINGS.foamMode });
});
app.post('/api/foam/config', async (req, res) => {
  try {
    if (typeof req.body?.root === 'string') SETTINGS.foamRoot = req.body.root.trim();
    if (typeof req.body?.foamMode === 'boolean') SETTINGS.foamMode = req.body.foamMode;
    await saveSettings();
    res.json({ ok: true, root: SETTINGS.foamRoot, foamMode: SETTINGS.foamMode });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/foam/tutorials', async (req, res) => {
  try { res.type('text/plain').send(await foamFindTutorial(req.query.q || '', Math.min(50, parseInt(req.query.top_k) || 30))); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/foam/source', async (req, res) => {
  try { res.type('text/plain').send(await foamFindSource(req.query.q || '', req.query.kind || 'all', Math.min(50, parseInt(req.query.top_k) || 20))); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/foam/clone', async (req, res) => {
  try { res.json({ ok: true, message: await foamCloneTutorial(req.body?.tutorial_path, req.body?.dest) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/foam/inspect', async (req, res) => {
  try { res.type('text/plain').send(await foamInspectCase(req.body?.case_path)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ============ \u6c42\u89e3\u5668\u540e\u53f0\u4f5c\u4e1a HTTP ============
app.get('/api/foam/runs', (req, res) => {
  res.json({ runs: [...SOLVER_RUNS.entries()].map(([id, r]) => ({
    runId: id, casePath: r.casePath, command: r.command,
    started: r.started, ended: r.ended, exitCode: r.exitCode,
    running: !r.ended
  })) });
});
app.post('/api/foam/run', async (req, res) => {
  try {
    const { case_path, command } = req.body || {};
    const msg = await foamRunSolverAsync({ case_path, command }, null);
    const id = (msg.match(/runId:\s*(\w+)/) || [])[1] || '';
    res.json({ ok: true, runId: id, message: msg });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/foam/run/:id', (req, res) => {
  const r = SOLVER_RUNS.get(req.params.id);
  if (!r) return res.status(404).json({ error: '\u672a\u77e5 runId' });
  // \u89e3\u6790\u6700\u65b0 Time \u4e0e\u6b8b\u5dee
  let lastTime = '';
  for (let i = r.log.length - 1; i >= 0; i--) {
    const m = r.log[i].match(/^Time\s*=\s*([\d.eE+\-]+)/);
    if (m) { lastTime = m[1]; break; }
  }
  const residuals = r.log.filter(l => /Initial residual/.test(l)).slice(-30);
  // 结构化时序（给前端画曲线用）
  let seriesObj = null;
  try { seriesObj = JSON.parse(foamResidualSeries(req.params.id, 200, null)); } catch {}
  res.json({
    runId: req.params.id, casePath: r.casePath, command: r.command,
    started: r.started, ended: r.ended, exitCode: r.exitCode, running: !r.ended,
    lastTime, residuals, tail: r.log.slice(-80),
    series: seriesObj ? seriesObj.series : [],
    fields: seriesObj ? seriesObj.fields : [],
    trends: seriesObj ? seriesObj.trends : {}
  });
});
app.post('/api/foam/run/:id/stop', (req, res) => {
  res.json({ ok: true, message: foamSolverStop(req.params.id) });
});

// ====================== MFIX Beta HTTP ======================
app.get('/api/mfix/config', async (req, res) => {
  const root = SETTINGS.mfixRoot || '';
  const bash = SETTINGS.mfixBash || '';
  const exists = root ? await pathExistsSync(root) : false;
  const hasTutorials = exists ? await pathExistsSync(path.join(root, 'tutorials')) : false;
  res.json({ root, bash, exists, hasTutorials, mfixMode: !!SETTINGS.mfixMode });
});
app.post('/api/mfix/config', async (req, res) => {
  try {
    if (typeof req.body?.root === 'string') SETTINGS.mfixRoot = req.body.root.trim();
    if (typeof req.body?.bash === 'string') SETTINGS.mfixBash = req.body.bash.trim();
    if (typeof req.body?.mfixMode === 'boolean') SETTINGS.mfixMode = req.body.mfixMode;
    await saveSettings();
    res.json({ ok: true, root: SETTINGS.mfixRoot, bash: SETTINGS.mfixBash, mfixMode: SETTINGS.mfixMode });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
app.get('/api/mfix/tutorials', async (req, res) => {
  try { res.type('text/plain').send(await mfixFindTutorial(req.query.q || '', Math.min(50, parseInt(req.query.top_k) || 30))); }
  catch (e) { res.status(400).type('text/plain').send(e.message); }
});
app.post('/api/mfix/clone', async (req, res) => {
  try { res.json({ ok: true, message: await mfixCloneTutorial(req.body?.tutorial_path, req.body?.dest) }); }
  catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});
app.post('/api/mfix/inspect', async (req, res) => {
  try { res.type('text/plain').send(await mfixInspectCase(req.body?.case_path)); }
  catch (e) { res.status(400).type('text/plain').send(e.message); }
});
app.post('/api/mfix/run', async (req, res) => {
  try {
    const { case_path, command } = req.body || {};
    const msg = await mfixRunSolverAsync({ case_path, command }, null);
    res.json({ ok: true, message: msg });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});
app.post('/api/mfix/run/:id/stop', (req, res) => {
  res.json({ ok: true, message: mfixSolverStop(req.params.id) });
});

// ====================== LBM Beta HTTP ======================
app.get('/api/lbm/config', async (req, res) => {
  const root = SETTINGS.lbmTutorialRoot || '';
  const exists = root ? await pathExistsSync(root) : false;
  res.json({ tutorialRoot: root, runCmd: SETTINGS.lbmRunCmd || '', exists, lbmMode: !!SETTINGS.lbmMode });
});
app.post('/api/lbm/config', async (req, res) => {
  try {
    if (typeof req.body?.tutorialRoot === 'string') SETTINGS.lbmTutorialRoot = req.body.tutorialRoot.trim();
    if (typeof req.body?.runCmd === 'string') SETTINGS.lbmRunCmd = req.body.runCmd.trim();
    if (typeof req.body?.lbmMode === 'boolean') SETTINGS.lbmMode = req.body.lbmMode;
    await saveSettings();
    res.json({ ok: true, tutorialRoot: SETTINGS.lbmTutorialRoot, runCmd: SETTINGS.lbmRunCmd, lbmMode: SETTINGS.lbmMode });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
app.get('/api/lbm/tutorials', async (req, res) => {
  try { res.type('text/plain').send(await lbmFindTutorial(req.query.q || '', Math.min(50, parseInt(req.query.top_k) || 30))); }
  catch (e) { res.status(400).type('text/plain').send(e.message); }
});
app.post('/api/lbm/clone', async (req, res) => {
  try { res.json({ ok: true, message: await lbmCloneTutorial(req.body?.tutorial_path, req.body?.dest) }); }
  catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});
app.post('/api/lbm/inspect', async (req, res) => {
  try { res.type('text/plain').send(await lbmInspectCase(req.body?.case_path, req.body?.algorithm)); }
  catch (e) { res.status(400).type('text/plain').send(e.message); }
});
app.post('/api/lbm/run', async (req, res) => {
  try {
    const { case_path, command } = req.body || {};
    const msg = await lbmRunAsync({ case_path, command }, null);
    res.json({ ok: true, message: msg });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});
app.post('/api/lbm/run/:id/stop', (req, res) => {
  res.json({ ok: true, message: lbmSolverStop(req.params.id) });
});

// ====================== 自定义工作流 Beta HTTP ======================
app.get('/api/custom/config', (req, res) => {
  res.json({
    customMode: !!SETTINGS.customMode,
    name:   SETTINGS.customName   || '',
    root:   SETTINGS.customRoot   || '',
    prompt: SETTINGS.customPrompt || ''
  });
});
app.post('/api/custom/config', async (req, res) => {
  try {
    if (typeof req.body?.name === 'string')   SETTINGS.customName   = req.body.name.slice(0, 200);
    if (typeof req.body?.root === 'string')   SETTINGS.customRoot   = req.body.root.slice(0, 500);
    if (typeof req.body?.prompt === 'string') SETTINGS.customPrompt = req.body.prompt.slice(0, 20000);
    if (typeof req.body?.customMode === 'boolean') SETTINGS.customMode = req.body.customMode;
    await saveSettings();
    res.json({
      ok: true,
      customMode: !!SETTINGS.customMode,
      name:   SETTINGS.customName   || '',
      root:   SETTINGS.customRoot   || '',
      prompt: SETTINGS.customPrompt || ''
    });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ====================== Digitizer (V3) HTTP ======================
// 序列化 request_id → { resolve, reject, timer } 为了等用户亲手标注后调用 tool 返回。
const PENDING_DIGITIZE = new Map();

app.post('/api/digitize/save', async (req, res) => {
  try {
    const body = req.body || {};
    const name = (body.name || 'plot').toString().replace(/[^\w\-]/g, '_').slice(0, 60) || 'plot';
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const dir = path.join(WORKSPACE, 'digitized');
    await fs.mkdir(dir, { recursive: true });
    const csvPath = path.join(dir, `${ts}_${name}.csv`);
    const pts = Array.isArray(body.points) ? body.points : [];
    const head = `# digitized at ${new Date().toISOString()}\n# axis_x=${body.axis_x} axis_y=${body.axis_y}\n# calibration: X1=(${body?.calibration?.x1?.x},${body?.calibration?.x1?.y})→${body?.calibration?.x1?.value}  X2=(${body?.calibration?.x2?.x},${body?.calibration?.x2?.y})→${body?.calibration?.x2?.value}  Y1=(${body?.calibration?.y1?.x},${body?.calibration?.y1?.y})→${body?.calibration?.y1?.value}  Y2=(${body?.calibration?.y2?.x},${body?.calibration?.y2?.y})→${body?.calibration?.y2?.value}\nx,y\n`;
    const lines = pts.map(p => `${Number(p.x)},${Number(p.y)}`).join('\n') + '\n';
    await fs.writeFile(csvPath, head + lines);
    // 也可选保存原始图片
    let imgRel = null;
    if (body.image_base64) {
      const imgPath = path.join(dir, `${ts}_${name}.png`);
      await fs.writeFile(imgPath, Buffer.from(body.image_base64, 'base64'));
      imgRel = path.relative(WORKSPACE, imgPath).replace(/\\/g, '/');
    }
    const rel = path.relative(WORKSPACE, csvPath).replace(/\\/g, '/');

    // 如果是 agent 发起的 request → 解锁 pending
    if (body.request_id && PENDING_DIGITIZE.has(body.request_id)) {
      const entry = PENDING_DIGITIZE.get(body.request_id);
      PENDING_DIGITIZE.delete(body.request_id);
      try { clearTimeout(entry.timer); } catch {}
      entry.resolve({ csvPath: rel, imagePath: imgRel, points: pts, axis_x: body.axis_x, axis_y: body.axis_y, name });
    }
    // 广播给所有 ws：让聊天出一条系统提示
    if (body.send_to_chat) {
      for (const c of allClients) {
        try { c.send(JSON.stringify({ type: 'term', line: `[标注完成] ${pts.length} 个数据点 → ${rel}` })); } catch {}
      }
    }
    res.json({ ok: true, path: rel, image_path: imgRel, count: pts.length });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post('/api/digitize/cancel', (req, res) => {
  const id = req.body?.request_id;
  if (id && PENDING_DIGITIZE.has(id)) {
    const entry = PENDING_DIGITIZE.get(id);
    PENDING_DIGITIZE.delete(id);
    try { clearTimeout(entry.timer); } catch {}
    entry.resolve({ canceled: true });
  }
  res.json({ ok: true });
});

// Agent 端工具：让用户手动标注一张图表
async function requestUserDigitize(args, ws, session) {
  const reqId = 'dig-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  const timeoutSec = Math.max(30, Math.min(3600, args.timeout_sec || 600));
  let imageBase64 = null;
  let imageNote = '';
  if (args.image_path) {
    try {
      const abs = path.isAbsolute(args.image_path) ? args.image_path : path.resolve(WORKSPACE, args.image_path);
      const buf = await fs.readFile(abs);
      imageBase64 = buf.toString('base64');
      imageNote = ` (已预加载 ${path.relative(WORKSPACE, abs)})`;
    } catch (e) {
      imageNote = ` (预加载失败: ${e.message}，用户需自行选图)`;
    }
  }
  // 推送给当前 ws + 所有 ws（让用户能从任意标签页响应）
  const payload = { type: 'digitize_open', request_id: reqId, image_base64: imageBase64, hint: args.hint || '', name: args.name || 'plot' };
  try { ws.send(JSON.stringify(payload)); } catch {}
  // 同步等用户
  return await new Promise((resolve) => {
    const timer = setTimeout(() => {
      if (PENDING_DIGITIZE.has(reqId)) {
        PENDING_DIGITIZE.delete(reqId);
        resolve(`[超时] 用户在 ${timeoutSec}s 内未完成标注${imageNote}`);
      }
    }, timeoutSec * 1000);
    PENDING_DIGITIZE.set(reqId, {
      timer,
      resolve: (r) => {
        if (r.canceled) return resolve(`[用户取消] 标注被取消${imageNote}`);
        const lines = [
          `[标注完成]${imageNote}`,
          `CSV: ${r.csvPath}`,
          r.imagePath ? `IMG: ${r.imagePath}` : null,
          `axis_x=${r.axis_x}, axis_y=${r.axis_y}, n=${r.points.length}`,
          ``,
          `数据点（x, y）：`,
          ...r.points.slice(0, 80).map((p, i) => `  ${i+1}. ${Number(p.x).toPrecision(6)}, ${Number(p.y).toPrecision(6)}`)
        ].filter(Boolean);
        if (r.points.length > 80) lines.push(`  ... 还有 ${r.points.length - 80} 个点见 CSV`);
        resolve(lines.join('\n'));
      },
      reject: () => resolve(`[标注失败]`)
    });
  });
}

// ====================== Python 环境发现 ======================
function probePython(exe) {
  return new Promise((resolve) => {
    const p = spawn(exe, ['-c', 'import sys,platform,os; print(sys.version.split()[0]); print(sys.executable); print(os.environ.get("CONDA_DEFAULT_ENV",""))'], { windowsHide: true });
    let out = '', err = '';
    p.stdout.on('data', d => out += d); p.stderr.on('data', d => err += d);
    const to = setTimeout(() => { try { p.kill(); } catch {} resolve(null); }, 4000);
    p.on('close', (code) => { clearTimeout(to); if (code !== 0) return resolve(null);
      const [ver, real, conda] = out.trim().split(/\r?\n/);
      resolve({ path: real || exe, version: ver || '', conda: conda || '' });
    });
    p.on('error', () => { clearTimeout(to); resolve(null); });
  });
}

async function discoverPythons() {
  const candidates = new Set();
  // 1. PATH 上的
  if (IS_WIN) ['python.exe', 'python3.exe', 'py.exe'].forEach(n => candidates.add(n));
  else ['python3', 'python'].forEach(n => candidates.add(n));
  // 2. 常见 conda 位置
  const home = os.homedir();
  const condaRoots = IS_WIN
    ? [path.join(home, 'anaconda3'), path.join(home, 'miniconda3'), path.join(home, 'miniforge3'), 'C:\\ProgramData\\Anaconda3', 'C:\\ProgramData\\miniconda3']
    : [path.join(home, 'anaconda3'), path.join(home, 'miniconda3'), path.join(home, 'miniforge3'), '/opt/anaconda3', '/opt/miniconda3'];
  for (const root of condaRoots) {
    try { await fs.access(root);
      candidates.add(IS_WIN ? path.join(root, 'python.exe') : path.join(root, 'bin', 'python'));
      const envsDir = path.join(root, 'envs');
      try { const entries = await fs.readdir(envsDir, { withFileTypes: true });
        for (const e of entries) if (e.isDirectory())
          candidates.add(IS_WIN ? path.join(envsDir, e.name, 'python.exe') : path.join(envsDir, e.name, 'bin', 'python'));
      } catch {}
    } catch {}
  }
  // 3. 当前工作区的 venv
  for (const sub of ['.venv', 'venv', 'env', '.env']) {
    const py = IS_WIN ? path.join(WORKSPACE, sub, 'Scripts', 'python.exe') : path.join(WORKSPACE, sub, 'bin', 'python');
    try { await fs.access(py); candidates.add(py); } catch {}
  }
  // 4. Windows: py.exe -0p 列出所有安装
  if (IS_WIN) {
    try {
      const out = await new Promise((res) => {
        const p = spawn('py.exe', ['-0p'], { windowsHide: true });
        let o = ''; p.stdout.on('data', d => o += d);
        p.on('close', () => res(o)); p.on('error', () => res(''));
        setTimeout(() => { try { p.kill(); } catch {} res(o); }, 3000);
      });
      out.split(/\r?\n/).forEach(l => { const m = l.match(/([A-Z]:\\[^\r\n]+python\.exe)/i); if (m) candidates.add(m[1]); });
    } catch {}
  }
  // 探测并去重
  const results = []; const seen = new Set();
  for (const c of candidates) {
    const info = await probePython(c);
    if (!info) continue;
    if (seen.has(info.path)) continue;
    seen.add(info.path);
    results.push({ path: info.path, version: info.version, conda: info.conda, requested: c });
  }
  results.sort((a, b) => b.version.localeCompare(a.version));
  return results;
}

let PY_CACHE = null;
app.get('/api/python/list', async (req, res) => {
  if (req.query.refresh === '1') PY_CACHE = null;
  if (!PY_CACHE) PY_CACHE = await discoverPythons();
  res.json({ envs: PY_CACHE, current: SETTINGS.pythonPath || '' });
});
app.post('/api/python/select', async (req, res) => {
  const { path: p } = req.body || {};
  if (p) {
    const info = await probePython(p);
    if (!info) return res.status(400).json({ error: '路径不是有效的 Python 解释器' });
    SETTINGS.pythonPath = info.path;
  } else SETTINGS.pythonPath = '';
  await saveSettings();
  res.json({ ok: true, current: SETTINGS.pythonPath });
});

// ====================== pvpython 自检（诊断 IMPORT_ERR） ======================
app.get('/api/pv/probe', async (req, res) => {
  const exe = pvpythonExe();
  const result = {
    chosenExe: exe,
    settings: {
      paraviewExe: SETTINGS.paraviewExe || '',
      paraviewPython: SETTINGS.paraviewPython || ''
    },
    exists: fssync.existsSync(exe),
    basenameLooksRight: /pvpython/i.test(path.basename(exe)),
    hostEnv: {
      PYTHONHOME: process.env.PYTHONHOME || '',
      PYTHONPATH: process.env.PYTHONPATH || '',
      CONDA_PREFIX: process.env.CONDA_PREFIX || ''
    },
    test: null,
    suggestion: ''
  };
  if (!result.exists) {
    result.suggestion = `所选 pvpython 不存在：${exe}。请在「设置 → ParaView Python 路径」里指向 ParaView 安装目录下的 bin/pvpython.exe（不是普通 python.exe）。`;
    return res.json(result);
  }
  if (!result.basenameLooksRight) {
    result.suggestion = `当前路径文件名 (${path.basename(exe)}) 不像 pvpython。普通 python.exe 不带 paraview 模块，请改成 ParaView 安装目录下 bin/pvpython.exe。`;
  }
  await new Promise((resolve) => {
    const p = spawn(exe, ['-c', 'import sys;print(sys.executable);import paraview;print(paraview.__file__);print(getattr(paraview,"__version__",""))'], {
      windowsHide: true, env: pvCleanEnv()
    });
    let out = '', err = '';
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => err += d);
    const to = setTimeout(() => { try { p.kill(); } catch {} resolve(); }, 8000);
    p.on('close', (code) => {
      clearTimeout(to);
      const lines = out.trim().split(/\r?\n/);
      result.test = {
        exitCode: code,
        sysExecutable: lines[0] || '',
        paraviewModule: lines[1] || '',
        paraviewVersion: lines[2] || '',
        stderr: err.trim().slice(-500)
      };
      if (code !== 0 || !lines[1]) {
        if (/No module named 'paraview'/i.test(err)) {
          if (!result.basenameLooksRight) {
            result.suggestion = `用户把 ParaView Python 路径设成了 ${path.basename(exe)}，普通 python 不带 paraview 模块。请改成 ParaView 安装目录下 bin/pvpython.exe。`;
          } else if (process.env.PYTHONHOME || process.env.PYTHONPATH) {
            result.suggestion = `pvpython 启动了但 import paraview 失败。检测到宿主 PYTHONHOME/PYTHONPATH（conda/系统 Python 在劫持 pvpython 内嵌解释器）。已自动剔除这两个变量再启动；若仍失败说明 ParaView 安装目录不完整。`;
          } else {
            result.suggestion = `pvpython 找不到 paraview 模块——通常是 ParaView 安装不完整。请从官网重新下载 (paraview.org/download)，解压后用其 bin/pvpython.exe。`;
          }
        } else {
          result.suggestion = `pvpython 启动失败 (exit ${code})：${err.trim().slice(-300)}`;
        }
      } else {
        result.suggestion = `OK：pvpython 工作正常，paraview ${lines[2] || ''} @ ${lines[1] || ''}`;
      }
      resolve();
    });
    p.on('error', (e) => {
      clearTimeout(to);
      result.test = { exitCode: -1, error: e.message };
      result.suggestion = `pvpython 启动失败：${e.message}（路径：${exe}）`;
      resolve();
    });
  });
  res.json(result);
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// ============== WebSocket 心跳（防代理空闲断开 / 自动清理僵尸连接）==============
const WS_PING_MS = 25_000;
const wsHeartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { try { ws.terminate(); } catch {} continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
    try { if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'heartbeat', t: Date.now() })); } catch {}
  }
}, WS_PING_MS);
wss.on('close', () => clearInterval(wsHeartbeat));

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  const session = {
    messages: [{ role: 'system', content: SYSTEM_PROMPT_BASE(WORKSPACE) }],
    checkpoints: [], currentCheckpoint: null,
    pendingEdits: [], todos: [], taskComplete: false,
    autoMode: true,
    foamMode: !!SETTINGS.foamMode,
    mfixMode: !!SETTINGS.mfixMode,
    lbmMode:  !!SETTINGS.lbmMode,
    customMode: !!SETTINGS.customMode,
    enabledTools: new Set(DEFAULT_ENABLED),
    pendingApproval: null, aborter: null, aborted: false, currentProc: null,
    shell: null, shellCwd: WORKSPACE,
    // V4: 人在回路 — 当 agent 抛出 1)/2)/3) 编号选项且无 tool_call 时，置 true；下一条 user 消息会清零
    awaitingUserChoice: false
  };
  sessions.set(ws, session); allClients.add(ws);
  ws.send(JSON.stringify({ type: 'tools_state', enabled: [...session.enabledTools], groups: TOOL_GROUPS }));
  buildTree().then(t => ws.send(JSON.stringify({ type: 'tree', tree: t }))).catch(()=>{});
  broadcastCheckpoints(ws); broadcastEdits(ws); broadcastTodos(ws);
  ws.send(JSON.stringify({ type: 'sim_state', enabled: false, running: !!PV_STATE.pid }));
  if (PV_STATE.lastFrame) ws.send(JSON.stringify({ type: 'sim_frame', dataUrl: PV_STATE.lastFrame }));
  ws.send(JSON.stringify({ type: 'foam_state', enabled: !!session.foamMode, root: SETTINGS.foamRoot || '' }));
  ws.send(JSON.stringify({ type: 'mfix_state', enabled: !!session.mfixMode, root: SETTINGS.mfixRoot || '', bash: SETTINGS.mfixBash || '' }));
  ws.send(JSON.stringify({ type: 'lbm_state', enabled: !!session.lbmMode, tutorialRoot: SETTINGS.lbmTutorialRoot || '', runCmd: SETTINGS.lbmRunCmd || '' }));
  ws.send(JSON.stringify({ type: 'custom_state', enabled: !!session.customMode, name: SETTINGS.customName || '', root: SETTINGS.customRoot || '', prompt: SETTINGS.customPrompt || '' }));

  // —— 交互式 shell ——
  function ensureShell() {
    if (session.shell && !session.shell.killed) return session.shell;
    const sh = spawnShell(session.shellCwd);
    session.shell = sh;
    const onData = d => { d.toString().split(/\r?\n/).forEach(line => { if (line !== undefined) ws.send(JSON.stringify({ type: 'pty_out', line })); }); };
    sh.stdout.on('data', onData); sh.stderr.on('data', onData);
    sh.on('exit', (code) => { ws.send(JSON.stringify({ type: 'pty_out', line: `[shell 退出 ${code}]` })); session.shell = null; });
    ws.send(JSON.stringify({ type: 'pty_out', line: `[已启动 ${IS_WIN ? 'cmd.exe' : (process.env.SHELL || 'bash')} @ ${session.shellCwd}]` }));
    return sh;
  }

  ws.on('message', async (raw) => {
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    const s = sessions.get(ws); if (!s) return;
    if (m.type === 'user') { s.awaitingUserChoice = false; s.messages[0] = { role: 'system', content: buildSystemPrompt(s) }; runAgent(ws, m.text, m.attachments || []); }
    else if (m.type === 'set_auto') s.autoMode = !!m.value;
    else if (m.type === 'nb_open') {
      const k = nbKernelStart(m.path); k.subscribers.add(ws);
      ws.send(JSON.stringify({ type: 'nb_msg', path: m.path, msg: { type: k.ready ? 'ready' : 'starting' } }));
    }
    else if (m.type === 'nb_execute') { nbKernelStart(m.path).subscribers.add(ws); nbKernelSend(m.path, { action: 'execute', code: m.code, cell_id: m.cell_id }); }
    else if (m.type === 'nb_interrupt') { nbKernelSend(m.path, { action: 'interrupt' }); }
    else if (m.type === 'nb_restart') { nbKernelSend(m.path, { action: 'restart' }); }
    else if (m.type === 'nb_close') { const k = NB_KERNELS.get(m.path); if (k) k.subscribers.delete(ws); }
    else if (m.type === 'set_tools') {
      const incoming = Array.isArray(m.tools) ? m.tools : [];
      const enabled = new Set([...TOOL_GROUPS.edit, ...incoming]);  // 编辑类始终开启
      s.enabledTools = enabled;
      ws.send(JSON.stringify({ type: 'tools_state', enabled: [...enabled] }));
    }
    // set_sim removed in v2; ParaView frame subscription is opened by set_foam/set_mfix/set_lbm when any Beta mode is enabled.
    else if (m.type === 'set_foam') {
      s.foamMode = !!m.value;
      // 同时把 foam 工具组并入启用集合（关掉时不强制移除，让用户自己取消）
      if (s.foamMode) for (const t of TOOL_GROUPS.foam) s.enabledTools.add(t);
      // ParaView 帧推送：任一 Beta 模式启用即订阅，全部关闭才取消
      if (s.foamMode || s.mfixMode || s.lbmMode) PV_STATE.subscribers.add(ws);
      else PV_STATE.subscribers.delete(ws);
      s.messages[0] = { role: 'system', content: buildSystemPrompt(s) };
      SETTINGS.foamMode = s.foamMode; await saveSettings();
      ws.send(JSON.stringify({ type: 'tools_state', enabled: [...s.enabledTools], groups: TOOL_GROUPS }));
      ws.send(JSON.stringify({ type: 'foam_state', enabled: s.foamMode, root: SETTINGS.foamRoot || '' }));
      ws.send(JSON.stringify({ type: 'term', line: `[OpenFOAM Beta ${s.foamMode ? '开启' : '关闭'}]` }));
    }
    else if (m.type === 'set_mfix') {
      s.mfixMode = !!m.value;
      if (s.mfixMode) for (const t of TOOL_GROUPS.mfix) s.enabledTools.add(t);
      if (s.foamMode || s.mfixMode || s.lbmMode) PV_STATE.subscribers.add(ws);
      else PV_STATE.subscribers.delete(ws);
      s.messages[0] = { role: 'system', content: buildSystemPrompt(s) };
      SETTINGS.mfixMode = s.mfixMode; await saveSettings();
      ws.send(JSON.stringify({ type: 'tools_state', enabled: [...s.enabledTools], groups: TOOL_GROUPS }));
      ws.send(JSON.stringify({ type: 'mfix_state', enabled: s.mfixMode, root: SETTINGS.mfixRoot || '', bash: SETTINGS.mfixBash || '' }));
      ws.send(JSON.stringify({ type: 'term', line: `[MFIX Beta ${s.mfixMode ? '开启' : '关闭'}]` }));
    }
    else if (m.type === 'set_lbm') {
      s.lbmMode = !!m.value;
      if (s.lbmMode) for (const t of TOOL_GROUPS.lbm) s.enabledTools.add(t);
      if (s.foamMode || s.mfixMode || s.lbmMode) PV_STATE.subscribers.add(ws);
      else PV_STATE.subscribers.delete(ws);
      s.messages[0] = { role: 'system', content: buildSystemPrompt(s) };
      SETTINGS.lbmMode = s.lbmMode; await saveSettings();
      ws.send(JSON.stringify({ type: 'tools_state', enabled: [...s.enabledTools], groups: TOOL_GROUPS }));
      ws.send(JSON.stringify({ type: 'lbm_state', enabled: s.lbmMode, tutorialRoot: SETTINGS.lbmTutorialRoot || '', runCmd: SETTINGS.lbmRunCmd || '' }));
      ws.send(JSON.stringify({ type: 'term', line: `[LBM Beta ${s.lbmMode ? '开启' : '关闭'}]` }));
    }
    else if (m.type === 'set_custom') {
      // 设置自定义工作流：{ enabled, name?, root?, prompt? }
      s.customMode = !!m.enabled;
      if (typeof m.name === 'string')   SETTINGS.customName   = m.name.slice(0, 200);
      if (typeof m.root === 'string')   SETTINGS.customRoot   = m.root.slice(0, 500);
      if (typeof m.prompt === 'string') SETTINGS.customPrompt = m.prompt.slice(0, 20000);
      SETTINGS.customMode = s.customMode;
      await saveSettings();
      s.messages[0] = { role: 'system', content: buildSystemPrompt(s) };
      ws.send(JSON.stringify({ type: 'custom_state', enabled: s.customMode, name: SETTINGS.customName || '', root: SETTINGS.customRoot || '', prompt: SETTINGS.customPrompt || '' }));
      const wc = (SETTINGS.customPrompt || '').length;
      ws.send(JSON.stringify({ type: 'term', line: `[自定义工作流 ${s.customMode ? '开启' : '关闭'}] ${SETTINGS.customName || '(未命名)'} · prompt ${wc} 字符` }));
    }
    else if (m.type === 'pty_input') { try { ensureShell().stdin.write(m.data); } catch (e) { ws.send(JSON.stringify({ type: 'pty_out', line: '[shell 错误] ' + e.message })); } }
    else if (m.type === 'pty_kill') { if (s.shell) try { s.shell.kill(); } catch {} }
    else if (m.type === 'approval' && s.pendingApproval) { const fn = s.pendingApproval; s.pendingApproval = null; fn(!!m.approved); }
    else if (m.type === 'stop') {
      s.aborted = true;
      if (s.aborter) try { s.aborter.abort(); } catch {}
      // 递归杀当前 agent 同步子进程树（run_command 等）。
      // ⚠ 重要边界：仅杀 s.currentProc，不动 SOLVER_RUNS — 那是用户显式启的后台求解，
      // 必须靠 foam_solver_stop / mfix_solver_stop / lbm_solver_stop 或面板按钮单独控制，
      // 不能让"停止 agent"误杀正在跑的 OpenFOAM/MFIX/LBM 仿真。
      if (s.currentProc) {
        const pid = s.currentProc.pid;
        try { s.currentProc.kill(); } catch {}
        if (IS_WIN && pid) {
          try { spawn('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }); } catch {}
        } else if (pid) {
          try { process.kill(pid, 'SIGKILL'); } catch {}
        }
      }
      if (s.pendingApproval) { const fn = s.pendingApproval; s.pendingApproval = null; fn(false); }
      const liveRuns = [...SOLVER_RUNS.values()].filter(r => !r.ended).length;
      const tail = liveRuns ? `（${liveRuns} 个后台求解器未受影响，仍在跑；如要停请在面板/工具里单独 stop）` : '';
      ws.send(JSON.stringify({ type: 'term', line: `[Agent 已停止]${tail}` }));
      ws.send(JSON.stringify({ type: 'agent_end' }));
    } else if (m.type === 'reset') {
      s.messages = [{ role: 'system', content: buildSystemPrompt(s) }];
      s.checkpoints = []; s.pendingEdits = []; s.todos = []; s.taskComplete = false;
      ws.send(JSON.stringify({ type: 'reset_done' }));
      broadcastCheckpoints(ws); broadcastEdits(ws); broadcastTodos(ws);
    } else if (m.type === 'compact') {
      try {
        const before = s.messages.length;
        // 保留 system + 最近 6 条；把中间用一段总结替代
        if (before > 10) {
          const sys = s.messages[0];
          const tail = s.messages.slice(-6);
          const middle = s.messages.slice(1, -6);
          const summary = middle.map(x => {
            if (x.role === 'user') return `[\u7528\u6237] ${(x.content || '').toString().slice(0, 200)}`;
            if (x.role === 'assistant') return `[\u52a9\u624b] ${(x.content || '').toString().slice(0, 300)}` + (x.tool_calls ? ` (\u8c03\u7528 ${x.tool_calls.map(t => t.function?.name).join(',')})` : '');
            if (x.role === 'tool') return `[\u5de5\u5177\u8fd4\u56de] ${String(x.content || '').slice(0, 200)}`;
            return '';
          }).filter(Boolean).join('\n');
          s.messages = [sys, { role: 'user', content: '\u4ee5\u4e0b\u662f\u4e4b\u524d\u4f1a\u8bdd\u7684\u538b\u7f29\u603b\u7ed3\uff1a\n' + summary }, ...tail];
        }
        ws.send(JSON.stringify({ type: 'term', line: `[\u5df2\u538b\u7f29\u4e0a\u4e0b\u6587\uff1a${before} \u2192 ${s.messages.length} \u6761\u6d88\u606f]` }));
      } catch (e) { ws.send(JSON.stringify({ type: 'error', message: '\u538b\u7f29\u5931\u8d25\uff1a' + e.message })); }
    } else if (m.type === 'restore_checkpoint') {
      try { const n = await restoreCheckpoint(s, m.id);
        ws.send(JSON.stringify({ type: 'term', line: `[已回滚 ${n} 个文件]` }));
        broadcastCheckpoints(ws); broadcastEdits(ws); broadcastTree();
      } catch (e) { ws.send(JSON.stringify({ type: 'error', message: '回滚失败：' + e.message })); }
    } else if (m.type === 'keep_edit') { try { keepEdit(s, m.id); broadcastEdits(ws); } catch (e) { ws.send(JSON.stringify({ type: 'error', message: e.message })); } }
    else if (m.type === 'undo_edit') { try { const e = await undoEdit(s, m.id); ws.send(JSON.stringify({ type: 'term', line: `[已撤销 ${e.path}]` })); broadcastEdits(ws); broadcastTree(); } catch (err) { ws.send(JSON.stringify({ type: 'error', message: '撤销失败：' + err.message })); } }
    else if (m.type === 'keep_all') { s.pendingEdits = []; broadcastEdits(ws); }
    else if (m.type === 'undo_all') {
      const ids = s.pendingEdits.map(e => e.id);
      for (const id of ids) { try { await undoEdit(s, id); } catch {} }
      broadcastEdits(ws); broadcastTree();
      ws.send(JSON.stringify({ type: 'term', line: `[已撤销全部待审编辑]` }));
    }
  });
  ws.on('close', () => {
    if (session.shell) try { session.shell.kill(); } catch {}
    PV_STATE.subscribers.delete(ws);
    // 从所有求解器订阅集合中移除，避免向已关闭 socket 推送
    for (const run of SOLVER_RUNS.values()) run.subs.delete(ws);
    // 中断进行中的审批/agent 循环，防止内存悬挂
    if (session.pendingApproval) { try { session.pendingApproval(false); } catch {} session.pendingApproval = null; }
    if (session.aborter) { try { session.aborter.abort(); } catch {} }
    session.aborted = true;
    sessions.delete(ws); allClients.delete(ws);
  });
});

await loadSettings();
await loadCopilotState();
await autoProbeEnvironment();
const HOST = parseCliHost() || process.env.HOST || '127.0.0.1';
server.listen(PORT, HOST, () => {
  console.log(`\n  NullFlux 已启动  (by LZF)`);
  console.log(`  平台: ${process.platform}`);
  console.log(`  工作目录: ${WORKSPACE}`);
  console.log(`  Provider:${SETTINGS.provider}  模型: ${SETTINGS.provider === 'copilot' ? SETTINGS.copilotModel : SETTINGS.model}`);
  console.log(`  ParaView:${SETTINGS.paraviewExe || '(未配置)'}`);
  console.log(`  pvpython:${SETTINGS.paraviewPython || '(默认 PATH)'}`);
  console.log(`  OpenFOAM root:${SETTINGS.foamRoot || '(未设置)'}`);
  console.log(`  OpenFOAM bashrc:${SETTINGS.openfoamBash || '(未设置)'}`);
  console.log(`  MFIX root:${SETTINGS.mfixRoot || '(未设置)'}`);
  console.log(`  MFIX bashrc:${SETTINGS.mfixBash || '(未设置)'}`);
  console.log(`  LBM tutorial root:${SETTINGS.lbmTutorialRoot || '(未设置)'}`);
  {
    const flags = [];
    if (process.env.TAVILY_API_KEY) flags.push('Tavily');
    if (process.env.SERPER_API_KEY) flags.push('Serper');
    if (process.env.BRAVE_API_KEY) flags.push('Brave');
    if (process.env.SEARXNG_URL) flags.push('SearXNG');
    if (process.env.SEMANTIC_SCHOLAR_API_KEY) flags.push('S2');
    console.log(`  联网搜索：${flags.length ? flags.join(' + ') + ' + HTML 兜底' : 'HTML 爬取 (DDG/Bing/Baidu)；可设置 TAVILY_API_KEY 获得 SOTA'}`);
    console.log(`  学术：Semantic Scholar + arXiv (无需 Key)`);
  }
  console.log(`  监听:    ${HOST}:${PORT}`);
  console.log(`  打开:    http://${HOST === '0.0.0.0' ? '<服务器IP>' : HOST}:${PORT}\n`);
});
