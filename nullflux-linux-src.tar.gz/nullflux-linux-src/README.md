# NullFlux (Linux · Source) — by LZF

> CFD AI Agent. 含源码版，便于二次开发。

## 一、安装依赖（首次）

```bash
# 需要 Node.js >= 18  (推荐 nvm install 20)
cd nullflux-linux-src
./start.sh           # 首次运行会自动执行 npm install --omit=dev
```

## 二、启动 / 指定端口

```bash
./start.sh                        # 默认 0.0.0.0:5174
./start.sh --port 5180            # 自定义端口
./start.sh -p 5180                # 缩写
./start.sh 5180                   # 直接给数字
./start.sh --port 5180 --host 127.0.0.1
```

## 三、可选系统依赖

- Python 3.9+      （doc_reader.py / Notebook 内核需要；可在 ⚙ 中选解释器）
- ParaView 5.x     （pvpython 离屏渲染；可选）
- OpenFOAM v2206+  （Beta CFD 模式；可选）

## 四、首次配置

打开浏览器访问 `http://<服务器>:<端口>`，点击 ⚙ 设置：
- LLM Provider + API Key
- ParaView / OpenFOAM 路径

## 五、文件构成

```
nullflux-linux-src/
├── server.js          ← 主程序（含完整源码）
├── doc_reader.py
├── nb_kernel_host.py
├── public/            ← 前端
├── package.json
├── start.sh           ← 启动脚本（支持端口参数）
└── README.md
```
