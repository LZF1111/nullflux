# CFDriver

> CFD AI Agent — by LZF

## 运行

```bash
# Linux / macOS
./start.sh

# Windows
start.bat
```

需要本机已安装：
- Node.js >= 18
- Python 3.9+（用于 doc_reader.py / Notebook 内核）
- 可选：ParaView 5.x（pvpython 用于离屏渲染）
- 可选：OpenFOAM v2206+（Beta 仿真模式）

默认地址：http://127.0.0.1:5175

## 配置

首次启动后到 ⚙ 面板填写：
- LLM Provider + API Key（保存在本地 settings.json）
- ParaView 路径（可选）
- OpenFOAM root + bashrc（可选）

## 文件构成

- server.bundle.mjs ← 主程序（已混淆封装，源码不可见）
- public/           ← 前端
- doc_reader.py     ← PDF/DOCX 读取（明文，依赖 PyMuPDF）
- start.sh / .bat   ← 启动脚本
