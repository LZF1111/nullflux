#!/usr/bin/env python3
"""NullFlux v6 — Optuna ask-tell 优化驱动
被 server.js 通过 child_process 调用；I/O 全走 stdin/stdout JSON。

子命令：
  create   --study_id S --base_dir D --spec '<json>'
  suggest  --study_id S --base_dir D
  record   --study_id S --base_dir D --trial_id N --value V --state STATE
  status   --study_id S --base_dir D
  render   --study_id S --base_dir D --kind history|importance|parallel|slice --out PATH
  list     --base_dir D

存储布局：
  <base_dir>/<study_id>/study.json         # 我们写的元数据（search_space, base_case, objective）
  <base_dir>/<study_id>/optuna.db          # Optuna SQLite 存所有 trial
  <base_dir>/<study_id>/trials.jsonl       # 我们写的可读 trial log（append-only）
"""

import argparse, json, os, sys, time, sqlite3
from pathlib import Path

def _eprint(msg):
    print(msg, file=sys.stderr, flush=True)

def _study_dir(base_dir, study_id):
    p = Path(base_dir) / study_id
    p.mkdir(parents=True, exist_ok=True)
    return p

def _storage_url(study_dir):
    return f"sqlite:///{(study_dir / 'optuna.db').as_posix()}"

def _load_spec(study_dir):
    f = study_dir / "study.json"
    if not f.exists():
        raise RuntimeError(f"study.json not found in {study_dir}")
    return json.loads(f.read_text(encoding="utf-8"))

def _make_sampler(name, seed=None):
    import optuna
    name = (name or "TPE").upper()
    if name == "TPE":   return optuna.samplers.TPESampler(seed=seed)
    if name == "GP":    return optuna.samplers.GPSampler(seed=seed)
    if name == "CMA":   return optuna.samplers.CmaEsSampler(seed=seed)
    if name == "RANDOM":return optuna.samplers.RandomSampler(seed=seed)
    if name == "GRID":
        # Grid 需要 search_space 字典；外部 caller 必须把 spec 里的 choices/网格点准备好
        return None  # 由 cmd_create 处理
    raise ValueError(f"unknown sampler: {name}")

def _make_pruner(name):
    import optuna
    if not name: return optuna.pruners.NopPruner()
    n = name.upper()
    if n == "MEDIAN":     return optuna.pruners.MedianPruner()
    if n == "HYPERBAND":  return optuna.pruners.HyperbandPruner()
    return optuna.pruners.NopPruner()

def _suggest_one(trial, p):
    name = p["name"]
    t = p["type"]
    if t == "float":
        return trial.suggest_float(name, float(p["low"]), float(p["high"]),
                                   log=bool(p.get("log", False)),
                                   step=p.get("step"))
    if t == "int":
        return trial.suggest_int(name, int(p["low"]), int(p["high"]),
                                 log=bool(p.get("log", False)),
                                 step=int(p.get("step", 1)))
    if t == "cat":
        return trial.suggest_categorical(name, p["choices"])
    raise ValueError(f"unknown param type: {t}")

# ----------------------------- commands -----------------------------

def cmd_create(args):
    import optuna
    sd = _study_dir(args.base_dir, args.study_id)
    spec = json.loads(args.spec)
    spec.setdefault("created_at", time.time())
    spec.setdefault("study_id", args.study_id)
    direction = spec.get("objective", {}).get("direction", "minimize")
    sampler_name = spec.get("sampler", "TPE")
    seed = spec.get("seed")

    # Grid sampler 特殊处理
    sampler = None
    if (sampler_name or "").upper() == "GRID":
        grid_space = {}
        for p in spec["search_space"]:
            if p["type"] == "cat":
                grid_space[p["name"]] = list(p["choices"])
            elif "grid" in p:
                grid_space[p["name"]] = list(p["grid"])
            else:
                raise ValueError(f"Grid sampler 需要 param '{p['name']}' 提供 choices 或 grid 列表")
        sampler = optuna.samplers.GridSampler(grid_space)
    else:
        sampler = _make_sampler(sampler_name, seed=seed)

    pruner = _make_pruner(spec.get("pruner"))
    storage = _storage_url(sd)

    # 创建或重连
    study = optuna.create_study(
        study_name=args.study_id,
        storage=storage,
        sampler=sampler,
        pruner=pruner,
        direction=direction,
        load_if_exists=True,
    )

    (sd / "study.json").write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    (sd / "trials.jsonl").touch(exist_ok=True)

    print(json.dumps({
        "ok": True,
        "study_id": args.study_id,
        "study_dir": str(sd),
        "storage": storage,
        "direction": direction,
        "sampler": sampler_name,
        "n_params": len(spec["search_space"]),
    }, ensure_ascii=False))

def cmd_suggest(args):
    import optuna
    sd = _study_dir(args.base_dir, args.study_id)
    spec = _load_spec(sd)
    storage = _storage_url(sd)
    study = optuna.load_study(study_name=args.study_id, storage=storage)

    trial = study.ask()
    params = {}
    for p in spec["search_space"]:
        params[p["name"]] = _suggest_one(trial, p)

    # 把 trial 编号塞回 storage，让 caller 后续 tell
    # Optuna 的 trial.number 是从 0 开始递增的
    out = {
        "ok": True,
        "study_id": args.study_id,
        "trial_id": trial.number,
        "trial_number": trial.number,
        "params": params,
        "trial_dir_suggested": f"trial_{trial.number:04d}",
    }
    # 写一行 jsonl
    with open(sd / "trials.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"event": "ask", "trial_id": trial.number, "params": params, "ts": time.time()}, ensure_ascii=False) + "\n")
    print(json.dumps(out, ensure_ascii=False))

def cmd_record(args):
    import optuna
    sd = _study_dir(args.base_dir, args.study_id)
    storage = _storage_url(sd)
    study = optuna.load_study(study_name=args.study_id, storage=storage)

    state = (args.state or "COMPLETE").upper()
    state_map = {
        "COMPLETE": optuna.trial.TrialState.COMPLETE,
        "PRUNED":   optuna.trial.TrialState.PRUNED,
        "FAIL":     optuna.trial.TrialState.FAIL,
    }
    if state not in state_map:
        raise ValueError(f"unknown state: {state}")

    # 找到这个 trial
    trial = None
    for t in study.get_trials(deepcopy=False, states=None):
        if t.number == args.trial_id:
            trial = t
            break
    if trial is None:
        raise RuntimeError(f"trial_id {args.trial_id} not found in study {args.study_id}")

    if state == "COMPLETE":
        if args.value is None:
            raise ValueError("COMPLETE state 需要 --value")
        study.tell(trial, args.value, state=state_map[state])
    else:
        study.tell(trial, state=state_map[state])

    with open(sd / "trials.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"event": "tell", "trial_id": args.trial_id, "value": args.value, "state": state, "ts": time.time()}, ensure_ascii=False) + "\n")

    out = {
        "ok": True,
        "trial_id": args.trial_id,
        "state": state,
        "value": args.value,
        "n_done": len([t for t in study.get_trials(deepcopy=False) if t.state == optuna.trial.TrialState.COMPLETE]),
    }
    try:
        bt = study.best_trial
        out["best"] = {"trial_id": bt.number, "value": bt.value, "params": bt.params}
    except Exception:
        out["best"] = None
    print(json.dumps(out, ensure_ascii=False))

def cmd_status(args):
    import optuna
    sd = _study_dir(args.base_dir, args.study_id)
    spec = _load_spec(sd)
    storage = _storage_url(sd)
    study = optuna.load_study(study_name=args.study_id, storage=storage)
    trials = study.get_trials(deepcopy=False)
    done = [t for t in trials if t.state == optuna.trial.TrialState.COMPLETE]
    pruned = [t for t in trials if t.state == optuna.trial.TrialState.PRUNED]
    failed = [t for t in trials if t.state == optuna.trial.TrialState.FAIL]
    running = [t for t in trials if t.state == optuna.trial.TrialState.RUNNING]

    history = [{"trial_id": t.number, "value": t.value, "params": t.params,
                "state": t.state.name} for t in trials]

    best = None
    try:
        bt = study.best_trial
        best = {"trial_id": bt.number, "value": bt.value, "params": bt.params}
    except Exception:
        pass

    # 收敛曲线：累计 best
    curve = []
    cur_best = None
    direction = spec.get("objective", {}).get("direction", "minimize")
    for t in done:
        v = t.value
        if cur_best is None: cur_best = v
        else:
            if direction == "minimize": cur_best = min(cur_best, v)
            else:                       cur_best = max(cur_best, v)
        curve.append({"trial_id": t.number, "value": v, "running_best": cur_best})

    # 参数重要性（>=10 done 时算）
    importance = None
    if len(done) >= 10:
        try:
            importance = optuna.importance.get_param_importances(study)
            importance = {k: float(v) for k, v in importance.items()}
        except Exception as e:
            importance = {"_error": str(e)}

    print(json.dumps({
        "ok": True,
        "study_id": args.study_id,
        "direction": direction,
        "sampler": spec.get("sampler"),
        "n_trials_total": len(trials),
        "n_done": len(done),
        "n_pruned": len(pruned),
        "n_failed": len(failed),
        "n_running": len(running),
        "budget": spec.get("n_trials_budget"),
        "best": best,
        "history": history,
        "convergence": curve,
        "importance": importance,
    }, ensure_ascii=False))

def cmd_render(args):
    import optuna
    sd = _study_dir(args.base_dir, args.study_id)
    storage = _storage_url(sd)
    study = optuna.load_study(study_name=args.study_id, storage=storage)
    kind = args.kind
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        from optuna.visualization.matplotlib import (
            plot_optimization_history, plot_param_importances,
            plot_parallel_coordinate, plot_slice,
        )
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        if kind == "history":
            ax = plot_optimization_history(study)
        elif kind == "importance":
            ax = plot_param_importances(study)
        elif kind == "parallel":
            ax = plot_parallel_coordinate(study)
        elif kind == "slice":
            ax = plot_slice(study)
        else:
            raise ValueError(f"unknown kind: {kind}")
        fig = ax.figure if hasattr(ax, "figure") else plt.gcf()
        fig.set_size_inches(10, 6)
        fig.tight_layout()
        fig.savefig(out_path, dpi=120)
        plt.close(fig)
        print(json.dumps({"ok": True, "kind": kind, "path": str(out_path)}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))

def cmd_list(args):
    base = Path(args.base_dir)
    if not base.exists():
        print(json.dumps({"ok": True, "studies": []}, ensure_ascii=False)); return
    studies = []
    for d in sorted(base.iterdir()):
        if not d.is_dir(): continue
        sj = d / "study.json"
        if not sj.exists(): continue
        try:
            spec = json.loads(sj.read_text(encoding="utf-8"))
            studies.append({
                "study_id": d.name,
                "sampler": spec.get("sampler"),
                "direction": spec.get("objective", {}).get("direction"),
                "n_params": len(spec.get("search_space", [])),
                "budget": spec.get("n_trials_budget"),
                "created_at": spec.get("created_at"),
            })
        except Exception:
            pass
    print(json.dumps({"ok": True, "studies": studies}, ensure_ascii=False))

# ----------------------------- entry -----------------------------

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("create")
    p.add_argument("--study_id", required=True)
    p.add_argument("--base_dir", required=True)
    p.add_argument("--spec", required=True, help="JSON spec string")
    p.set_defaults(func=cmd_create)

    p = sub.add_parser("suggest")
    p.add_argument("--study_id", required=True)
    p.add_argument("--base_dir", required=True)
    p.set_defaults(func=cmd_suggest)

    p = sub.add_parser("record")
    p.add_argument("--study_id", required=True)
    p.add_argument("--base_dir", required=True)
    p.add_argument("--trial_id", type=int, required=True)
    p.add_argument("--value", type=float, default=None)
    p.add_argument("--state", default="COMPLETE")
    p.set_defaults(func=cmd_record)

    p = sub.add_parser("status")
    p.add_argument("--study_id", required=True)
    p.add_argument("--base_dir", required=True)
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("render")
    p.add_argument("--study_id", required=True)
    p.add_argument("--base_dir", required=True)
    p.add_argument("--kind", required=True, choices=["history","importance","parallel","slice"])
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_render)

    p = sub.add_parser("list")
    p.add_argument("--base_dir", required=True)
    p.set_defaults(func=cmd_list)

    args = ap.parse_args()
    try:
        args.func(args)
    except Exception as e:
        print(json.dumps({"ok": False, "error": str(e), "type": type(e).__name__}, ensure_ascii=False))
        sys.exit(1)

if __name__ == "__main__":
    main()
